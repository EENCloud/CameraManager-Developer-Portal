package com.cameramanager.mobile_sdk_sample.activity

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.cameramanager.mobile_sdk.camera_core.data.Device
import com.cameramanager.mobile_sdk.camera_core.error.MobileSdkError
import com.cameramanager.mobile_sdk.wizard.CameraWizard
import com.cameramanager.mobile_sdk.wizard.CameraWizardListener
import com.cameramanager.mobile_sdk_sample.ConsoleUtil
import com.cameramanager.mobile_sdk_sample.R
import com.cameramanager.mobile_sdk_sample.impl.AccessTokenProviderImpl
import io.reactivex.Completable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_add_camera.*

class AddCameraActivity : AppCompatActivity() {

    private val compositeDisposable = CompositeDisposable()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_camera)

        val accessToken = intent.getStringExtra(DemoActivity.ACCESS_TOKEN)!!

        val accessTokenProvider = AccessTokenProviderImpl(accessToken)

        addButton.setOnClickListener {
            progressBar.visibility = View.VISIBLE
            ConsoleUtil.consoleLog(this, "Adding Camera", resultTextView)

            val cameraMac = cameraEditText.text.toString()
            val zoneId = zoneEditText.text.toString().toLong()

            compositeDisposable.add(
                Completable.create { emitter ->
                    val listener = object : CameraWizardListener {
                        override fun onAdded(cameraId: Long) {
                            emitter.onComplete()
                        }
                        override fun onError(device: Device?, mobileSdkError: MobileSdkError?) {
                            emitter.onError(mobileSdkError!!)
                        }
                    }
                    val cameraWizard = CameraWizard(listener)
                    cameraWizard.setProvider(accessTokenProvider)
                    cameraWizard.addDevice(cameraMac, "My awesome camera", zoneId)

                }.observeOn(Schedulers.io()).subscribe({
                    ConsoleUtil.consoleLog(this, "Camera Added Successfully", resultTextView)
                    progressBar.visibility = View.INVISIBLE
                }, {
                    ConsoleUtil.consoleLog(this, "Error on adding camera: $it", resultTextView)
                    progressBar.visibility = View.INVISIBLE
                })
            )
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        compositeDisposable.clear()
    }

}