package com.cameramanager.mobile_sdk_sample.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cameramanager.mobile_sdk_sample.R
import io.reactivex.disposables.CompositeDisposable
import kotlinx.android.synthetic.main.activity_demo.*

class DemoActivity : AppCompatActivity() {

    companion object {
        const val ACCESS_TOKEN = "ACCESS_TOKEN"
        const val CAMERA_ID = "CAMERA_ID"
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_demo)

        val accessToken = intent.getStringExtra(ACCESS_TOKEN) ?: return

        infoTextView.text = "Access Token: $accessToken"

        snifferButton.setOnClickListener {
            val intent = Intent(this, SnifferActivity::class.java)
            intent.putExtra(ACCESS_TOKEN, accessToken)
            startActivity(intent)
        }

        addCameraButton.setOnClickListener {
            val intent = Intent(this, AddCameraActivity::class.java)
            intent.putExtra(ACCESS_TOKEN, accessToken)
            startActivity(intent)
        }

        streamingButton.setOnClickListener {
            val intent = Intent(this, StreamingActivity::class.java)
            intent.putExtra(ACCESS_TOKEN, accessToken)
            startActivity(intent)
        }

    }

}