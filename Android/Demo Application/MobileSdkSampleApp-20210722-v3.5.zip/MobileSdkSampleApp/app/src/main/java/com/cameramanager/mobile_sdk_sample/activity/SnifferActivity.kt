package com.cameramanager.mobile_sdk_sample.activity

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.cameramanager.mobile_sdk.sniffer.CameraSniffer
import com.cameramanager.mobile_sdk_sample.ConsoleUtil
import com.cameramanager.mobile_sdk_sample.R
import com.cameramanager.mobile_sdk_sample.impl.AccessTokenProviderImpl
import com.cameramanager.mobile_sdk_sample.impl.CameraSnifferListenerImpl
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_sniffer.*
import java.util.concurrent.TimeUnit

class SnifferActivity: AppCompatActivity() {

    private val compositeDisposable = CompositeDisposable()
    private val sniffingSecondsPeriod = 3L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sniffer)

        val accessToken = intent.getStringExtra(DemoActivity.ACCESS_TOKEN)!!

        val accessTokenProvider = AccessTokenProviderImpl(accessToken)
        val cameraSniffer = CameraSniffer(this, CameraSnifferListenerImpl(this))
        cameraSniffer.setProvider(accessTokenProvider)

        compositeDisposable.add(
            Observable.interval(sniffingSecondsPeriod, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.computation())
                .subscribe {
                    if (cameraSniffer.isSniffing) {
                        val foundDevices = cameraSniffer.foundDevices
                        ConsoleUtil.consoleLog(this, "${foundDevices.size} found devices", resultTextView)
                    }
                }
        )

        startButton.setOnClickListener {
            cameraSniffer.startSniffing()
            progressBar.visibility = View.VISIBLE
            ConsoleUtil.consoleLog(this, "Start Sniffing", resultTextView)
        }

        stopButton.setOnClickListener {
            cameraSniffer.stopSniffing()
            ConsoleUtil.consoleLog(this, "Stop Sniffing", resultTextView)
            progressBar.visibility = View.INVISIBLE
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        compositeDisposable.clear()
    }

}