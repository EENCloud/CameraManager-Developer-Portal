package com.cameramanager.mobile_sdk_sample

import android.app.Application

class SampleApplication: Application() {

    companion object {
        lateinit var application: Application
    }

    override fun onCreate() {
        super.onCreate()
        application = this
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
    }

}