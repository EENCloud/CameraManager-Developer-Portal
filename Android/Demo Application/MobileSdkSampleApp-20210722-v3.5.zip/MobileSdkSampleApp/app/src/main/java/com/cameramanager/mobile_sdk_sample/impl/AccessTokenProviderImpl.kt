package com.cameramanager.mobile_sdk_sample.impl

import com.cameramanager.mobile_sdk.token_provider.AccessTokenProvider

class AccessTokenProviderImpl(var token: String) : AccessTokenProvider {

    override fun getAccessToken(): String {
        return token
    }

}