package com.cameramanager.mobile_sdk_sample.activity

import android.os.Bundle
import android.view.Surface
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.cameramanager.mobile_sdk.streamer.CameraStreamer
import com.cameramanager.mobile_sdk.streamer.CameraStreamerListener
import com.cameramanager.mobile_sdk.streamer.StreamerItem
import com.cameramanager.mobile_sdk_sample.ConsoleUtil
import com.cameramanager.mobile_sdk_sample.R
import com.cameramanager.mobile_sdk_sample.impl.AccessTokenProviderImpl
import io.reactivex.disposables.CompositeDisposable
import kotlinx.android.synthetic.main.activity_streaming.*
import kotlinx.android.synthetic.main.activity_streaming.cameraEditText
import kotlinx.android.synthetic.main.activity_streaming.progressBar

class StreamingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_streaming)

        val accessToken = intent.getStringExtra(DemoActivity.ACCESS_TOKEN)!!

        startButton.setOnClickListener {
            progressBar.visibility = View.VISIBLE

            val streamerItem = if (recordingEditText.text.isBlank()) {
                ConsoleUtil.consoleLog(this, "Playing Camera", resultTextView)
                StreamerItem.createItem(cameraEditText.text.toString().toLong())
            } else {
                ConsoleUtil.consoleLog(this, "Playing Recording", resultTextView)
                StreamerItem.createItem(cameraEditText.text.toString().toLong(), recordingEditText.text.toString().toLong())
            }

            val cameraStreamer = CameraStreamer(this, Surface(textureView.surfaceTexture))

            cameraStreamer.cameraStreamerListener = object : CameraStreamerListener {

                override fun onStatusChanged(cameraStreamerStatus: CameraStreamer.CameraStreamerStatus?) {
                    ConsoleUtil.consoleLog(this@StreamingActivity, "onStatusChanged: $cameraStreamerStatus", resultTextView)
                }

                override fun onPlaybackStateChanged(cameraStreamerPlaybackState: CameraStreamer.CameraStreamerPlaybackState?) {
                    if (cameraStreamerPlaybackState == CameraStreamer.CameraStreamerPlaybackState.Playing) {
                        progressBar.visibility = View.INVISIBLE
                    } else {
                        progressBar.visibility = View.VISIBLE
                    }
                    ConsoleUtil.consoleLog(this@StreamingActivity, "onPlaybackStateChanged: $cameraStreamerPlaybackState", resultTextView)
                }

                override fun onCurrentItemStatusChanged(streamerItemStatus: StreamerItem.StreamerItemStatus?) {
                    ConsoleUtil.consoleLog(this@StreamingActivity, "onCurrentItemStatusChanged: $streamerItemStatus", resultTextView)
                }

                override fun onCurrentItemDurationChanged(newDuration: Long) {
                    ConsoleUtil.consoleLog(this@StreamingActivity, "onCurrentItemDurationChanged: $newDuration", resultTextView)
                    println("onCurrentItemDurationChanged")
                }

                override fun onAudioStreamingStateChanged(cameraStreamerAudioStreamingState: CameraStreamer.CameraStreamerAudioStreamingState?) {
                    ConsoleUtil.consoleLog(this@StreamingActivity, "onAudioStreamingStateChanged: $cameraStreamerAudioStreamingState", resultTextView)
                }

                override fun onSnapshotTaken(snapshot: ByteArray?, snapshotTime: Long) {
                    ConsoleUtil.consoleLog(this@StreamingActivity, "onSnapshotTaken: $snapshotTime", resultTextView)
                }

            }

            cameraStreamer.setProvider(AccessTokenProviderImpl(accessToken))
            cameraStreamer.streamerItem = streamerItem
//            cameraStreamer.seekTo(streamer.getDuration() / 2)
            cameraStreamer.rate = 1f
        }
    }
}