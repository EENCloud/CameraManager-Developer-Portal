package com.cameramanager.mobile_sdk_sample

import android.annotation.SuppressLint
import android.app.Activity
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

object ConsoleUtil {

    private val formatter = SimpleDateFormat("HH:mm:ss", Locale.ENGLISH)

    @SuppressLint("SetTextI18n")
    fun consoleLog(activity: Activity, text: String, textView: TextView) {
        activity.runOnUiThread {
            textView.text = "${textView.text}\n${formatter.format(Date())}: $text"
        }
    }

}