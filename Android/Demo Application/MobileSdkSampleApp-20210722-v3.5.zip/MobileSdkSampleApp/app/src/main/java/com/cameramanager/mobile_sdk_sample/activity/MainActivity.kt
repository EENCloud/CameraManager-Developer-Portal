package com.cameramanager.mobile_sdk_sample.activity

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker
import com.cameramanager.mobile_sdk_sample.BuildConfig
import com.cameramanager.mobile_sdk_sample.R
import com.cameramanager.mobile_sdk_sample.api.SampleRetrofit
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {

    companion object {
        const val PERMISSION_REQUEST_CODE = 123
        const val REST_ENVIRONMENT = "rest"
        const val ACCEPTANCE_ENVIRONMENT = "acceptance"
        const val TEST_ENVIRONMENT = "test"
        const val ENVIRONMENT_KEY = "ENVIRONMENT"
        const val USERNAME_KEY = "USERNAME"
        const val PASSWORD_KEY = "PASSWORD"
        const val CAMERA_KEY = "CAMERA"
    }

    private val compositeDisposable = CompositeDisposable()
    private var sampleRetrofit: SampleRetrofit = SampleRetrofit()
    private var accessToken: String? = null
    private var demoCount: Int = 0
    private val protocol = "https://"
    private var environment = REST_ENVIRONMENT
    private val url = ".cameramanager.com"
    private var loginBaseUrl = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        configEnvironmentButtons()
        configLoginButton()
        configPermissionsButton()
        configDemoButton()
        configTitleDemo()

        loadValues()
    }

    override fun onDestroy() {
        super.onDestroy()
        compositeDisposable.clear()
    }

    private fun configEnvironmentButtons() {
        restButton.alpha = 0.25f
        acceptanceButton.alpha = 0.25f
        testButton.alpha = 0.25f
        restButton.setOnClickListener { setEnvironment(REST_ENVIRONMENT) }
        acceptanceButton.setOnClickListener { setEnvironment(ACCEPTANCE_ENVIRONMENT) }
        testButton.setOnClickListener { setEnvironment(TEST_ENVIRONMENT) }
        acceptanceButton.isEnabled = false
        testButton.isEnabled = false
    }

    private fun setEnvironment(environment: String) {
        this.environment = if (environment.isEmpty()) REST_ENVIRONMENT else environment
        saveValue(ENVIRONMENT_KEY, environment)
        restButton.alpha = 0.25f
        acceptanceButton.alpha = 0.25f
        testButton.alpha = 0.25f
        when (environment) {
            REST_ENVIRONMENT -> restButton.alpha = 1f
            ACCEPTANCE_ENVIRONMENT -> acceptanceButton.alpha = 1f
            TEST_ENVIRONMENT -> testButton.alpha = 1f
        }
    }

    private fun getBaseUrl(): String {
        loginBaseUrl = protocol + environment + url
        return loginBaseUrl
    }

    private fun configLoginButton() {
        loginButton.setOnClickListener {
            sampleRetrofit.createRetrofit(getBaseUrl())
            saveValue(USERNAME_KEY, usernameEditText.text.toString())
            saveValue(PASSWORD_KEY, passwordEditText.text.toString())
            progressBarLayout.visibility = View.VISIBLE
            compositeDisposable.add(
                sampleRetrofit.postOAuthToken(usernameEditText.text.toString(), passwordEditText.text.toString())
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({oauthToken ->
//                        Toast.makeText(this, "${oauthToken.accessToken}", Toast.LENGTH_SHORT).show()
                        accessToken = oauthToken.accessToken
                        tokenTextView.text = accessToken
                        progressBarLayout.visibility = View.GONE
                    }, {
                        Toast.makeText(this, "Login error", Toast.LENGTH_SHORT).show()
                        progressBarLayout.visibility = View.GONE
                    })
            )
        }
    }

    private fun configPermissionsButton() {
        permissionsButton.setOnClickListener {
            checkPermissions()
        }
    }

    private fun configDemoButton() {
        demoButton.setOnClickListener {
//            saveValue(CAMERA_KEY, cameraEditText.text.toString())
//            val cameraId = cameraEditText.text.toString()
            val intent = Intent(this, DemoActivity::class.java)
            intent.putExtra(DemoActivity.ACCESS_TOKEN, accessToken)
//            intent.putExtra(DemoActivity.CAMERA_ID, cameraId)
            startActivity(intent)
        }
    }

    private fun configTitleDemo() {
        versionTextView.text = BuildConfig.VERSION_NAME
    }

    private fun checkPermissions() {
        val permissionList: MutableList<String> = ArrayList()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PermissionChecker.PERMISSION_DENIED) {
            permissionList.add(Manifest.permission.RECORD_AUDIO)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PermissionChecker.PERMISSION_DENIED) {
            permissionList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (permissionList.size > 0) {
            requestPermissions(permissionList)
        }
    }

    private fun requestPermissions(permissionList: List<String>) {
        val permissions = permissionList.toTypedArray()
        ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE)
    }

    private fun loadValues() {
        setEnvironment(loadValue(ENVIRONMENT_KEY, REST_ENVIRONMENT))
        usernameEditText.setText(loadValue(USERNAME_KEY))
        passwordEditText.setText(loadValue(PASSWORD_KEY))
//        cameraEditText.setText(loadValue(CAMERA_KEY))
    }

    private fun saveValue(key: String, value: String) {
        val sharedPref = getPreferences(Context.MODE_PRIVATE) ?: return
        with (sharedPref.edit()) {
            putString(key, value)
            apply()
        }
    }

    private fun loadValue(key: String, defaultValue: String = ""): String {
        val sharedPref = getPreferences(Context.MODE_PRIVATE) ?: return ""
        return sharedPref.getString(key, defaultValue)!!
    }

}