package com.cameramanager.mobile_sdk_sample.impl

import android.content.Context
import android.widget.Toast
import com.cameramanager.mobile_sdk.camera_core.data.Device
import com.cameramanager.mobile_sdk.camera_core.error.MobileSdkError
import com.cameramanager.mobile_sdk.sniffer.CameraSnifferListener

class CameraSnifferListenerImpl(
    private val context: Context
) : CameraSnifferListener {

    override fun onFound(camera: Device?) {
        Toast.makeText(context, "onFound:: $camera", Toast.LENGTH_SHORT).show()
    }

    override fun onLost(camera: Device?) {
        Toast.makeText(context, "onLost:: $camera", Toast.LENGTH_SHORT).show()
    }

    override fun onFoundManually(device: Device?) {
        Toast.makeText(context, "onFoundManually:: $device", Toast.LENGTH_SHORT).show()
    }

    override fun onError(error: MobileSdkError?) {
        Toast.makeText(context, "onError:: $error", Toast.LENGTH_SHORT).show()
    }

}