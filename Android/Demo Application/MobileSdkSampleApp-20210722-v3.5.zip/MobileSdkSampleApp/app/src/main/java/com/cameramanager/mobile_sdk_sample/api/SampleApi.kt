package com.cameramanager.mobile_sdk_sample.api

import io.reactivex.Single
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.Header
import retrofit2.http.POST

interface SampleApi {

    @FormUrlEncoded
    @POST("oauth/token")
    fun loginUser(
        @Header("Authorization") basicToken: String,
        @Field("username") user: String,
        @Field("password") pass: String,
        @Field("grant_type") grant_type: String,
        @Field("scope") scope: String
    ): Single<OAuthToken>

    @POST("oauth/token?grant_type=client_credentials&scope=write")
    fun loginDevice(): Single<OAuthToken>

    @FormUrlEncoded
    @POST("oauth/token")
    fun refreshToken(
        @Field("refresh_token") refreshToken: String,
        @Field("grant_type") grant_type: String,
        @Field("scope") scope: String
    ): Single<OAuthToken>


}