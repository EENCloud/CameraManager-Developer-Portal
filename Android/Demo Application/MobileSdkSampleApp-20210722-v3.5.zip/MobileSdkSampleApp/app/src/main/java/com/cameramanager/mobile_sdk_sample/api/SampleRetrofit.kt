package com.cameramanager.mobile_sdk_sample.api

import android.text.TextUtils
import com.google.gson.GsonBuilder
import io.reactivex.Single
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.net.MalformedURLException
import java.net.URL
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLSession

class SampleRetrofit {

    companion object {
        const val BASIC_AUTH = "Basic SU9TLWUwNzBkNTQ5Y2MzY2YxNWU2YjBlMjc5ZjY4NWVhYzM2ZGQxMTc4NGY1NzE0ZjBjMjJiN2EzZjU3NDdiYmFkMjQ6SU9T"
    }

    private lateinit var sampleApi: SampleApi


    fun createRetrofit(baseUrl: String) {
        require(!TextUtils.isEmpty(baseUrl)) { "baseUrl cannot be empty" }
        val retrofitBuilder =
            Retrofit.Builder().addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ").create()))
                .baseUrl(baseUrl)
        retrofitBuilder.client(createClient(baseUrl))
        sampleApi = retrofitBuilder.build().create(SampleApi::class.java)
    }

    fun postOAuthToken(username: String, password: String): Single<OAuthToken> {
        return sampleApi.loginUser(BASIC_AUTH, username, password, "password", "write")
    }





    private fun createClient(baseUrl: String, timeout: Long = 60000, debugEnabled: Boolean = true): OkHttpClient {
        val clientBuilder = OkHttpClient.Builder()
            .connectTimeout(timeout, TimeUnit.MILLISECONDS)
            .writeTimeout(timeout, TimeUnit.MILLISECONDS)
            .readTimeout(timeout, TimeUnit.MILLISECONDS)
        addHostnameVerifier(clientBuilder, baseUrl)
//        addHeaderInterceptor(authorizationType, clientBuilder)
        if (debugEnabled) {
            clientBuilder.addInterceptor(getLoggingInterceptor())
        }
//        enableTls12OnPreLollipop(clientBuilder)
        return clientBuilder.build()
    }

    private fun addHostnameVerifier(builder: OkHttpClient.Builder, baseUrl: String) {
        builder.hostnameVerifier { hostname: String, sslSession: SSLSession ->
            verifyHostname(hostname, sslSession, baseUrl)
        }
    }

    private fun verifyHostname(hostname: String, session: SSLSession, baseUrl: String): Boolean {
        return try {
            hostname == URL(baseUrl).host
        } catch (ex: MalformedURLException) {
            false
        }
    }

//    private fun addHeaderInterceptor(authorizationType: AuthorizationType, clientBuilder: OkHttpClient.Builder) {
//        clientBuilder.addInterceptor(HeaderInterceptor(authorizationType))
//    }

    private fun getLoggingInterceptor(): Interceptor {
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = HttpLoggingInterceptor.Level.BASIC
        return loggingInterceptor
    }

}