package com.cameramanager.mobile_sdk_sample.api

import com.google.gson.annotations.SerializedName

class OAuthToken(
    @SerializedName("access_token")
    var accessToken: String,
    @SerializedName("refresh_token")
    var refreshToken: String,
    @SerializedName("token_type")
    var tokenType: String,
    @SerializedName("expires_in")
    var expiresIn: Int,
    var scope: String
)

/*
{
    "access_token": "d1ebb771-8677-4227-981a-36af91d3a42d:10001",
    "token_type": "bearer",
    "refresh_token": "02855eb5-4570-4a23-a3a7-6a704974a9d2:10001",
    "expires_in": 43199,
    "scope": "write"
}
 */