package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.prepare;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.wizard.Screen;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenFragment;

public class PrepareFragment extends ScreenFragment
{

	public static PrepareFragment newInstance()
	{
		return new PrepareFragment();
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		return inflater.inflate( R.layout.fragment_prepare, container, false );
	}

	public void onDataReady()
	{
		if ( isAdded() && getView() != null )
		{
			_screenChangeListener.changeScreen( Screen.AccessPoint );
		}
	}
}
