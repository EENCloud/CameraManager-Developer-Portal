package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.wifi.list;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.cameramanager.mobile_sdk.nubo.network.api.camera.model.WifiNetwork;
import com.cameramanager.mobile_sdk_v2_sample.R;

/**
 * Created by Dragos-Daniel Dit on 14.02.2018.
 */

public class WifiHolder extends RecyclerView.ViewHolder
{

	private TextView _textView;

	public WifiHolder( View itemView )
	{
		super( itemView );
		_textView = itemView.findViewById( R.id.access_point_view );
	}

	public void bind( WifiNetwork wifiNetwork )
	{
		_textView.setText( wifiNetwork.getEssid() );
	}
}
