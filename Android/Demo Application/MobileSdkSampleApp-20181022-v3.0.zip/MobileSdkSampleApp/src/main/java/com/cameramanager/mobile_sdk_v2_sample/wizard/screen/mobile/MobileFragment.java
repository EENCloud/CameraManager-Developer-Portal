package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.mobile;

import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.cameramanager.mobile_sdk.nubo.network.api.camera.model.AccessPointName;
import com.cameramanager.mobile_sdk.nubo.network.api.camera.model.Carrier;
import com.cameramanager.mobile_sdk.nubo.wizard.pair.configuration.MobileSetupOption;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.wizard.consumer.ItemConsumer;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenFragment;

import java.util.ArrayList;
import java.util.List;

public class MobileFragment extends ScreenFragment
{
	private static final String CARRIER_LIST = "CarrierList";
	private static final String MOBILE_OPTION = "MobileOption";
	private List< Carrier > _carrierList;
	private ItemConsumer< AccessPointName > _apnItemConsumer;
	@MobileSetupOption
	private int _mobileOption;
	private Switch _manualSwitch;

	public static MobileFragment newInstance( @MobileSetupOption int mobileOption, ArrayList< Carrier > carrierList )
	{
		final MobileFragment mobileFragment = new MobileFragment();
		final Bundle bundle = new Bundle();
		bundle.putInt( MOBILE_OPTION, mobileOption );
		bundle.putParcelableArrayList( CARRIER_LIST, carrierList );
		mobileFragment.setArguments( bundle );
		return mobileFragment;
	}

	@Override
	public void onCreate( @Nullable Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		_mobileOption = getArguments().getInt( MOBILE_OPTION );
		_carrierList = getArguments().getParcelableArrayList( CARRIER_LIST );
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		View rootView = inflater.inflate( R.layout.fragment_mobile, container, false );
		initViews( rootView );
		return rootView;
	}

	@Override
	public void onPause()
	{
		super.onPause();
		hideLoadingAnimation();
	}

	public MobileFragment setApnItemConsumer( ItemConsumer< AccessPointName > apnItemConsumer )
	{
		_apnItemConsumer = apnItemConsumer;
		return this;
	}

	private void initViews( View rootView )
	{

		if ( _mobileOption == MobileSetupOption.PinRequired )
		{
			initLockedViews( rootView );
		}
		else
		{
			initCarrierViews( rootView );
		}
	}

	private void initLockedViews( View rootView )
	{
		setViews( rootView, R.drawable.ic_network_locked, "Sim card is locked", "Go back", v -> getActivity().onBackPressed() );
	}

	private void initCarrierViews( View rootView )
	{
		_manualSwitch = rootView.findViewById( R.id.manual_switch );
		_manualSwitch.setOnCheckedChangeListener( ( buttonView, isChecked ) -> onSwitchChecked( isChecked ) );

		if ( _carrierList.size() > 0 )
		{
			setViews( rootView, R.drawable.ic_signal_cellular_4_bar, _carrierList.get( 0 ).getName(), "Connect", v -> onConnectClick() );
			_manualSwitch.setChecked( false );
		}
		else
		{
			onSwitchChecked( true );
			_manualSwitch.setChecked( true );
			_manualSwitch.setEnabled( false );
		}
	}

	private void setViews( View rootView, @DrawableRes int drawableId, String text, String text2, View.OnClickListener onClickListener )
	{
		( (ImageView) rootView.findViewById( R.id.network_view ) ).setImageResource( drawableId );
		( (TextView) rootView.findViewById( R.id.carrier_view ) ).setText( text );
		TextView buttonTextView = rootView.findViewById( R.id.btn_yes );
		buttonTextView.setText( text2 );
		buttonTextView.setOnClickListener( onClickListener );
	}

	private void onConnectClick()
	{
		showLoadingAnimation();
		if ( _manualSwitch.isChecked() )
		{
			_apnItemConsumer.accept( getApnFromManual() );
		}
		else if ( _carrierList.size() > 0 && _carrierList.get( 0 ).getAccessPointNames().length > 0 )
		{
			_apnItemConsumer.accept( _carrierList.get( 0 ).getAccessPointNames()[0] );
		}
		else
		{
			onSwitchChecked( true );
			_manualSwitch.setChecked( true );
			_manualSwitch.setEnabled( false );
		}
	}

	private void showLoadingAnimation()
	{
		getView().findViewById( R.id.network_view ).setVisibility( View.GONE );
		getView().findViewById( R.id.progress_bar ).setVisibility( View.VISIBLE );
	}

	private void hideLoadingAnimation()
	{
		getView().findViewById( R.id.progress_bar ).setVisibility( View.GONE );
		getView().findViewById( R.id.network_view ).setVisibility( View.VISIBLE );
	}

	private AccessPointName getApnFromManual()
	{
		final EditText apnEditText = getView().findViewById( R.id.apn_edit_text );
		final EditText usernameEditText = getView().findViewById( R.id.username_edit_text );
		final EditText passwordEditText = getView().findViewById( R.id.password_edit_text );
		return new AccessPointName( apnEditText.getText().toString(), usernameEditText.getText().toString(), passwordEditText.getText().toString() );
	}

	private void onSwitchChecked( boolean checked )
	{
		if ( checked )
		{
			getView().findViewById( R.id.carrier_view ).setVisibility( View.INVISIBLE );
			getView().findViewById( R.id.apn_layout ).setVisibility( View.VISIBLE );
			getView().findViewById( R.id.username_layout ).setVisibility( View.VISIBLE );
			getView().findViewById( R.id.password_layout ).setVisibility( View.VISIBLE );
		}
		else
		{
			getView().findViewById( R.id.apn_layout ).setVisibility( View.INVISIBLE );
			getView().findViewById( R.id.username_layout ).setVisibility( View.INVISIBLE );
			getView().findViewById( R.id.password_layout ).setVisibility( View.INVISIBLE );
			getView().findViewById( R.id.carrier_view ).setVisibility( View.VISIBLE );
		}
	}

}
