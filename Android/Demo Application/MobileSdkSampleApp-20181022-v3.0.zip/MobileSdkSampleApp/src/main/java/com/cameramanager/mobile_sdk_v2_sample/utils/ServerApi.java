package com.cameramanager.mobile_sdk_v2_sample.utils;

import com.cameramanager.mobile_sdk.network_provider.recordings.model.LiveStream;
import com.cameramanager.mobile_sdk.network_provider.recordings.model.Recording;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableCamera;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableRecording;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableZone;

import java.util.List;

import io.reactivex.Single;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ServerApi
{

	@GET( "cameras" )
	Single< List< AvailableCamera > > getCameras();

	@GET( "zones" )
	Single< List< AvailableZone > > getZones();

	@GET( "cameras/{cameraId}/streams" )
	Single< List< LiveStream > > getStreams( @Path( "cameraId" ) long cameraId );

	@GET( "cameras/{cameraId}/recordings" )
	Single< List< AvailableRecording > > getRecordings( @Path( "cameraId" ) long cameraId );

	@GET( "cameras/{cameraId}/recordings/{recordingId}" )
	Single< Recording > getRecording( @Path( "cameraId" ) long cameraId, @Path( "recordingId" ) long recordingId );

}
