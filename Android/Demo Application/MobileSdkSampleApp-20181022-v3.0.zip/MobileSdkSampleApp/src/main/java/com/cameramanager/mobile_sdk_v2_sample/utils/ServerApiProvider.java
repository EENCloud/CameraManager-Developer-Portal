package com.cameramanager.mobile_sdk_v2_sample.utils;

import com.cameramanager.mobile_sdk.network_provider.NetworkUtils;
import com.cameramanager.mobile_sdk.network_provider.RetrofitFactory;
import com.cameramanager.mobile_sdk.network_provider.recordings.StreamService;
import com.cameramanager.mobile_sdk.network_provider.recordings.StreamServiceImpl;
import com.cameramanager.mobile_sdk.network_provider.recordings.model.Recording;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableCamera;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableRecording;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableZone;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;

/**
 * Created by Art Vynogradov on 10/12/18.
 */
public enum ServerApiProvider
{

	INSTANCE;

	private ServerApi _api;

	public void init( String baseUrl, String accessToken )
	{
		Retrofit retrofit = RetrofitFactory.getRetrofit( baseUrl, NetworkUtils.getTokenAuthorization( accessToken ) );
		_api = retrofit.create( ServerApi.class );
	}

	public Single< List< AvailableCamera > > getAvailableCameras()
	{
		return _api.getCameras().subscribeOn( Schedulers.io() );
	}

	public Single< List< AvailableZone > > getAvailableZones()
	{
		return _api.getZones().subscribeOn( Schedulers.io() );
	}

	public Single< List< AvailableRecording > > getAvailableFootage( long cameraId )
	{
		return _api.getRecordings( cameraId ).subscribeOn( Schedulers.io() );
	}

}
