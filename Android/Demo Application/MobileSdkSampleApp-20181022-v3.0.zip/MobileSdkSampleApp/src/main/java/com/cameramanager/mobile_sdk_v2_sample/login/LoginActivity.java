package com.cameramanager.mobile_sdk_v2_sample.login;//package com.cameramanager.mobile_sdk_v2_sample.user_session;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.cameramanager.mobile_sdk_v2_sample.R;

public class LoginActivity extends AppCompatActivity
{

	@Override
	protected void onCreate( @Nullable Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setContentView( R.layout.activity_login );

		LoginFragment loginFragment = (LoginFragment) getSupportFragmentManager().findFragmentByTag( LoginFragment.TAG );
		if ( loginFragment == null )
		{
			loginFragment = LoginFragment.newInstance();
		}
		getSupportFragmentManager().beginTransaction().replace( R.id.container_fragment_login, loginFragment ).commit();
	}

}
