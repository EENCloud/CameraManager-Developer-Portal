package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.zone;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cameramanager.mobile_sdk.camera_core.error.MobileSdkError;
import com.cameramanager.mobile_sdk.camera_core.util.Log;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableZone;
import com.cameramanager.mobile_sdk_v2_sample.token.AccessTokenManager;
import com.cameramanager.mobile_sdk_v2_sample.utils.ServerApiProvider;
import com.cameramanager.mobile_sdk_v2_sample.wizard.consumer.ItemConsumer;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenFragment;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;

public class ZoneListFragment extends ScreenFragment
{

	private ZoneAdapter _adapter;
	private ItemConsumer< AvailableZone > _zoneItemConsumer;
	private Disposable _zoneListDisposable;

	public static ZoneListFragment newInstance()
	{
		return new ZoneListFragment();
	}

	@Override
	public void onCreate( @Nullable Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		// Inflate the layout for this fragment
		final View rootView = inflater.inflate( R.layout.fragment_zone_list, container, false );

		final RecyclerView recyclerView = rootView.findViewById( R.id.recycler_view );

		_adapter = new ZoneAdapter( _zoneItemConsumer );
		recyclerView.setAdapter( _adapter );
		recyclerView.setLayoutManager( new LinearLayoutManager( getActivity() ) );

		return rootView;
	}

	@Override
	public void onResume()
	{
		super.onResume();
		dispose();
		_zoneListDisposable = ServerApiProvider.INSTANCE.getAvailableZones().observeOn( AndroidSchedulers.mainThread() ).subscribe( _adapter::setData, this::onError );
	}

	private void onError( Throwable throwable )
	{
		Log.e( "ZoneList", "getZoneListError: ", throwable );
	}

	@Override
	public void onPause()
	{
		super.onPause();
		dispose();
	}

	private void dispose()
	{
		if ( _zoneListDisposable != null && !_zoneListDisposable.isDisposed() )
		{
			_zoneListDisposable.dispose();
		}
	}

	private String getAccessToken() throws MobileSdkError
	{
		return AccessTokenManager.INSTANCE.getAccessTokenProvider().getAccessToken();
	}

	public ZoneListFragment setZoneItemConsumer( ItemConsumer< AvailableZone > zoneItemConsumer )
	{
		_zoneItemConsumer = zoneItemConsumer;
		return this;
	}
}
