package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.accesspoint;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cameramanager.mobile_sdk.nubo.network.connectivity.model.NuboCamWifiAccessPoint;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.wizard.consumer.ItemConsumer;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenFragment;

import java.util.ArrayList;
import java.util.List;


public class AccessPointFragment extends ScreenFragment
{

	public static final String ACCESS_POINTS = "AccessPoints";
	private List<NuboCamWifiAccessPoint> _accessPointList;
	private AccessPointAdapter _accessPointAdapter;
	private ItemConsumer<NuboCamWifiAccessPoint> _accessPointConsumer;

	public static AccessPointFragment newInstance( ArrayList<NuboCamWifiAccessPoint> list )
	{
		final AccessPointFragment accessPointFragment = new AccessPointFragment();
		final Bundle args = new Bundle();
		args.putParcelableArrayList( ACCESS_POINTS, list );
		accessPointFragment.setArguments( args );
		return accessPointFragment;
	}

	@Override
	public void onCreate( @Nullable Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		_accessPointList = getArguments().getParcelableArrayList( ACCESS_POINTS );
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		// Inflate the layout for this fragment
		final View rootView = inflater.inflate( R.layout.fragment_access_point, container, false );

		final RecyclerView recyclerView = rootView.findViewById( R.id.recycler_view );

		_accessPointAdapter = new AccessPointAdapter( _accessPointList, _accessPointConsumer );
		recyclerView.setAdapter( _accessPointAdapter );
		recyclerView.setLayoutManager( new LinearLayoutManager( getActivity() ) );

		return rootView;
	}

	public void setData( List<NuboCamWifiAccessPoint> accessPointList )
	{
		_accessPointAdapter.setData( accessPointList );
	}

	public AccessPointFragment setAccessPointConsumer( ItemConsumer<NuboCamWifiAccessPoint> accessPointConsumer )
	{
		_accessPointConsumer = accessPointConsumer;
		return this;
	}
}
