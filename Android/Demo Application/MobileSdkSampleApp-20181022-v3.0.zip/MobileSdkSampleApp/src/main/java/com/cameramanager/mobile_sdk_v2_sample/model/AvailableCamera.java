package com.cameramanager.mobile_sdk_v2_sample.model;

import com.google.gson.annotations.SerializedName;

public class AvailableCamera
{

	@SerializedName( "cameraId" )
	private int _id;
	@SerializedName( "name" )
	private String _name;

	public int getId()
	{
		return _id;
	}

	public String getName()
	{
		return _name;
	}

}
