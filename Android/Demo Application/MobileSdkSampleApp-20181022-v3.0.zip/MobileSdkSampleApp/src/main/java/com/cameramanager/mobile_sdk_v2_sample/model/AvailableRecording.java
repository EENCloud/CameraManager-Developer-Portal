package com.cameramanager.mobile_sdk_v2_sample.model;

import com.google.gson.annotations.SerializedName;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AvailableRecording
{

	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss", Locale.US );

	@SerializedName( "recordingId" )
	private long _id;
	@SerializedName( "startTime" )
	private Date _startTime;
	@SerializedName( "endTime" )
	private Date _endTime;

	public long getId()
	{
		return _id;
	}

	public Date getStartTime()
	{
		return _startTime;
	}

	public String getStartTimeDisplay()
	{
		return DATE_FORMAT.format( _startTime );
	}

	public Date getEndTime()
	{
		return _endTime;
	}

	public String getEndTimeDisplay()
	{
		if ( _endTime != null )
		{
			return DATE_FORMAT.format( _endTime );
		}
		else
		{
			return "";
		}
	}
}
