package com.cameramanager.mobile_sdk_v2_sample.sniff_cameras;

import com.cameramanager.mobile_sdk.camera_core.data.Address;
import com.cameramanager.mobile_sdk.camera_core.data.Device;
import com.cameramanager.mobile_sdk.camera_core.data.DeviceModelInfo;

class SniffedDevice extends Device
{

	private boolean _isAdding;
	private boolean _isAlreadyAdded;

	SniffedDevice( Device device )
	{
		this( device.getAddress(), device.getDeviceModelInfo(), device.getTypeId() );
	}

	SniffedDevice( Address address, DeviceModelInfo deviceModelInfo, long typeId )
	{
		super( address, deviceModelInfo, typeId );
	}

	boolean isAdding()
	{
		return _isAdding;
	}

	void setAdding( boolean isAdding )
	{
		_isAdding = isAdding;
	}

	boolean isAlreadyAdded()
	{
		return _isAlreadyAdded;
	}

	void setAlreadyAdded( boolean alreadyAdded )
	{
		_isAlreadyAdded = alreadyAdded;
	}

}
