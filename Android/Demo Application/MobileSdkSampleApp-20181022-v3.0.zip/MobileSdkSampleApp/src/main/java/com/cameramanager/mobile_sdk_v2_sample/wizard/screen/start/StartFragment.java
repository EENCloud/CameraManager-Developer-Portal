package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.start;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.wizard.Screen;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenFragment;

public class StartFragment extends ScreenFragment
{

	public static StartFragment newInstance()
	{
		return new StartFragment();
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		// Inflate the layout for this fragment
		View rootView = inflater.inflate( R.layout.fragment_start, container, false );
		rootView.findViewById( R.id.btn_yes ).setOnClickListener( v -> _screenChangeListener.changeScreen( Screen.Zone ) );
		return rootView;
	}

}
