package com.cameramanager.mobile_sdk_v2_sample.wizard;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.cameramanager.mobile_sdk_v2_sample.wizard.Screen.*;
import static com.cameramanager.mobile_sdk_v2_sample.wizard.Screen.Error;

/**
 * Created by DragosD on 14-Feb-18.
 */
@IntDef( { Start, AccessPoint, Pair, Error, Success, Wifi, Prepare, Name, WifiPassword, Zone, Mobile } )
@Retention( RetentionPolicy.SOURCE )
public @interface Screen
{
	int Start = 0;
	int Prepare = 1;
	int AccessPoint = 2;
	int Pair = 3;
	int Wifi = 4;
	int Error = 5;
	int Success = 6;
	int Name = 7;
	int WifiPassword = 8;
	int Zone = 9;
	int Mobile = 10;

}
