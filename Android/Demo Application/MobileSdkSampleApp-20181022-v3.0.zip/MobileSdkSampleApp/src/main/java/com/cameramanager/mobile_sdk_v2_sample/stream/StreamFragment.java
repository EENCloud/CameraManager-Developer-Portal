package com.cameramanager.mobile_sdk_v2_sample.stream;

import android.app.ActionBar;
import android.content.pm.ActivityInfo;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import com.cameramanager.mobile_sdk.camera_core.error.MobileSdkError;
import com.cameramanager.mobile_sdk.camera_core.util.Log;
import com.cameramanager.mobile_sdk.streamer.CameraStreamer;
import com.cameramanager.mobile_sdk.streamer.CameraStreamerListener;
import com.cameramanager.mobile_sdk.streamer.StreamerItem;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.utils.C;
import com.cameramanager.mobile_sdk_v2_sample.utils.UiUtils;
import com.cameramanager.mobile_sdk_v2_sample.token.AccessTokenManager;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.disposables.CompositeDisposable;

public class StreamFragment extends Fragment
{

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Constants
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	public static final String TAG = "StreamFragment";

	private final float[] SPEED_RATES = new float[]{ 1f, 2f, 5f, 10f };

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Static
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	public static StreamFragment newInstance( long cameraId, long recId )
	{
		Bundle args = new Bundle();
		args.putLong( C.EXTRA_CAMERA_ID, cameraId );
		args.putLong( C.EXTRA_REC_ID, recId );

		StreamFragment fragment = new StreamFragment();
		fragment.setArguments( args );
		return fragment;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Fields
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	@BindView( R.id.layout_stream_fragment )
	ConstraintLayout _rootLayout;

	@BindView( R.id.player_texture_view )
	TextureView _playerTextureView;

	@BindView( R.id.btn_play_pause )
	ImageView _btnPlayPause;
	@BindView( R.id.seek_footage )
	SeekBar _seekBarFootage;
	@BindView( R.id.btn_fullscreen )
	ImageView _btnFullscreen;

	@BindView( R.id.btn_prev_frame )
	ImageView _btnPrevFrame;
	@BindView( R.id.btn_next_frame )
	ImageView _btnNextFrame;
	@BindView( R.id.text_speed )
	TextView _textSpeed;

	private SurfaceTexture _streamSurfaceTexture;
	private Surface _surface;

	private long _cameraId;
	private long _recId;

	private int _currentSpeedRateIndex = 0;

	private boolean _playing;
	private AtomicBoolean _isFullscreen = new AtomicBoolean();

	private final ExecutorService _bgThreadExecutor = Executors.newSingleThreadExecutor();

	private ConditionVariable _isCameraStreamerReady = new ConditionVariable();
	private CameraStreamer _cameraStreamer;
	private CameraStreamerListener _cameraStreamerListener = new CameraStreamerListener()
	{
		@Override
		public void onStatusChanged( CameraStreamer.CameraStreamerStatus cameraStreamerStatus )
		{

		}

		@Override
		public void onPlaybackStateChanged( CameraStreamer.CameraStreamerPlaybackState state )
		{
			switch ( state )
			{
				case Buffering:
					togglePlayPauseBtn( false );
					break;

				case Playing:
					Log.d( TAG, "CameraStreamerListener::onStarted()" );
					togglePlayPauseBtn( true );
					if ( getActivity() != null && !_seekBarFootage.isSelected() )
					{
						getActivity().runOnUiThread( () -> {
							int progress = (int) ( _cameraStreamer.getCurrentTime() );
							_seekBarFootage.setProgress( progress );
						} );
					}
					break;

				case Paused:
					togglePlayPauseBtn( false );
					break;

				case Ended:
					break;
			}
		}

		@Override
		public void onCurrentItemStatusChanged( StreamerItem.StreamerItemStatus status )
		{
			switch ( status )
			{
				case Ready:
					setupSeekFootage();
					break;
				case Unknown:
					break;
				case Failed:
					break;
			}
		}

		@Override
		public void onCurrentItemDurationChanged( long newDuration )
		{
			setFootageDuration(newDuration);
		}

		@Override
		public void onSnapshotTaken( byte[] bytes, long l )
		{

		}
	};

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Public methods
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setRetainInstance( true );

		_cameraId = getArguments().getLong( C.EXTRA_CAMERA_ID, -1L );
		_recId = getArguments().getLong( C.EXTRA_REC_ID, -1L );

		Log.d( TAG, "onCreate()::Camera ID = " + _cameraId + "; Rec ID = " + _recId );
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		final View rootView = inflater.inflate( R.layout.fragment_stream, container, false );
		Log.d( TAG, "onCreateView()::About to init views" );
		ButterKnife.bind( this, rootView );

		setupPlayPauseRoutine();
		setupFullscreenRoutine();

		configureTextureView();
		initSeekBarFootage();

		return rootView;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////
	//
	// Private methods
	//
	///////////////////////////////////////////////////////////////////////////////////////////////

	private void setupPlayPauseRoutine()
	{
		_btnPlayPause.setEnabled( false );
		_btnPlayPause.setOnClickListener( v -> playPause() );
	}

	private void playPause()
	{
		if ( _playing )
		{
			pauseVideo();
		}
		else
		{
			playVideo();
		}
	}

	private void togglePlayPauseBtn( boolean playing )
	{
		if ( playing == _playing )
		{
			return;
		}
		_playing = playing;

		getActivity().runOnUiThread( () -> {
			if ( _playing )
			{
				// state transition: PAUSE -> PLAY
				_btnPlayPause.setImageResource( R.drawable.pause_play_animated_vector );

			}
			else
			{
				// state transition: PLAY -> PAUSE
				_btnPlayPause.setImageResource( R.drawable.play_pause_animated_vector );
			}

			Drawable animation = _btnPlayPause.getDrawable();
			if ( animation instanceof Animatable )
			{
				( (Animatable) animation ).start();
			}
		} );
	}

	private void playVideo()
	{
		_bgThreadExecutor.execute( () -> {
			_isCameraStreamerReady.block();

			setupSeekFootage();

			_cameraStreamer.setRate( CameraStreamer.NATURAL_SPEED_RATE );
		} );
	}

	private void pauseVideo()
	{
		_bgThreadExecutor.execute( () -> {
			_isCameraStreamerReady.block();
			_cameraStreamer.setRate( CameraStreamer.PAUSE_SPEED_RATE );
		} );
	}

	private void setupSeekFootage()
	{
		setFootageDuration( _cameraStreamer.getStreamerItem().getDuration() );
	}

	private void setFootageDuration( long footageDuration )
	{
		_seekBarFootage.setProgress( (int) _cameraStreamer.getCurrentTime() );
		_seekBarFootage.setMax( (int) footageDuration );
	}

	private void setupFullscreenRoutine()
	{
		_btnFullscreen.setEnabled( false );
		_btnFullscreen.setOnClickListener( v -> toggleFullscreen() );
	}

	private void toggleFullscreen()
	{
		if ( _isFullscreen.getAndSet( false ) )
		{
			// state transition: FULLSCREEN -> WINDOWED
			getActivity().setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_PORTRAIT );
			ActionBar actionBar = getActivity().getActionBar();
			if ( actionBar != null )
			{
				actionBar.show();
			}
			return;
		}

		if ( !_isFullscreen.getAndSet( true ) )
		{
			// state transition: WINDOWED -> FULLSCREEN
			getActivity().setRequestedOrientation( ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE );
			ActionBar actionBar = getActivity().getActionBar();
			if ( actionBar != null )
			{
				actionBar.hide();
			}
		}
	}

	private void configureTextureView()
	{
		_playerTextureView.setSurfaceTextureListener( new TextureView.SurfaceTextureListener()
		{
			@Override
			public void onSurfaceTextureAvailable( final SurfaceTexture surfaceTexture, final int width, final int height )
			{
				Log.d( TAG, "onSurfaceTextureAvailable()::" + width + "x" + height );

				_streamSurfaceTexture = surfaceTexture;
				_surface = new Surface( _streamSurfaceTexture );

				playStream();
			}

			@Override
			public void onSurfaceTextureSizeChanged( final SurfaceTexture surface, final int width, final int height )
			{
				Log.d( TAG, "onSurfaceTextureSizeChanged()::" + width + "x" + height );
			}

			@Override
			public boolean onSurfaceTextureDestroyed( final SurfaceTexture surface )
			{
				Log.d( TAG, "onSurfaceTextureDestroyed()" );
				return false;
			}

			@Override
			public void onSurfaceTextureUpdated( final SurfaceTexture surface )
			{

			}
		} );
	}

	private void initSeekBarFootage()
	{
		_seekBarFootage.setOnSeekBarChangeListener( new SeekBar.OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged( SeekBar seekBar, int progress, boolean fromUser )
			{
				Log.d( TAG, "onProgressChanged()::New = " + progress );
			}

			@Override
			public void onStartTrackingTouch( SeekBar seekBar )
			{
				Log.d( TAG, "onStartTrackingTouch()::" );
				_cameraStreamer.setRate( CameraStreamer.PAUSE_SPEED_RATE );
			}

			@Override
			public void onStopTrackingTouch( SeekBar seekBar )
			{
				Log.d( TAG, "onStopTrackingTouch()::" );
				_cameraStreamer.seekTo( seekBar.getProgress() );
			}
		} );
	}

	private void playStream()
	{
		StreamerItem streamerItem;
		if ( _recId < 0 )
		{
			// LIVE
			streamerItem = StreamerItem.createItem( _cameraId );
			_seekBarFootage.setVisibility( View.GONE );
			_btnPrevFrame.setVisibility( View.GONE );
			_btnNextFrame.setVisibility( View.GONE );
			_textSpeed.setVisibility( View.GONE );
		}
		else
		{
			// FOOTAGE
			streamerItem = StreamerItem.createItem( _cameraId, _recId );
			_seekBarFootage.setVisibility( View.VISIBLE );
			_btnPrevFrame.setVisibility( View.VISIBLE );
			_btnNextFrame.setVisibility( View.VISIBLE );
			_textSpeed.setVisibility( View.VISIBLE );
		}

		if ( _cameraStreamer != null )
		{
			_cameraStreamer.setStreamerItem( streamerItem );
			return;
		}

		_cameraStreamer = new CameraStreamer( getActivity(), _surface );
		_cameraStreamer.setCameraStreamerListener( _cameraStreamerListener );
		try
		{
			_cameraStreamer.setProvider( AccessTokenManager.INSTANCE.getAccessTokenProvider() );
		}
		catch ( MobileSdkError error )
		{
			throw new IllegalStateException( error.getGeneralMessage() + "::" + error.getDetailMessage() );
		}
		_cameraStreamer.setStreamerItem( streamerItem );

		_isCameraStreamerReady.open();

		// play automatically as soon as everything's ready
		playVideo();

		_btnPlayPause.setEnabled( true );
		_btnFullscreen.setEnabled( true );
	}

	@Override
	public void onPause()
	{
		super.onPause();
		Log.d( TAG, "onPause()" );

		stopVideo();

		if ( _surface != null && _surface.isValid() )
		{
			_surface.release();
		}
	}

	private void stopVideo()
	{
		_bgThreadExecutor.execute( () -> {
			_isCameraStreamerReady.block();
			_cameraStreamer.setRate( CameraStreamer.PAUSE_SPEED_RATE );
			_cameraStreamer.release();
		} );
	}

	@OnClick( R.id.btn_prev_frame )
	public void onPrevFrameClick()
	{
		_cameraStreamer.stepBy( -1 );
	}

	@OnClick( R.id.btn_next_frame )
	public void onNextFrameClick()
	{
		_cameraStreamer.stepBy( 1 );
	}

	@OnClick( R.id.text_speed )
	public void onSpeedClick()
	{
		++_currentSpeedRateIndex;
		if ( _currentSpeedRateIndex >= SPEED_RATES.length )
		{
			_currentSpeedRateIndex = 0;
		}
		_textSpeed.setText( String.format( Locale.US, "%dx", (int) SPEED_RATES[_currentSpeedRateIndex] ) );
		_cameraStreamer.setRate( SPEED_RATES[_currentSpeedRateIndex] );
	}

}
