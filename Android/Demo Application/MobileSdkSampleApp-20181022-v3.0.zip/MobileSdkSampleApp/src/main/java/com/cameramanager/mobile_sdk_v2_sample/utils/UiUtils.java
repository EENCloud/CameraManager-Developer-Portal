package com.cameramanager.mobile_sdk_v2_sample.utils;

import android.content.Context;
import android.support.design.widget.Snackbar;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

public class UiUtils
{

	private static Snackbar _snackbar;

	public static ProgressBar showProgress( Context context, ViewGroup rootView, String message )
	{
		ProgressBar progressBar = new ProgressBar( context, null, android.R.attr.progressBarStyleLarge );
		progressBar.setIndeterminate( true );
		progressBar.setVisibility( View.VISIBLE );

		if ( !( rootView instanceof FrameLayout ) )
		{
			return progressBar;
		}

		final FrameLayout.LayoutParams params = new FrameLayout.LayoutParams( ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT );
		params.gravity = Gravity.CENTER;
		rootView.addView( progressBar, params );

		_snackbar = Snackbar.make( rootView, message, Snackbar.LENGTH_INDEFINITE );
		_snackbar.show();

		return progressBar;
	}

	public static void hideProgress( ProgressBar progressBar, ViewGroup rootView )
	{
		if ( progressBar != null )
		{
			rootView.removeView( progressBar );
		}

		if ( _snackbar != null )
		{
			_snackbar.dismiss();
			_snackbar = null;
		}
	}

}
