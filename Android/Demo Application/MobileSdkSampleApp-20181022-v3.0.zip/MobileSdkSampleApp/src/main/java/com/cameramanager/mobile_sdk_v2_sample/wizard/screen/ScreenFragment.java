package com.cameramanager.mobile_sdk_v2_sample.wizard.screen;

import android.app.Fragment;
import android.content.Context;
import android.view.View;
import android.widget.ImageView;

import com.cameramanager.mobile_sdk_v2_sample.R;

/**
 * Created by DragosD on 14-Feb-18.
 */

public class ScreenFragment extends Fragment
{
	protected ScreenChangeListener _screenChangeListener;

	@Override
	public void onAttach( Context context )
	{
		super.onAttach( context );
		if ( context instanceof ScreenChangeListener )
		{
			_screenChangeListener = (ScreenChangeListener) context;
		} else
		{
			throw new RuntimeException( context.toString() + " must implement OnFragmentInteractionListener" );
		}
	}

	@Override
	public void onDetach()
	{
		super.onDetach();
		_screenChangeListener = null;
	}

	public ImageView getTransitionImageView()
	{
		final ImageView transitionImageView;
		final View rootView = getView();

		if ( rootView != null )
		{
			transitionImageView = rootView.findViewById( R.id.camera );
		} else
		{
			transitionImageView = null;
		}

		return transitionImageView;
	}
}
