package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.accesspoint;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.cameramanager.mobile_sdk.nubo.network.connectivity.model.NuboCamWifiAccessPoint;
import com.cameramanager.mobile_sdk_v2_sample.R;

/**
 * Created by Dragos-Daniel Dit on 14.02.2018.
 */

public class AccessPointHolder extends RecyclerView.ViewHolder
{

	private TextView _textView;

	public AccessPointHolder( View itemView )
	{
		super( itemView );
		_textView = itemView.findViewById( R.id.access_point_view );
	}

	public void bind( NuboCamWifiAccessPoint wifiAccessPoint )
	{
		_textView.setText( wifiAccessPoint.getEssid() );
	}
}
