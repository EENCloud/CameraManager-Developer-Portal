package com.cameramanager.mobile_sdk_v2_sample.wizard.screen;

import com.cameramanager.mobile_sdk_v2_sample.wizard.Screen;

/**
 * Created by DragosD on 14-Feb-18.
 */

public interface ScreenChangeListener
{
	void changeScreen( @Screen int screen );
}
