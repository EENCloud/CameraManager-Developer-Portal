package com.cameramanager.mobile_sdk_v2_sample.available_cameras;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableCamera;
import com.cameramanager.mobile_sdk_v2_sample.utils.ServerApiProvider;
import com.cameramanager.mobile_sdk_v2_sample.utils.UiUtils;
import com.cameramanager.mobile_sdk_v2_sample.footage.FootageActivity;
import com.cameramanager.mobile_sdk_v2_sample.stream.StreamActivity;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;

public class AvailableCamerasFragment extends Fragment
{

	public static final String TAG = "AvailableCamerasFragment";

	@BindView( R.id.layout_fragment_available_cameras )
	FrameLayout _rootLayout;
	@BindView( R.id.container_available_cameras )
	RecyclerView _addedCamerasContainer;

	private ProgressBar _progressBar;

	private boolean _isLiveStream;
	private List< AvailableCamera > _availableCameras;
	private AvailableCamerasAdapter _availableCamerasAdapter;

	private final CompositeDisposable _compositeDisposable = new CompositeDisposable();

	public static AvailableCamerasFragment newInstance( boolean isLiveStream )
	{
		AvailableCamerasFragment fragment = new AvailableCamerasFragment();
		Bundle args = new Bundle();
		args.putBoolean( "isLiveStream", isLiveStream );
		fragment.setArguments( args );
		return fragment;
	}

	@Override
	public void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setHasOptionsMenu( true );

		_isLiveStream = getArguments().getBoolean( "isLiveStream" );

		_availableCameras = new CopyOnWriteArrayList<>();
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		final View rootView = inflater.inflate( R.layout.fragment_available_cameras, container, false );
		ButterKnife.bind( this, rootView );

		_availableCamerasAdapter = new AvailableCamerasAdapter( getContext(), _availableCameras );
		_compositeDisposable.add( _availableCamerasAdapter.getItemClickObservable().subscribe( this::goToStreamFragment ) );

		_addedCamerasContainer.setHasFixedSize( true );
		_addedCamerasContainer.setLayoutManager( new LinearLayoutManager( getContext() ) );
		_addedCamerasContainer.setAdapter( _availableCamerasAdapter );

		_progressBar = UiUtils.showProgress( getActivity(), _rootLayout, getString( R.string.loading_cameras ) );

		requestAvailableCameras();

		return rootView;
	}

	private void goToStreamFragment( int cameraId )
	{
		Intent launchStreamActivity = _isLiveStream ? new Intent( getActivity(), StreamActivity.class ) : new Intent( getActivity(), FootageActivity.class );
		launchStreamActivity.putExtra( "cameraId", cameraId );
		startActivity( launchStreamActivity );
	}

	void requestAvailableCameras()
	{
		_availableCameras.clear();
		_availableCamerasAdapter.notifyDataSetChanged();

		_compositeDisposable.add( ServerApiProvider.INSTANCE.getAvailableCameras().observeOn( AndroidSchedulers.mainThread() ).subscribe( availableCameras -> {
			_availableCameras.clear();
			_availableCameras.addAll( availableCameras );

			_availableCamerasAdapter.notifyDataSetChanged();

			UiUtils.hideProgress( _progressBar, _rootLayout );
		}, throwable -> {
			UiUtils.hideProgress( _progressBar, _rootLayout );

			Snackbar.make( _rootLayout, "Failed to obtain available cameras: " + throwable.getMessage(), Snackbar.LENGTH_LONG ).show();
		} ) );
	}

	@Override
	public void onCreateOptionsMenu( Menu menu, MenuInflater inflater )
	{
		inflater.inflate( R.menu.menu_available_cameras, menu );
		super.onCreateOptionsMenu( menu, inflater );
	}

	@Override
	public boolean onOptionsItemSelected( MenuItem item )
	{
		int id = item.getItemId();

		switch ( id )
		{
			case R.id.action_show_multiple_streams:
				goToMultipleStreamsFragment();
				return true;
			default:
				break;
		}

		return super.onOptionsItemSelected( item );
	}

	private void goToMultipleStreamsFragment()
	{
		// Exactly 4 streams are needed
		long[] cameraIds = new long[4];
		int index = 0;

		for ( AvailableCamera availableCamera : _availableCameras )
		{
			cameraIds[index++] = availableCamera.getId();
			if ( index == cameraIds.length )
			{
				break;
			}
		}
		while ( index < cameraIds.length )
		{
			// Duplicate first camera ID in case there are less than 4 available cameras
			cameraIds[index++] = cameraIds[0];
		}

		Intent launchStreamActivity = new Intent( getActivity(), StreamActivity.class );
		launchStreamActivity.putExtra( "cameraIds", cameraIds );
		startActivity( launchStreamActivity );
	}

}
