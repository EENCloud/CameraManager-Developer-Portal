package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.accesspoint;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cameramanager.mobile_sdk.nubo.network.connectivity.model.NuboCamWifiAccessPoint;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.wizard.consumer.ItemConsumer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Dragos-Daniel Dit on 14.02.2018.
 */

public class AccessPointAdapter extends RecyclerView.Adapter<AccessPointHolder>
{
	private List<NuboCamWifiAccessPoint> _list;
	private ItemConsumer<NuboCamWifiAccessPoint> _accessPointConsumer;

	public AccessPointAdapter( List<NuboCamWifiAccessPoint> list, ItemConsumer<NuboCamWifiAccessPoint> accessPointConsumer )
	{
		_list = new ArrayList<>( list );
		_accessPointConsumer = accessPointConsumer;
	}

	@Override
	public AccessPointHolder onCreateViewHolder( ViewGroup parent, int viewType )
	{
		View view = LayoutInflater.from( parent.getContext() ).inflate( R.layout.item_access_point, parent, false );
		return new AccessPointHolder( view );
	}

	@Override
	public void onBindViewHolder( AccessPointHolder holder, int position )
	{
		final NuboCamWifiAccessPoint accessPoint = _list.get( position );
		holder.bind( accessPoint );
		holder.itemView.setOnClickListener( v -> _accessPointConsumer.accept( accessPoint ) );
	}

	@Override
	public int getItemCount()
	{
		return _list.size();
	}

	public void setData( List<NuboCamWifiAccessPoint> newList )
	{
		_list.clear();
		_list.addAll( newList );
		notifyDataSetChanged();
	}
}
