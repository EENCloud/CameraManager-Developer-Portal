package com.cameramanager.mobile_sdk_v2_sample.login;//package com.cameramanager.mobile_sdk_v2_sample.user_session;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

import com.cameramanager.mobile_sdk_v2_sample.MainActivity;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.utils.UiUtils;
import com.cameramanager.mobile_sdk_v2_sample.token.AccessTokenManager;

import butterknife.BindView;
import butterknife.ButterKnife;

public class LoginFragment extends Fragment
{

	static final String TAG = "LoginFragment";
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";

	@BindView( R.id.container_login_progress )
	FrameLayout _containerProgressBar;

	@BindView( R.id.field_username )
	EditText _fieldUsername;
	@BindView( R.id.field_password )
	EditText _fieldPassword;
	@BindView( R.id.btn_login )
	Button _btnLogin;
	@BindView( R.id.remember_credentials_checkbox )
	CheckBox _rememberCheckbox;

	static LoginFragment newInstance()
	{
		LoginFragment fragment = new LoginFragment();
		Bundle args = new Bundle();
		fragment.setArguments( args );
		return fragment;
	}

	@Override
	public void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
	}

	@Override
	public View onCreateView( LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		final View rootView = inflater.inflate( R.layout.fragment_login, container, false );
		ButterKnife.bind( this, rootView );

		if ( AccessTokenManager.INSTANCE.isReady() )
		{
			goToMainScreen();
		}

		_btnLogin.setOnClickListener( v -> login() );

		_fieldUsername.setText( getCredential( USERNAME ) );
		_fieldPassword.setText( getCredential( PASSWORD ) );
		_rememberCheckbox.setChecked( !_fieldUsername.getText().toString().isEmpty() );

		return rootView;
	}

	private void login()
	{
		final String username = _fieldUsername.getText().toString();
		if ( TextUtils.isEmpty( username ) )
		{
			_fieldUsername.setError( "Username cannot be empty" );
			return;
		}

		final String password = _fieldPassword.getText().toString();
		if ( TextUtils.isEmpty( password ) )
		{
			_fieldPassword.setError( "Password cannot be empty" );
			return;
		}

		if ( _rememberCheckbox.isChecked() )
		{
			saveCredentials( username, password );
		}

		login( username, password );
	}

	private void login( String username, String password )
	{
		final ProgressBar progressBar = UiUtils.showProgress( getActivity(), _containerProgressBar, getString( R.string.logging_in ) );

		new Thread( () ->
					{
						try
						{
							AccessTokenManager.INSTANCE.requestAccessToken( username, password );

							goToMainScreen();
						} catch ( Exception ex )
						{
							Log.e( TAG, "Failed to log in", ex );
						} finally
						{
							if ( getActivity() != null )
							{
								getActivity().runOnUiThread( () -> UiUtils.hideProgress( progressBar, _containerProgressBar ) );
							}
						}
					} ).start();

	}

	private void goToMainScreen()
	{
		Intent mainActivityIntent = new Intent( getActivity(), MainActivity.class );
		mainActivityIntent.addFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP );
		getActivity().startActivity( mainActivityIntent );
		getActivity().finish();
	}

	private void saveCredentials( String username, String password )
	{
		final SharedPreferences sharedPreferences = getContext().getSharedPreferences( TAG, Context.MODE_PRIVATE );
		final SharedPreferences.Editor editor = sharedPreferences.edit();
		editor.putString( USERNAME, username );
		editor.putString( PASSWORD, password );
		editor.apply();
	}

	private String getCredential( String credentialKey )
	{
		final SharedPreferences sharedPreferences = getContext().getSharedPreferences( TAG, Context.MODE_PRIVATE );
		return sharedPreferences.getString( credentialKey, "" );
	}

}
