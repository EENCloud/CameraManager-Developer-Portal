package com.cameramanager.mobile_sdk_v2_sample.token;

import android.os.ConditionVariable;

import com.cameramanager.mobile_sdk.camera_core.error.MobileSdkError;
import com.cameramanager.mobile_sdk.camera_core.error.MobileSdkErrorFactory;
import com.cameramanager.mobile_sdk.network_provider.actions.KeyValueActionResult;
import com.cameramanager.mobile_sdk.network_provider.environment.Environments;
import com.cameramanager.mobile_sdk.network_provider.oauth.ActionRequestAccessToken;
import com.cameramanager.mobile_sdk.token_provider.AccessTokenProvider;
import com.cameramanager.mobile_sdk_v2_sample.utils.ServerApiProvider;

import java.util.concurrent.atomic.AtomicReference;

import io.reactivex.schedulers.Schedulers;

public enum AccessTokenManager
{

	INSTANCE;

	private static final String DEFAULT_LOGIN_BASE_URL = "https://rest.cameramanager.com:443/";
	private static final String DEFAULT_BASE_URL = DEFAULT_LOGIN_BASE_URL + "rest/v2.2/";

	private AtomicReference< AccessTokenProvider > _accessTokenProviderRef = new AtomicReference<>();
	private ConditionVariable _isAccessTokenProviderReady = new ConditionVariable();

	public void requestAccessToken( String username, String password )
	{
		ActionRequestAccessToken actionRequestAccessToken = new ActionRequestAccessToken.Builder().baseUrl( DEFAULT_LOGIN_BASE_URL )
																								  .authorization( "ANDROID:ANDROID" )
																								  .username( username )
																								  .password( password )
																								  .build();

		try
		{
			KeyValueActionResult accessTokenResult = (KeyValueActionResult) actionRequestAccessToken.execute().subscribeOn( Schedulers.io() ).blockingSingle();
			String accessToken = accessTokenResult.getResult().get( "accessToken" );

			ServerApiProvider.INSTANCE.init( getBaseUrl(), accessToken );

			setAccessTokenProvider( accessToken );
			_isAccessTokenProviderReady.open();
		}
		catch ( Exception ex )
		{
			_isAccessTokenProviderReady.open();
			throw ex;
		}
	}

	private void setAccessTokenProvider( final String accessToken )
	{
		_accessTokenProviderRef.set( () -> accessToken );
	}

	public AccessTokenProvider getAccessTokenProvider() throws MobileSdkError
	{
		_isAccessTokenProviderReady.block();

		if ( _accessTokenProviderRef.get() == null )
		{
			throw MobileSdkErrorFactory.getErrorByCode( MobileSdkError.CODE_AUTHENTICATION_ERROR, "No OAuth token; did you call requestAccessToken()?" );
		}
		return _accessTokenProviderRef.get();
	}

	public boolean isReady()
	{
		return ( _accessTokenProviderRef.get() != null );
	}

	public String getBaseUrl()
	{
		return DEFAULT_BASE_URL;
	}

}
