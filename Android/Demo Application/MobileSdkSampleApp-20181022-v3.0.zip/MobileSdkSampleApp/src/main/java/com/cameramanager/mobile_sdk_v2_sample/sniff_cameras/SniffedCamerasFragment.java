package com.cameramanager.mobile_sdk_v2_sample.sniff_cameras;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.cameramanager.mobile_sdk.camera_core.data.Address;
import com.cameramanager.mobile_sdk.camera_core.data.Device;
import com.cameramanager.mobile_sdk.camera_core.data.DeviceModelInfo;
import com.cameramanager.mobile_sdk.camera_core.error.MobileSdkError;
import com.cameramanager.mobile_sdk.camera_core.util.Log;
import com.cameramanager.mobile_sdk.sniffer.CameraSniffer;
import com.cameramanager.mobile_sdk.sniffer.CameraSnifferListener;
import com.cameramanager.mobile_sdk.wizard.CameraWizard;
import com.cameramanager.mobile_sdk.wizard.CameraWizardListener;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.utils.SampleUtils;
import com.cameramanager.mobile_sdk_v2_sample.token.AccessTokenManager;
import com.cameramanager.mobile_sdk_v2_sample.wizard.WizardActivity;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Pattern;

public class SniffedCamerasFragment extends Fragment implements CameraSnifferListener,
																CameraWizardListener,
																SniffedCamerasAdapter.OnCameraItemActionListener
{

	public static final String TAG = "SniffedCamerasFragment";

	private CameraSniffer _cameraSniffer;
	private List< SniffedDevice > _sniffedCameras;

	private CameraWizard _cameraWizard;

	private SwipeRefreshLayout _refreshToSniff;
	private Button _btnStopSniffing;

	private RecyclerView _sniffedCamerasContainer;
	private SniffedCamerasAdapter _sniffedCamerasAdapter;

	private AlertDialog _addSniffedCameraDialog;
	private AlertDialog _addCameraManuallyDialog;

	private Device _device;

	@Override
	public void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setHasOptionsMenu( true );

		_cameraSniffer = new CameraSniffer( getContext(), this );
		try
		{
			_cameraSniffer.setProvider( AccessTokenManager.INSTANCE.getAccessTokenProvider() );
		}
		catch ( MobileSdkError error )
		{
			throw new IllegalStateException( "Failed to set provider for CameraSniffer", error );
		}

		_sniffedCameras = new CopyOnWriteArrayList<>();
		for ( Device camera : _cameraSniffer.getFoundDevices() )
		{
			_sniffedCameras.add( new SniffedDevice( camera ) );
		}

		_cameraWizard = new CameraWizard( this );
		try
		{
			_cameraWizard.setProvider( AccessTokenManager.INSTANCE.getAccessTokenProvider() );
		}
		catch ( MobileSdkError error )
		{
			throw new IllegalStateException( "Failed to set provider for CameraWizard", error );
		}
	}

	@Override
	public View onCreateView( LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		final View rootView = inflater.inflate( R.layout.fragment_sniff_cameras, container, false );

		_refreshToSniff = rootView.findViewById( R.id.refresh_sniffed_cameras );
		_refreshToSniff.setColorSchemeColors(
				ContextCompat.getColor( getActivity(), R.color.colorPrimary ),
				ContextCompat.getColor( getActivity(), R.color.colorAccent ),
				ContextCompat.getColor( getActivity(), R.color.colorPrimaryDark ) );

		_refreshToSniff.setOnRefreshListener( new SwipeRefreshLayout.OnRefreshListener()
		{
			@Override
			public void onRefresh()
			{
				rootView.findViewById( R.id.label_swipe_hint_sniff ).setVisibility( View.GONE );

				_sniffedCameras.clear();
				_sniffedCamerasAdapter.notifyDataSetChanged();

				_btnStopSniffing.setVisibility( View.VISIBLE );
				_cameraSniffer.startSniffing();
			}
		} );

		_btnStopSniffing = rootView.findViewById( R.id.btn_stop_sniffing );
		_btnStopSniffing.setOnClickListener( new View.OnClickListener()
		{
			@Override
			public void onClick( View v )
			{
				stopSniffingRoutine();
			}
		} );

		_sniffedCamerasAdapter = new SniffedCamerasAdapter( _sniffedCameras, getResources() );
		_sniffedCamerasAdapter.setListener( this );

		_sniffedCamerasContainer = rootView.findViewById( R.id.container_sniffed_cameras );
		_sniffedCamerasContainer.setHasFixedSize( true );
		_sniffedCamerasContainer.setLayoutManager( new LinearLayoutManager( getContext() ) );
		_sniffedCamerasContainer.setAdapter( _sniffedCamerasAdapter );

		return rootView;
	}

	@Override
	public void onPause()
	{
		super.onPause();

		stopSniffingRoutine();
	}

	private void stopSniffingRoutine()
	{
		_refreshToSniff.setRefreshing( false );
		_btnStopSniffing.setVisibility( View.INVISIBLE );

		_cameraSniffer.stopSniffing();
	}

	@Override
	public void onCreateOptionsMenu( Menu menu, MenuInflater inflater )
	{
		inflater.inflate( R.menu.menu_sniff_cameras, menu );
		super.onCreateOptionsMenu( menu, inflater );
	}

	@Override
	public boolean onOptionsItemSelected( MenuItem item )
	{
		int id = item.getItemId();

		switch ( id )
		{
			case R.id.action_add_camera:
				showAddCameraDialog();
				return true;
			case R.id.action_add_nubo:
				startActivity( new Intent( getActivity(), WizardActivity.class ) );
				return true;
			default:
				break;
		}

		return super.onOptionsItemSelected( item );
	}

	public void showAddCameraDialog()
	{
		AlertDialog.Builder dialogBuilder = new AlertDialog.Builder( getActivity() );
		LayoutInflater inflater = getActivity().getLayoutInflater();

		final View layout = inflater.inflate( R.layout.dialog_add_camera, null );
		( layout.findViewById( R.id.btn_confirm_add ) ).setOnClickListener( new View.OnClickListener()
		{
			@Override
			public void onClick( View v )
			{
				String name, brand, model, macAddress, ipAddress, port, zoneId;

				EditText fieldName = layout.findViewById( R.id.field_name );
				name = fieldName.getText().toString().trim();
				if ( name.equalsIgnoreCase( "" ) )
				{
					fieldName.setError( "Name cannot be empty" );
					return;
				}

				EditText fieldBrand = layout.findViewById( R.id.field_brand );
				brand = fieldBrand.getText().toString().trim();
				if ( brand.equalsIgnoreCase( "" ) )
				{
					fieldBrand.setError( "Brand cannot be empty" );
					return;
				}

				EditText fieldModel = layout.findViewById( R.id.field_model );
				model = fieldModel.getText().toString().trim();
				if ( model.equalsIgnoreCase( "" ) )
				{
					fieldModel.setError( "Model cannot be empty" );
					return;
				}

				EditText fieldMac = layout.findViewById( R.id.field_mac );
				macAddress = fieldMac.getText().toString().trim();
				if ( macAddress.equalsIgnoreCase( "" ) )
				{
					fieldMac.setError( "MAC Address cannot be empty" );
					return;
				}
				else if ( !Pattern.matches( "^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$", macAddress ) )
				{
					fieldMac.setError( "MAC Address format is XX:XX:XX:XX:XX:XX" );
					return;
				}

				EditText fieldIp = layout.findViewById( R.id.field_ip );
				ipAddress = fieldIp.getText().toString().trim();
				if ( ipAddress.equalsIgnoreCase( "" ) )
				{
					fieldIp.setError( "IP cannot be empty" );
					return;
				}
				else if ( !Patterns.IP_ADDRESS.matcher( ipAddress ).matches() )
				{
					fieldIp.setError( "IP format is XXX.XXX.XXX.XXX" );
					return;
				}

				EditText fieldPort = layout.findViewById( R.id.field_port );
				port = fieldPort.getText().toString().trim();
				if ( port.equalsIgnoreCase( "" ) )
				{
					fieldPort.setError( "Port cannot be empty" );
					return;
				}

				EditText fieldZoneId = layout.findViewById( R.id.field_zone_id );
				zoneId = fieldZoneId.getText().toString().trim();
				if ( zoneId.equalsIgnoreCase( "" ) )
				{
					fieldZoneId.setError( "Zone ID cannot be empty" );
					return;
				}

				_addCameraManuallyDialog.dismiss();

				_cameraWizard.addDevice( new Device( new Address( ipAddress, port, macAddress ), new DeviceModelInfo( brand, model ), 0L ), name, Long.parseLong( zoneId ) );
			}
		} );

		dialogBuilder.setView( layout );
		_addCameraManuallyDialog = dialogBuilder.create();
		_addCameraManuallyDialog.show();
	}

	// region CameraSnifferListener

	@Override
	public void onFound( Device device )
	{
		Log.d( TAG, "onFound()::" + device );
		_sniffedCameras.add( new SniffedDevice( device ) );
		_sniffedCamerasAdapter.notifyItemInserted( _sniffedCameras.size() - 1 );
	}

	@Override
	public void onLost( Device device )
	{
		Log.d( TAG, "onLost()::" + device );
		SniffedDevice lostCamera = SampleUtils.getCameraByMac( device.getAddress().getMac(), _sniffedCameras );
		int lostCamPosition = _sniffedCameras.indexOf( lostCamera );

		_sniffedCameras.remove( lostCamera );
		_sniffedCamerasAdapter.notifyItemRemoved( lostCamPosition );
	}

	@Override
	public void onError( MobileSdkError error )
	{
		Log.e( TAG, error.toString() );
	}

	// endregion CameraSnifferListener

	// region OnDeviceAddedListener

	@Override
	public void onAdded( long cameraId )
	{
		if ( getActivity() == null || getView() == null )
		{
			return;
		}

		SniffedDevice sniffedDevice = SampleUtils.getCameraByMac( _device.getAddress().getMac(), _sniffedCameras );
		if ( sniffedDevice != null )
		{
			sniffedDevice.setAdding( false );
			sniffedDevice.setAlreadyAdded( true );
			getActivity().runOnUiThread( () -> _sniffedCamerasAdapter.notifyDataSetChanged() );
		}

		Snackbar.make( getView(), String.format( Locale.getDefault(), "Camera [%s] is added with ID [%d]", _device.getAddress().getIp(), cameraId ), Snackbar.LENGTH_LONG )
				.show();
	}

	@Override
	public void onError( Device device, MobileSdkError error )
	{
		if ( getActivity() == null || getView() == null )
		{
			return;
		}

		SniffedDevice sniffedDevice = SampleUtils.getCameraByMac( device.getAddress().getMac(), _sniffedCameras );
		if ( sniffedDevice != null )
		{
			sniffedDevice.setAdding( false );
			getActivity().runOnUiThread( () -> _sniffedCamerasAdapter.notifyDataSetChanged() );
		}

		Snackbar.make( getView(), String.format( "Failed to add camera: [%s] Reason: %s", error.getGeneralMessage(), error.getDetailMessage() ), Snackbar.LENGTH_LONG ).show();
	}

	// endregion OnDeviceAddedListener

	// region OnCameraItemActionListener

	@Override
	public void onAddRequested( final Device device )
	{
		AlertDialog.Builder dialogBuilder = new AlertDialog.Builder( getActivity() );
		LayoutInflater inflater = getActivity().getLayoutInflater();

		final View layout = inflater.inflate( R.layout.dialog_add_sniffed_camera, null );
		( layout.findViewById( R.id.btn_confirm_add ) ).setOnClickListener( new View.OnClickListener()
		{
			@Override
			public void onClick( View v )
			{
				String name, zoneId;
				EditText fieldName = layout.findViewById( R.id.field_name );
				name = fieldName.getText().toString().trim();
				if ( name.equalsIgnoreCase( "" ) )
				{
					fieldName.setError( "Name cannot be empty" );
					return;
				}

				EditText fieldZoneId = layout.findViewById( R.id.field_zone_id );
				zoneId = fieldZoneId.getText().toString().trim();
				if ( zoneId.equalsIgnoreCase( "" ) )
				{
					fieldZoneId.setError( "Zone ID cannot be empty" );
					return;
				}

				_addSniffedCameraDialog.dismiss();

				SniffedDevice sniffedDevice = SampleUtils.getCameraByMac( device.getAddress().getMac(), _sniffedCameras );
				if ( sniffedDevice == null )
				{
					throw new IllegalStateException( String.format( "Failed to find sniffed camera with MAC [%s]", device.getAddress().getMac() ) );
				}

				sniffedDevice.setAdding( true );
				getActivity().runOnUiThread( new Runnable()
				{
					@Override
					public void run()
					{
						_sniffedCamerasAdapter.notifyDataSetChanged();
					}
				} );

				_device = device;
				_cameraWizard.addDevice( device, name, Long.parseLong( zoneId ) );
			}
		} );

		dialogBuilder.setView( layout );
		_addSniffedCameraDialog = dialogBuilder.create();
		_addSniffedCameraDialog.show();
	}

	// endregion OnCameraItemActionListener

}
