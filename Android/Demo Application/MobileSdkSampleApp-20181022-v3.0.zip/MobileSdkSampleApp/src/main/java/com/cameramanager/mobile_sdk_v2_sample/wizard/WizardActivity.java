package com.cameramanager.mobile_sdk_v2_sample.wizard;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.transition.Slide;
import android.view.Gravity;
import android.widget.ImageView;

import com.cameramanager.mobile_sdk.camera_core.error.MobileSdkError;
import com.cameramanager.mobile_sdk.camera_core.util.Log;
import com.cameramanager.mobile_sdk.nubo.network.api.camera.model.AccessPointName;
import com.cameramanager.mobile_sdk.nubo.network.api.camera.model.WifiNetwork;
import com.cameramanager.mobile_sdk.nubo.network.connectivity.model.NuboCamWifiAccessPoint;
import com.cameramanager.mobile_sdk.nubo.wizard.NuboCamWizard;
import com.cameramanager.mobile_sdk.nubo.wizard.listener.NuboCamWizardListener;
import com.cameramanager.mobile_sdk.nubo.wizard.pair.configuration.MobileSetupOption;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableZone;
import com.cameramanager.mobile_sdk_v2_sample.token.AccessTokenManager;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenChangeListener;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.accesspoint.AccessPointFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.error.ErrorFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.mobile.MobileFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.name.NameFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.pair.PairFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.prepare.PrepareFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.start.StartFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.success.SuccessFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.transition.CameraTransition;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.wifi.list.WifiListFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.wifi.password.WifiPasswordFragment;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.zone.ZoneListFragment;
import com.cameramanager.mobile_sdk.token_provider.AccessTokenProvider;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WizardActivity extends Activity implements ScreenChangeListener,
														NuboCamWizardListener
{

	public static final String TAG = "Wizard";
	private NuboCamWizard _nuboCamWizard;
	private String _cameraName;
	private ArrayList< WifiNetwork > _wifiNetworkList;
	private ArrayList< NuboCamWifiAccessPoint > _nuboCamWifiAccessPointList;
	private WifiNetwork _wifiNetwork;
	private AvailableZone _zone;
	@MobileSetupOption
	private int _mobileSetupOption;

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		_nuboCamWizard = NuboCamWizard.create( getApplicationContext(), this, getAccessTokenProvider() );
		postponeEnterTransition();
		setContentView( R.layout.activity_wizard );
		getFragmentManager().beginTransaction().replace( R.id.container, StartFragment.newInstance(), StartFragment.class.getSimpleName() ).addToBackStack( null ).commit();
		_nuboCamWifiAccessPointList = new ArrayList<>();
		_wifiNetworkList = new ArrayList<>();
	}

	@Override
	public void onBackPressed()
	{
		getFragmentManager().popBackStackImmediate();
		if ( getFragmentManager().getBackStackEntryCount() == 0 )
		{
			super.onBackPressed();
		}
	}

	@Override
	public void changeScreen( @Screen final int screen )
	{
		final ImageView transitionImageView;
		final Fragment screenFragment = getFragmentManager().findFragmentById( R.id.container );

		if ( screenFragment instanceof ScreenFragment )
		{
			transitionImageView = ( (ScreenFragment) screenFragment ).getTransitionImageView();
		}
		else
		{
			transitionImageView = null;
		}

		changeScreen( screen, transitionImageView );
	}

	@Override
	public void onPreparedForConnection( List< NuboCamWifiAccessPoint > accessPointList )
	{
		_nuboCamWifiAccessPointList.clear();
		_nuboCamWifiAccessPointList.addAll( accessPointList );

		final Fragment fragment = getFragmentManager().findFragmentByTag( PrepareFragment.class.getSimpleName() );
		if ( fragment instanceof PrepareFragment )
		{
			( (PrepareFragment) fragment ).onDataReady();
		}

		final Fragment accessPointFragment = getFragmentManager().findFragmentByTag( AccessPointFragment.class.getSimpleName() );
		if ( accessPointFragment instanceof AccessPointFragment )
		{
			( (AccessPointFragment) accessPointFragment ).setData( _nuboCamWifiAccessPointList );
		}
	}

	@Override
	public void onConnectedToCamera( @MobileSetupOption int option )
	{
		_mobileSetupOption = option;
		_nuboCamWizard.refreshWifiList();
		changeScreen( Screen.Name );
	}

	@Override
	public void onWifiListRefresh( List< WifiNetwork > wifiNetworkList )
	{
		_wifiNetworkList.clear();
		_wifiNetworkList.addAll( wifiNetworkList );
		final Fragment wifiListFragment = getFragmentManager().findFragmentByTag( WifiListFragment.class.getSimpleName() );
		if ( wifiListFragment instanceof WifiListFragment )
		{
			( (WifiListFragment) wifiListFragment ).setData( _wifiNetworkList );
		}
	}

	@Override
	public void onFinished( int cameraId )
	{
		changeScreen( Screen.Success );
	}

	@Override
	public void onError( MobileSdkError error )
	{
		changeScreen( Screen.Error );
	}

	private void changeScreen( @Screen int screen, ImageView transitionView )
	{
		final ScreenFragment fragment;
		switch ( screen )
		{
			case Screen.AccessPoint:
				fragment = getAccessPointFragment();
				break;
			case Screen.Error:
				fragment = ErrorFragment.newInstance();
				break;
			case Screen.Pair:
				fragment = PairFragment.newInstance();
				break;
			case Screen.Prepare:
				fragment = PrepareFragment.newInstance();
				startNuboCamWizard();
				break;
			case Screen.Start:
				fragment = StartFragment.newInstance();
				break;
			case Screen.Wifi:
				fragment = WifiListFragment.newInstance( _mobileSetupOption, _wifiNetworkList )
										   .setWifiNetworkConsumer( this::onWifiNetworkSelected )
										   .setTriggerWifiScanRunnable( _nuboCamWizard::refreshWifiList );
				break;
			case Screen.Name:
				fragment = NameFragment.newInstance().setNameConsumer( name -> _cameraName = name );
				break;
			case Screen.WifiPassword:
				fragment = WifiPasswordFragment.newInstance( _wifiNetwork ).setPasswordConsumer( this::connectCameraToWifi );
				break;
			case Screen.Success:
				fragment = SuccessFragment.newInstance();
				break;
			case Screen.Zone:
				fragment = ZoneListFragment.newInstance().setZoneItemConsumer( this::selectZone );
				break;
			case Screen.Mobile:
				fragment = MobileFragment.newInstance( _mobileSetupOption, _nuboCamWizard.getListOfAvailableCarriers() ).setApnItemConsumer( this::connectToApn );
				break;
			default:
				fragment = StartFragment.newInstance();
				break;
		}

		goToFragment( fragment, transitionView );
	}

	@Override
	public void onDisconnectedFromCameraUnexpectedly()
	{
		/*ignored*/
	}

	private void goToFragment( Fragment fragment, ImageView transitionView )
	{

		Fragment currentFragment = getFragmentManager().findFragmentById( R.id.container );
		currentFragment.setSharedElementReturnTransition( new CameraTransition() );
		currentFragment.setExitTransition( new Slide( Gravity.LEFT ) );
		currentFragment.setAllowReturnTransitionOverlap( false );
		currentFragment.setAllowEnterTransitionOverlap( false );

		fragment.setSharedElementEnterTransition( new CameraTransition() );
		fragment.setEnterTransition( new Slide( Gravity.RIGHT ) );
		fragment.setAllowEnterTransitionOverlap( false );
		fragment.setAllowReturnTransitionOverlap( false );

		getFragmentManager().beginTransaction()
							.replace( R.id.container, fragment, fragment.getClass().getSimpleName() )
							.addToBackStack( fragment.getTag() )
							.addSharedElement( transitionView, getString( R.string.camera_transition_name ) )
							.commit();
	}

	private AccessTokenProvider getAccessTokenProvider()
	{
		try
		{
			return AccessTokenManager.INSTANCE.getAccessTokenProvider();
		}
		catch ( MobileSdkError error )
		{
			Log.e( "Wizard", "getAccessTokenProvider: ", error );
			return null;
		}
	}

	private void startNuboCamWizard()
	{
		final Map< String, String > configurationMap = new HashMap<>();
		if ( _zone != null )
		{
			configurationMap.put( "zoneId", String.valueOf( _zone.getId() ) );
		}
		_nuboCamWizard.prepareForConnection( configurationMap );
	}

	private AccessPointFragment getAccessPointFragment()
	{
		return AccessPointFragment.newInstance( _nuboCamWifiAccessPointList ).setAccessPointConsumer( accessPoint -> {
			changeScreen( Screen.Pair );
			_nuboCamWizard.connectToCamera( accessPoint );

		} );
	}

	private void onWifiNetworkSelected( WifiNetwork wifiNetwork )
	{
		Log.v( TAG, "onWifiNetworkSelected: " + wifiNetwork );
		_wifiNetwork = wifiNetwork;
		if ( !wifiNetwork.getEncryption().equalsIgnoreCase( "none" ) )
		{
			changeScreen( Screen.WifiPassword );
		}
	}

	private void connectCameraToWifi( String password )
	{
		_nuboCamWizard.connectCameraToNetwork( _wifiNetwork.addPassword( password ), _cameraName );
	}

	private void selectZone( AvailableZone zone )
	{
		_zone = zone;
		changeScreen( Screen.Prepare );
	}

	private void connectToApn( AccessPointName apn )
	{
		_nuboCamWizard.connectCameraToNetwork( apn, _cameraName );
	}
}
