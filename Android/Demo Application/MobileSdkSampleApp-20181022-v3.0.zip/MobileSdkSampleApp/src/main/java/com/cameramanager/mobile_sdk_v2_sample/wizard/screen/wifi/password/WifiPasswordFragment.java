package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.wifi.password;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.cameramanager.mobile_sdk.camera_core.error.MobileSdkError;
import com.cameramanager.mobile_sdk.nubo.network.api.camera.model.WifiNetwork;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.wizard.consumer.ItemConsumer;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenFragment;

public class WifiPasswordFragment extends ScreenFragment
{

	public static final String WIFI_NETWORK = "wifiNetwork";

	public static WifiPasswordFragment newInstance( WifiNetwork wifiNetwork )
	{
		final Bundle bundle = new Bundle();
		final WifiPasswordFragment wifiPasswordFragment = new WifiPasswordFragment();
		bundle.putParcelable( WIFI_NETWORK, wifiNetwork );
		wifiPasswordFragment.setArguments( bundle );
		return wifiPasswordFragment;
	}

	private ItemConsumer<String> _passwordConsumer;
	private WifiNetwork _wifiNetwork;

	@Override
	public void onCreate( @Nullable Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		_wifiNetwork = getArguments().getParcelable( WIFI_NETWORK );
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		View rootView = inflater.inflate( R.layout.fragment_wifi_password, container, false );
		rootView.findViewById( R.id.btn_yes ).setOnClickListener( v -> onContinueClick( rootView.findViewById( R.id.password_edit_text ) ) );
		( (TextView) rootView.findViewById( R.id.ssid_text_view ) ).setText( String.format( getString( R.string.PleaseEnterPasswordFor ),
																							_wifiNetwork.getEssid() ) );
		return rootView;
	}

	private void showLoadingAnimation()
	{
		if ( getView() != null )
		{
			getView().findViewById( R.id.wifi_icon ).setVisibility( View.GONE );
			getView().findViewById( R.id.btn_yes ).setVisibility( View.INVISIBLE );
			getView().findViewById( R.id.progress_bar ).setVisibility( View.VISIBLE );
		}
	}

	private void hideLoadingAnimation()
	{
		if ( getView() != null )
		{
			getView().findViewById( R.id.progress_bar ).setVisibility( View.GONE );
			getView().findViewById( R.id.wifi_icon ).setVisibility( View.VISIBLE );
			getView().findViewById( R.id.btn_yes ).setVisibility( View.VISIBLE );
		}
	}

	private void onContinueClick( EditText editText )
	{
		closeKeyboard( editText );
		showLoadingAnimation();
		_passwordConsumer.accept( getCurrentPassword( editText ) );
	}

	private void closeKeyboard( EditText passwordEditText )
	{
		final InputMethodManager imm = (InputMethodManager) getActivity().getSystemService( Context.INPUT_METHOD_SERVICE );
		if ( imm != null )
		{
			imm.hideSoftInputFromWindow( passwordEditText.getWindowToken(), 0 );
		}
	}

	private String getCurrentPassword( EditText editText )
	{
		return editText.getText().toString();
	}

	public WifiPasswordFragment setPasswordConsumer( ItemConsumer<String> passwordConsumer )
	{
		_passwordConsumer = passwordConsumer;
		return this;
	}

	public void displayError( MobileSdkError error )
	{
		hideLoadingAnimation();
	}
}
