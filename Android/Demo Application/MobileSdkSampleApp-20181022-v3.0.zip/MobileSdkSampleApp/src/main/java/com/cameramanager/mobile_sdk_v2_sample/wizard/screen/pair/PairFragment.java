package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.pair;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenFragment;

public class PairFragment extends ScreenFragment
{

	public static PairFragment newInstance()
	{
		return new PairFragment();
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		// Inflate the layout for this fragment
		return inflater.inflate( R.layout.fragment_pair, container, false );
	}

}
