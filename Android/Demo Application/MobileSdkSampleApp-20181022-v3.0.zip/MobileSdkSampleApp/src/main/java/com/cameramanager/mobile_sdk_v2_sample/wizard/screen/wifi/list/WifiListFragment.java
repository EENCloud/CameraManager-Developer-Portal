package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.wifi.list;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cameramanager.mobile_sdk.nubo.network.api.camera.model.WifiNetwork;
import com.cameramanager.mobile_sdk.nubo.wizard.pair.configuration.MobileSetupOption;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.wizard.consumer.ItemConsumer;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenFragment;

import java.util.ArrayList;
import java.util.List;

public class WifiListFragment extends ScreenFragment
{

	private static final String ACCESS_POINTS = "AccessPoints";
	private static final String MOBILE_SETUP_OPTION = "MobileSetupOption";
	private List< WifiNetwork > _wifiNetworkList;
	private WifiAdapter _wifiAdapter;
	private ItemConsumer< WifiNetwork > _wifiNetworkConsumer;
	private Runnable _triggerWifiScanRunnable;
	@MobileSetupOption
	private int _mobileSetupOption;

	public static WifiListFragment newInstance( @MobileSetupOption int mobileSetupOption, ArrayList< WifiNetwork > list )
	{
		final WifiListFragment accessPointFragment = new WifiListFragment();
		final Bundle bundle = new Bundle();
		bundle.putInt( MOBILE_SETUP_OPTION, mobileSetupOption );
		bundle.putParcelableArrayList( ACCESS_POINTS, list );
		accessPointFragment.setArguments( bundle );
		return accessPointFragment;
	}

	@Override
	public void onCreate( @Nullable Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		_wifiNetworkList = getArguments().getParcelableArrayList( ACCESS_POINTS );
		_mobileSetupOption = getArguments().getInt( MOBILE_SETUP_OPTION, MobileSetupOption.NotAvailable );
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		// Inflate the layout for this fragment
		final View rootView = inflater.inflate( R.layout.fragment_wifi_list, container, false );

		final RecyclerView recyclerView = rootView.findViewById( R.id.recycler_view );

		_wifiAdapter = new WifiAdapter( _wifiNetworkList, _wifiNetworkConsumer );
		recyclerView.setAdapter( _wifiAdapter );
		recyclerView.setLayoutManager( new LinearLayoutManager( getActivity() ) );

		rootView.findViewById( R.id.btn_trigger_scan ).setOnClickListener( v ->
																		   {
																			   showLoadingAnimation();
																			   _triggerWifiScanRunnable.run();
																		   } );
		rootView.findViewById( R.id.btn_go_mobile ).setVisibility( _mobileSetupOption == MobileSetupOption.NotAvailable ? View.GONE : View.VISIBLE );

		return rootView;
	}

	public void setData( List< WifiNetwork > accessPointList )
	{
		getActivity().runOnUiThread( () ->
									 {
										 _wifiAdapter.setData( accessPointList );
										 hideLoadingAnimation();
									 } );
	}

	public WifiListFragment setWifiNetworkConsumer( ItemConsumer< WifiNetwork > wifiNetworkConsumer )
	{
		_wifiNetworkConsumer = wifiNetworkConsumer;
		return this;
	}

	public WifiListFragment setTriggerWifiScanRunnable( Runnable wifiScanRunnable )
	{
		_triggerWifiScanRunnable = wifiScanRunnable;
		return this;
	}

	private void showLoadingAnimation()
	{
		getView().findViewById( R.id.wifi_icon ).setVisibility( View.GONE );
		getView().findViewById( R.id.progress_bar ).setVisibility( View.VISIBLE );
	}

	private void hideLoadingAnimation()
	{
		getView().findViewById( R.id.progress_bar ).setVisibility( View.GONE );
		getView().findViewById( R.id.wifi_icon ).setVisibility( View.VISIBLE );
	}
}
