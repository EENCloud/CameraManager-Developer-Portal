package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.zone;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableZone;

/**
 * Created by Dragos-Daniel Dit on 14.02.2018.
 */

public class ZoneHolder extends RecyclerView.ViewHolder
{

	private TextView _textView;

	ZoneHolder( View itemView )
	{
		super( itemView );
		_textView = itemView.findViewById( R.id.access_point_view );
	}

	public void bind( AvailableZone zone )
	{
		_textView.setText( zone.getName() );
	}
}
