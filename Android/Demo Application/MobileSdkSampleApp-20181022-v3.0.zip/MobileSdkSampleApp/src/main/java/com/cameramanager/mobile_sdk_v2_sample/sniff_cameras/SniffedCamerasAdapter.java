package com.cameramanager.mobile_sdk_v2_sample.sniff_cameras;

import android.content.res.Resources;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.cameramanager.mobile_sdk.camera_core.data.Device;
import com.cameramanager.mobile_sdk_v2_sample.R;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

class SniffedCamerasAdapter extends RecyclerView.Adapter< SniffedCamerasAdapter.ViewHolder >
{

	private List< SniffedDevice > _sniffedCameras;
	private Resources _resources;
	private OnCameraItemActionListener _onCameraItemActionListener;

	SniffedCamerasAdapter( List< SniffedDevice > sniffedCameras, Resources resources )
	{
		setData( sniffedCameras );
		_resources = resources;
	}

	void setData( List< SniffedDevice > sniffedCameras )
	{
		_sniffedCameras = sniffedCameras;
	}

	void setListener( OnCameraItemActionListener listener )
	{
		_onCameraItemActionListener = listener;
	}

	@Override
	public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType )
	{
		RelativeLayout rootView = (RelativeLayout) LayoutInflater.from( parent.getContext() ).inflate( R.layout.item_sniffed_camera, parent, false );
		return new ViewHolder( rootView );
	}

	@Override
	public void onBindViewHolder( ViewHolder holder, int position )
	{
		final SniffedDevice sniffedCamera = _sniffedCameras.get( position );
		String model = sniffedCamera.getDeviceModelInfo().getBrand() + " " + sniffedCamera.getDeviceModelInfo().getModel();
		holder._labelCameraModel.setText( String.format( _resources.getString( R.string.sniffed_camera_model ), model ) );
		holder._labelCameraIp.setText( String.format( _resources.getString( R.string.sniffed_camera_ip ), sniffedCamera.getAddress().getIp() ) );
		holder._labelCameraMac.setText( String.format( _resources.getString( R.string.sniffed_camera_mac ), sniffedCamera.getAddress().getMac() ) );

		if ( sniffedCamera.isAlreadyAdded() )
		{
			holder._btnAddCamera.setEnabled( false );
			holder._btnAddCamera.setText( _resources.getString( R.string.added ) );
		}
		else if ( sniffedCamera.isAdding() )
		{
			holder._btnAddCamera.setEnabled( false );
			holder._btnAddCamera.setText( _resources.getString( R.string.adding ) );
		}
		else
		{
			holder._btnAddCamera.setEnabled( true );
			holder._btnAddCamera.setText( _resources.getString( R.string.add ) );
			holder._btnAddCamera.setOnClickListener( new View.OnClickListener()
			{
				@Override
				public void onClick( View view )
				{
					_onCameraItemActionListener.onAddRequested( sniffedCamera );
				}
			} );
		}
	}

	@Override
	public int getItemCount()
	{
		return _sniffedCameras.size();
	}

	interface OnCameraItemActionListener
	{
		void onAddRequested( Device camera );
	}

	static class ViewHolder extends RecyclerView.ViewHolder
	{

		@BindView( R.id.label_found_camera_model )
		TextView _labelCameraModel;
		@BindView( R.id.label_found_camera_ip )
		TextView _labelCameraIp;
		@BindView( R.id.label_found_camera_mac )
		TextView _labelCameraMac;
		@BindView( R.id.btn_add_sniffed_camera )
		Button _btnAddCamera;

		ViewHolder( View itemView )
		{
			super( itemView );
			ButterKnife.bind( this, itemView );
		}
	}
}
