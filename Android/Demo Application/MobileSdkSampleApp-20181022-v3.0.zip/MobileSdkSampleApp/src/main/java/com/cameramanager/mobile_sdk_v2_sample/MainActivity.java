package com.cameramanager.mobile_sdk_v2_sample;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.cameramanager.mobile_sdk_v2_sample.available_cameras.AvailableCamerasFragment;
import com.cameramanager.mobile_sdk_v2_sample.sniff_cameras.SniffedCamerasFragment;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity
{

	@BindView( R.id.layout_activity_main )
	DrawerLayout _drawerLayout;
	@BindView( R.id.navigation )
	NavigationView _navigationView;
	@BindView( R.id.container_main_screen )
	FrameLayout _containerMainScreen;

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setContentView( R.layout.activity_main );
		ButterKnife.bind( this );

		setupActionBar();
		setupDrawer();
	}

	private void setupActionBar()
	{
		Toolbar toolbar = findViewById( R.id.toolbar );
		setSupportActionBar( toolbar );

		ActionBar actionBar = getSupportActionBar();
		if ( actionBar != null )
		{
			actionBar.setHomeAsUpIndicator( R.drawable.ic_menu );
			actionBar.setDisplayHomeAsUpEnabled( true );
		}
	}

	private void setupDrawer()
	{
		_navigationView.getMenu().findItem( R.id.drawer_item_sniff_cameras ).setChecked( true );

		showSniffedCamerasFragment();

		_navigationView.setNavigationItemSelectedListener( new NavigationView.OnNavigationItemSelectedListener()
		{
			@Override
			public boolean onNavigationItemSelected( @NonNull MenuItem menuItem )
			{
				switch ( menuItem.getItemId() )
				{
					case R.id.drawer_item_sniff_cameras:
						showSniffedCamerasFragment();
						break;

					case R.id.drawer_item_live:
						showAvailableCamerasFragment( true );
						break;

					case R.id.drawer_item_footage:
						showAvailableCamerasFragment( false );
						break;

					default:
						Snackbar.make( _containerMainScreen, "This option is currently disabled", Snackbar.LENGTH_SHORT ).show();
						break;
				}
				// Close the navigation drawer when an item is selected.
				_drawerLayout.closeDrawers();
				return true;
			}
		} );
	}

	private void showSniffedCamerasFragment()
	{
		if ( getSupportActionBar() != null )
		{
			getSupportActionBar().setTitle( R.string.sniffed_cameras_fragment_title );
		}

		SniffedCamerasFragment sniffedCamerasFragment = (SniffedCamerasFragment) getSupportFragmentManager().findFragmentByTag( SniffedCamerasFragment.TAG );
		if ( sniffedCamerasFragment == null )
		{
			sniffedCamerasFragment = new SniffedCamerasFragment();
		}

		getSupportFragmentManager().beginTransaction().replace( R.id.container_main_screen, sniffedCamerasFragment ).commit();
	}

	private void showAvailableCamerasFragment( boolean isLiveStream )
	{
		if ( getSupportActionBar() != null )
		{
			getSupportActionBar().setTitle( isLiveStream ? R.string.available_cameras_live_fragment_title : R.string.available_cameras_footage_fragment_title );
		}

		AvailableCamerasFragment availableCamerasFragment = (AvailableCamerasFragment) getSupportFragmentManager().findFragmentByTag( AvailableCamerasFragment.TAG );
		if ( availableCamerasFragment == null )
		{
			availableCamerasFragment = AvailableCamerasFragment.newInstance( isLiveStream );
		}

		getSupportFragmentManager().beginTransaction().replace( R.id.container_main_screen, availableCamerasFragment ).commit();
	}

	@Override
	public boolean onOptionsItemSelected( MenuItem item )
	{
		int id = item.getItemId();

		switch ( id )
		{
			case android.R.id.home:
				// Open the navigation drawer when the home icon is selected from the toolbar.
				_drawerLayout.openDrawer( GravityCompat.START );
				return true;
		}

		return super.onOptionsItemSelected( item );
	}
}
