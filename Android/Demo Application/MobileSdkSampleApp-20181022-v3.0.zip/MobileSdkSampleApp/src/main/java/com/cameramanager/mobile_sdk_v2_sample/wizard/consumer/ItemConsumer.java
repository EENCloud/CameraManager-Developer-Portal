package com.cameramanager.mobile_sdk_v2_sample.wizard.consumer;

/**
 * Created by Dragos-Daniel Dit on 15.02.2018.
 */

public interface ItemConsumer<T>
{
	void accept( T t );
}
