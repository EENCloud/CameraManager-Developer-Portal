package com.cameramanager.mobile_sdk_v2_sample.available_cameras;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableCamera;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.subjects.PublishSubject;

class AvailableCamerasAdapter extends RecyclerView.Adapter< AvailableCamerasAdapter.ViewHolder >
{

	private Context _context;
	private List< AvailableCamera > _availableCameras;

	private final PublishSubject< Integer > _onClickSubject;

	AvailableCamerasAdapter( Context context, List< AvailableCamera > availableCameras )
	{
		_context = context;
		setData( availableCameras );

		_onClickSubject = PublishSubject.create();
	}

	void setData( List< AvailableCamera > availableCameras )
	{
		_availableCameras = availableCameras;
	}

	@Override
	public ViewHolder onCreateViewHolder( ViewGroup parent, int viewType )
	{
		LinearLayout rootView = (LinearLayout) LayoutInflater.from( parent.getContext() ).inflate( R.layout.item_available_camera, parent, false );
		return new ViewHolder( rootView );
	}

	@Override
	public void onBindViewHolder( final ViewHolder holder, int position )
	{
		final AvailableCamera availableCamera = _availableCameras.get( position );

		holder._rootView.setOnClickListener( new View.OnClickListener()
		{
			@Override
			public void onClick( View v )
			{
				_onClickSubject.onNext( availableCamera.getId() );
			}
		} );

		holder._labelCameraId.setText( String.format( _context.getString( R.string.added_camera_id ), availableCamera.getId() ) );
		holder._labelCameraName.setText( String.format( _context.getString( R.string.added_camera_name ), availableCamera.getName() ) );
	}

	@Override
	public int getItemCount()
	{
		return _availableCameras.size();
	}

	Observable< Integer > getItemClickObservable()
	{
		return _onClickSubject.observeOn( AndroidSchedulers.mainThread() );
	}

	static class ViewHolder extends RecyclerView.ViewHolder
	{
		View _rootView;
		@BindView( R.id.label_camera_id )
		TextView _labelCameraId;
		@BindView( R.id.label_camera_name )
		TextView _labelCameraName;

		ViewHolder( View rootView )
		{
			super( rootView );
			_rootView = rootView;
			ButterKnife.bind( this, rootView );
		}
	}
}
