package com.cameramanager.mobile_sdk_v2_sample.footage;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableRecording;
import com.cameramanager.mobile_sdk_v2_sample.utils.ServerApiProvider;
import com.cameramanager.mobile_sdk_v2_sample.utils.UiUtils;
import com.cameramanager.mobile_sdk_v2_sample.stream.StreamActivity;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;

public class AvailableFootageFragment extends Fragment
{

	public static final String TAG = "AvailableFootageFragment";

	@BindView( R.id.layout_fragment_available_footage )
	FrameLayout _rootLayout;
	@BindView( R.id.label_no_footage )
	TextView _labelNoFootage;
	@BindView( R.id.container_available_footage )
	RecyclerView _availableFootageContainer;

	private ProgressBar _progressBar;

	private int _cameraId;
	private List< AvailableRecording > _availableRecordings;
	private AvailableFootageAdapter _availableFootageAdapter;

	private final CompositeDisposable _compositeDisposable = new CompositeDisposable();

	static AvailableFootageFragment newInstance( int cameraId )
	{
		AvailableFootageFragment fragment = new AvailableFootageFragment();
		Bundle args = new Bundle();
		args.putInt( "cameraId", cameraId );
		fragment.setArguments( args );
		return fragment;
	}

	@Override
	public void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );

		_cameraId = getArguments().getInt( "cameraId" );

		_availableRecordings = new CopyOnWriteArrayList<>();
	}

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		final View rootView = inflater.inflate( R.layout.fragment_available_footage, container, false );
		ButterKnife.bind( this, rootView );

		_availableFootageAdapter = new AvailableFootageAdapter( _availableRecordings );
		_compositeDisposable.add( _availableFootageAdapter.getItemClickObservable().subscribe( footagePosition -> {
			Intent intent = StreamActivity.createIntent( getActivity(), _cameraId, footagePosition, getAvailableFootageArray() );
			startActivity( intent );
		} ) );

		_availableFootageContainer.setHasFixedSize( true );
		_availableFootageContainer.setLayoutManager( new LinearLayoutManager( getContext() ) );
		_availableFootageContainer.setAdapter( _availableFootageAdapter );

		_progressBar = UiUtils.showProgress( getActivity(), _rootLayout, getString( R.string.loading_footage ) );

		requestAvailableFootage();

		return rootView;
	}

	void requestAvailableFootage()
	{
		_availableRecordings.clear();
		_availableFootageAdapter.notifyDataSetChanged();

		_compositeDisposable.add( ServerApiProvider.INSTANCE.getAvailableFootage( _cameraId ).observeOn( AndroidSchedulers.mainThread() ).subscribe( recordings -> {
			_availableRecordings.clear();
			_availableRecordings.addAll( recordings );

			_availableFootageAdapter.notifyDataSetChanged();

			if ( _availableRecordings.isEmpty() )
			{
				_labelNoFootage.setVisibility( View.VISIBLE );
			}

			UiUtils.hideProgress( _progressBar, _rootLayout );
		}, throwable -> {
			UiUtils.hideProgress( _progressBar, _rootLayout );

			Snackbar.make( _rootLayout, String.format( "Failed to obtain footage: %s", throwable.getMessage() ), Snackbar.LENGTH_LONG ).show();

		} ) );
	}

	private long[] getAvailableFootageArray()
	{
		long[] footageIdArray = new long[_availableRecordings.size()];
		for ( int i = _availableRecordings.size() - 1; i >= 0; i-- )
		{
			footageIdArray[i] = _availableRecordings.get( i ).getId();
		}
		return footageIdArray;
	}

}
