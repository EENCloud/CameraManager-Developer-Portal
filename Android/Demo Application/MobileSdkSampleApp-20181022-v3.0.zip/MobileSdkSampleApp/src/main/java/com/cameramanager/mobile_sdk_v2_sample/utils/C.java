package com.cameramanager.mobile_sdk_v2_sample.utils;

public final class C
{

	public static final String EXTRA_CAMERA_ID = "CAMERA_ID";
	public static final String EXTRA_REC_ID = "REC_ID";

}
