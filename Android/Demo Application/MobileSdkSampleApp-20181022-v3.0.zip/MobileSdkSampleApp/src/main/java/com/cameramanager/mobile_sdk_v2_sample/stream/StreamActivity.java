package com.cameramanager.mobile_sdk_v2_sample.stream;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.utils.C;

public class StreamActivity extends AppCompatActivity
{

	private static final String FOOTAGE_POSITION = "footagePosition";
	private static final String FOOTAGE_ID_ARRAY = "footageIdArray";

	public static Intent createIntent( Context context, int cameraId, int footagePosition, long[] footageIdArray )
	{
		Intent intent = new Intent( context, StreamActivity.class );
		intent.putExtra( C.EXTRA_CAMERA_ID, cameraId );
		intent.putExtra( FOOTAGE_POSITION, footagePosition );
		intent.putExtra( FOOTAGE_ID_ARRAY, footageIdArray );
		return intent;
	}

	@Override
	protected void onCreate( Bundle savedInstanceState )
	{
		super.onCreate( savedInstanceState );
		setContentView( R.layout.activity_stream );

		Intent launchIntent = getIntent();
		if ( launchIntent == null )
		{
			throw new IllegalStateException( "Params not specified for StreamActivity" );
		}

		int cameraId = launchIntent.getExtras().getInt( C.EXTRA_CAMERA_ID, -1 );
		int footagePosition = launchIntent.getExtras().getInt( FOOTAGE_POSITION, -1 );
		long[] footageIdArray = launchIntent.getExtras().getLongArray( FOOTAGE_ID_ARRAY );

		showStreamFragment( cameraId, footagePosition, footageIdArray );
	}

	private void showStreamFragment( int cameraId, int footagePosition, long[] footageIdArray )
	{
		ActionBar actionBar = getSupportActionBar();
		if ( actionBar != null )
		{
			getSupportActionBar().setDisplayHomeAsUpEnabled( true );
			getSupportActionBar().setTitle( footagePosition >= 0 ? R.string.footage_stream_fragment_title : R.string.live_stream_fragment_title );
		}

		StreamFragment streamFragment = (StreamFragment) getSupportFragmentManager().findFragmentByTag( StreamFragment.TAG );
		if ( streamFragment == null )
		{
			streamFragment = StreamFragment.newInstance( cameraId, footageIdArray != null ? footageIdArray[footagePosition] : -1L );
		}
		getSupportFragmentManager().beginTransaction().replace( R.id.container_stream_fragment, streamFragment ).commit();
	}

	@Override
	public boolean onOptionsItemSelected( MenuItem item )
	{
		int id = item.getItemId();

		switch ( id )
		{
			case android.R.id.home:
				// finish this activity and pop the previous one from the backstack
				finish();
				return true;
		}

		return super.onOptionsItemSelected( item );
	}

}
