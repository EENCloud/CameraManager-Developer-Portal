package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.wifi.list;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cameramanager.mobile_sdk.nubo.network.api.camera.model.WifiNetwork;
import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.wizard.consumer.ItemConsumer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Dragos-Daniel Dit on 14.02.2018.
 */

public class WifiAdapter extends RecyclerView.Adapter<WifiHolder>
{
	private List<WifiNetwork> _list;
	private ItemConsumer<WifiNetwork> _accessPointConsumer;

	public WifiAdapter( List<WifiNetwork> list, ItemConsumer<WifiNetwork> accessPointConsumer )
	{
		_list = new ArrayList<>( list );
		_accessPointConsumer = accessPointConsumer;
	}

	@Override
	public WifiHolder onCreateViewHolder( ViewGroup parent, int viewType )
	{
		View view = LayoutInflater.from( parent.getContext() ).inflate( R.layout.item_access_point, parent, false );
		return new WifiHolder( view );
	}

	@Override
	public void onBindViewHolder( WifiHolder holder, int position )
	{
		final WifiNetwork wifiNetwork = _list.get( position );
		holder.bind( wifiNetwork );
		holder.itemView.setOnClickListener( v -> _accessPointConsumer.accept( wifiNetwork ) );
	}

	@Override
	public int getItemCount()
	{
		return _list.size();
	}

	public void setData( List<WifiNetwork> newList )
	{
		_list.clear();
		_list.addAll( newList );
		notifyDataSetChanged();
	}
}
