package com.cameramanager.mobile_sdk_v2_sample.footage;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableRecording;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.subjects.PublishSubject;

class AvailableFootageAdapter extends RecyclerView.Adapter< AvailableFootageAdapter.ViewHolder >
{

	private List< AvailableRecording > _availableRecordings;

	private final PublishSubject< Integer > _onClickSubject;

	AvailableFootageAdapter( List< AvailableRecording > availableRecordings )
	{
		setData( availableRecordings );

		_onClickSubject = PublishSubject.create();
	}

	void setData( List< AvailableRecording > availableFootage )
	{
		_availableRecordings = availableFootage;
	}

	@NonNull
	@Override
	public ViewHolder onCreateViewHolder( @NonNull ViewGroup parent, int viewType )
	{
		LinearLayout rootView = (LinearLayout) LayoutInflater.from( parent.getContext() ).inflate( R.layout.item_available_footage, parent, false );
		return new ViewHolder( rootView );
	}

	@Override
	public void onBindViewHolder( @NonNull final ViewHolder holder, int position )
	{
		final AvailableRecording availableFootageItem = _availableRecordings.get( position );

		holder._rootView.setOnClickListener( v -> _onClickSubject.onNext( position ) );

		holder._labelFootageStart.setText( availableFootageItem.getStartTimeDisplay() );
		holder._labelFootageEnd.setText( availableFootageItem.getEndTimeDisplay() );

	}

	@Override
	public int getItemCount()
	{
		return _availableRecordings.size();
	}

	Observable< Integer > getItemClickObservable()
	{
		return _onClickSubject.observeOn( AndroidSchedulers.mainThread() );
	}

	static class ViewHolder extends RecyclerView.ViewHolder
	{
		View _rootView;
		@BindView( R.id.label_footage_start )
		TextView _labelFootageStart;
		@BindView( R.id.label_footage_end )
		TextView _labelFootageEnd;

		ViewHolder( View rootView )
		{
			super( rootView );
			_rootView = rootView;
			ButterKnife.bind( this, rootView );
		}
	}
}
