package com.cameramanager.mobile_sdk_v2_sample.model;

import com.google.gson.annotations.SerializedName;

public class AvailableZone
{

	@SerializedName( "zoneId" )
	private long _id;
	@SerializedName( "name" )
	private String _name;

	public long getId()
	{
		return _id;
	}

	public String getName()
	{
		return _name;
	}
}
