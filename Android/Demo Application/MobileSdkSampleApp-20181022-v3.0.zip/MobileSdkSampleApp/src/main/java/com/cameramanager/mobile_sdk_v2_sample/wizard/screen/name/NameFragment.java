package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.name;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.wizard.Screen;
import com.cameramanager.mobile_sdk_v2_sample.wizard.consumer.ItemConsumer;
import com.cameramanager.mobile_sdk_v2_sample.wizard.screen.ScreenFragment;

public class NameFragment extends ScreenFragment
{

	public static NameFragment newInstance()
	{
		return new NameFragment();
	}

	private ItemConsumer<String> _nameConsumer;

	@Override
	public View onCreateView( @NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
	{
		View rootView = inflater.inflate( R.layout.fragment_name, container, false );
		rootView.findViewById( R.id.btn_yes ).setOnClickListener( v -> onContinueClick( rootView ) );
		return rootView;
	}

	private void onContinueClick( View rootView )
	{
		_nameConsumer.accept( getCurrentSelectedName( rootView.findViewById( R.id.name_edit_text ) ) );
		_screenChangeListener.changeScreen( Screen.Wifi );
	}

	private String getCurrentSelectedName( EditText editText )
	{
		return editText.getText().toString();
	}

	public NameFragment setNameConsumer( ItemConsumer<String> nameConsumer )
	{
		_nameConsumer = nameConsumer;
		return this;
	}

}
