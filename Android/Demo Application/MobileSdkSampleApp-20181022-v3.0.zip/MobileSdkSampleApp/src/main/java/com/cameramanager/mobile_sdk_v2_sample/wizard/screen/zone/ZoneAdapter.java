package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.zone;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cameramanager.mobile_sdk_v2_sample.R;
import com.cameramanager.mobile_sdk_v2_sample.model.AvailableZone;
import com.cameramanager.mobile_sdk_v2_sample.wizard.consumer.ItemConsumer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Dragos-Daniel Dit on 14.02.2018.
 */

public class ZoneAdapter extends RecyclerView.Adapter< ZoneHolder >
{
	private List< AvailableZone > _list;
	private ItemConsumer< AvailableZone > _accessPointConsumer;

	ZoneAdapter( ItemConsumer< AvailableZone > accessPointConsumer )
	{
		_list = new ArrayList<>();
		_accessPointConsumer = accessPointConsumer;
	}

	@NonNull
	@Override
	public ZoneHolder onCreateViewHolder( @NonNull ViewGroup parent, int viewType )
	{
		View view = LayoutInflater.from( parent.getContext() ).inflate( R.layout.item_access_point, parent, false );
		return new ZoneHolder( view );
	}

	@Override
	public void onBindViewHolder( @NonNull ZoneHolder holder, int position )
	{
		final AvailableZone zone = _list.get( position );
		holder.bind( zone );
		holder.itemView.setOnClickListener( v -> _accessPointConsumer.accept( zone ) );
	}

	@Override
	public int getItemCount()
	{
		return _list.size();
	}

	public void setData( List< AvailableZone > zones )
	{
		_list.clear();
		_list.addAll( zones );
		notifyDataSetChanged();
	}
}
