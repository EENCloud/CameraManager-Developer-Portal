package com.cameramanager.mobile_sdk_v2_sample.utils;

import com.cameramanager.mobile_sdk.camera_core.data.Device;

import java.util.List;

public final class SampleUtils
{

	public static < T extends Device > T getCameraByMac( String mac, List< T > cameras )
	{
		for ( T camera : cameras )
		{
			if ( camera.getAddress().getMac().equalsIgnoreCase( mac ) )
			{
				return camera;
			}
		}
		return null;
	}

}
