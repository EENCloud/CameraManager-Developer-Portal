package com.cameramanager.mobile_sdk_v2_sample.wizard.screen.transition;

import android.transition.ChangeBounds;
import android.transition.ChangeImageTransform;
import android.transition.ChangeTransform;
import android.transition.TransitionSet;

/**
 * Created by DragosD on 14-Feb-18.
 */

public class CameraTransition extends TransitionSet
{
	public CameraTransition()
	{
		setOrdering( ORDERING_TOGETHER );
		addTransition( new ChangeBounds() );
		addTransition( new ChangeTransform() );
		addTransition( new ChangeImageTransform() );
	}
}
