// swift-tools-version:5.7
// AUTO-GENERATED — do not edit by hand.
// Published by CM-iOS-SDK's release pipeline (github.com/EENCloud/CM-iOS-SDK, private).
// Regenerated and overwritten on every release; local edits will be lost.
import PackageDescription

let package = Package(
    name: "CMMobileSDK",
    platforms: [.iOS(.v15)],
    products: [
        .library(name: "CMMobileSDK", targets: ["CMMobileSDKBinary", "CMMobileSDKDependencyShim"]),
        .library(name: "CMMobileTimelineSDK", targets: [
            "CMMobileTimelineSDKBinary", "CMMobileSDKBinary", "CMMobileSDKDependencyShim",
            "AFNetworking", "AFNetworking_RetryPolicy", "AFOAuth2Manager", "FSCalendar",
            "KVOController", "MSWeakTimer", "Mantle", "ObjcAssociatedObjectHelpers",
            "SDWebImage", "Toast", "WebsocketStompKit", "jetfire"
        ])
    ],
    dependencies: [
        .package(url: "https://github.com/Alamofire/Alamofire.git", .upToNextMajor(from: "5.0.5")),
        .package(url: "https://github.com/Moya/Moya.git", exact: "14.0.0")
    ],
    targets: [
        .binaryTarget(
            name: "CMMobileSDKBinary",
            url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/CMMobileSDK-v5213.xcframework.zip",
            checksum: "e67413f5b348079cf720f5f488c77baa580968c559a8384c62203fdc1bbb6419"
        ),
        .binaryTarget(
            name: "CMMobileTimelineSDKBinary",
            url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/MobileTimelineSDK/iOS/MobileTimelineSDK%20XCFramework/CMMobileTimelineSDK.xcframework-v1.0.9.zip",
            checksum: "3bfa5841060274312a1e37b62d4847d7fe26a353b99ba7dd4f154cbd23a50c5e"
        ),
        // CMMobileTimelineSDK.framework dynamically links all 12 of these at @rpath - none are
        // bundled inside it, none have usable upstream SPM support, and customers are SPM-only
        // (no CocoaPods/Carthage), so we vendor and ship our own xcframeworks built from each
        // library's public source.
        .binaryTarget(name: "AFNetworking", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/AFNetworking.xcframework.zip", checksum: "eb86f10d92f820c652fd75576f89629c52e0f2827cb47567935d4b827dbf2fac"),
        .binaryTarget(name: "AFNetworking_RetryPolicy", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/AFNetworking_RetryPolicy.xcframework.zip", checksum: "96de5621f0650d754428ff9e819030615ac85bf267b6527efc3a2c8cd9fee311"),
        .binaryTarget(name: "AFOAuth2Manager", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/AFOAuth2Manager.xcframework.zip", checksum: "aed0e1ccfa228a3aa927e0334f4143349c5025207dd3b82fc2370a0bfa5e6272"),
        .binaryTarget(name: "FSCalendar", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/FSCalendar.xcframework.zip", checksum: "70d8acd69cb31787dfaf785b66c14815704b305d3acfb6f4c077950370e72baf"),
        .binaryTarget(name: "KVOController", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/KVOController.xcframework.zip", checksum: "a642d275fcae34eabb91b0af333b017727ea28e42952ac05b93c3b8b8b50123c"),
        .binaryTarget(name: "MSWeakTimer", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/MSWeakTimer.xcframework.zip", checksum: "c1f073efe9ac10a5557ad7e7e502f5358f4381d76ed805427048f8383c49ea07"),
        .binaryTarget(name: "Mantle", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/Mantle.xcframework.zip", checksum: "f67bdb99fdf6826692cf35b8947aae4b9611641649849418dfb682aa6b71cefe"),
        .binaryTarget(name: "ObjcAssociatedObjectHelpers", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/ObjcAssociatedObjectHelpers.xcframework.zip", checksum: "bd6dbb73f03ee758130be07bf33aeea121bc2329c270e6d3d222fd3d9500f104"),
        .binaryTarget(name: "SDWebImage", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/SDWebImage.xcframework.zip", checksum: "408af5cd8be58727096857d11080a354ff1c34935ca39752efa488cbea50111f"),
        .binaryTarget(name: "Toast", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/Toast.xcframework.zip", checksum: "8da1d55f43bd256ea563021a8c4bfab2a271586d3d314b6c78e3d866516815dd"),
        .binaryTarget(name: "WebsocketStompKit", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/WebsocketStompKit.xcframework.zip", checksum: "e6ba5c9bace3eeac961c2c97ca671148dec9dcaec71f7e3b1c4f303c86568e39"),
        .binaryTarget(name: "jetfire", url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/TimelineSDK%20Dependencies/jetfire.xcframework.zip", checksum: "5dfb4f6e90af83e2e910d9843f20a5035c9d001cec8cad00e2bb9a8a4aea9a59"),
        .target(
            name: "CMMobileSDKDependencyShim",
            dependencies: [
                "CMMobileSDKBinary",
                .product(name: "Alamofire", package: "Alamofire"),
                .product(name: "Moya", package: "Moya")
            ],
            path: "Sources/CMMobileSDKDependencyShim"
        )
    ]
)
