// swift-tools-version:5.7
// AUTO-GENERATED — do not edit by hand.
// Published by CM-iOS-SDK's release pipeline (github.com/EENCloud/CM-iOS-SDK, private).
// Regenerated and overwritten on every release; local edits will be lost.
import PackageDescription

let package = Package(
    name: "CMMobileSDK",
    platforms: [.iOS(.v15)],
    products: [
        .library(name: "CMMobileSDK", targets: ["CMMobileSDKBinary", "CMMobileSDKDependencyShim"])
    ],
    dependencies: [
        .package(url: "https://github.com/Alamofire/Alamofire.git", .upToNextMajor(from: "5.0.5")),
        .package(url: "https://github.com/Moya/Moya.git", exact: "14.0.0")
    ],
    targets: [
        .binaryTarget(
            name: "CMMobileSDKBinary",
            url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/CMMobileSDK-v5213.xcframework.zip",
            checksum: "e67413f5b348079cf720f5f488c77baa580968c559a8384c62203fdc1bbb6419"
        ),
        .target(
            name: "CMMobileSDKDependencyShim",
            dependencies: [
                "CMMobileSDKBinary",
                .product(name: "Alamofire", package: "Alamofire"),
                .product(name: "Moya", package: "Moya")
            ],
            path: "Sources/CMMobileSDKDependencyShim"
        )
    ]
)
