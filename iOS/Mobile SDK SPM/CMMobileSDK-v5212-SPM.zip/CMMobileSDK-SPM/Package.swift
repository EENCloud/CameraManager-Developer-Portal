// swift-tools-version:5.7
// AUTO-GENERATED — do not edit by hand.
// Published by CM-iOS-SDK's release pipeline (github.com/EENCloud/CM-iOS-SDK, private).
// Regenerated and overwritten on every release; local edits will be lost.
import PackageDescription

let package = Package(
    name: "CMMobileSDK",
    platforms: [.iOS(.v15)],
    products: [
        .library(name: "CMMobileSDK", targets: ["CMMobileSDKBinary", "CMMobileSDKDependencyShim"])
    ],
    dependencies: [
        .package(url: "https://github.com/Alamofire/Alamofire.git", exact: "5.0.5"),
        .package(url: "https://github.com/Moya/Moya.git", exact: "14.0.0")
    ],
    targets: [
        .binaryTarget(
            name: "CMMobileSDKBinary",
            url: "https://raw.githubusercontent.com/EENCloud/CameraManager-Developer-Portal/main/iOS/Mobile%20SDK%20XCFramework/CMMobileSDK-v5212.xcframework.zip",
            checksum: "9743eb19fc74477a7de95924ef2dc1ce8375d8208945c66cd6bce42d1c9db54b"
        ),
        .target(
            name: "CMMobileSDKDependencyShim",
            dependencies: [
                "CMMobileSDKBinary",
                .product(name: "Alamofire", package: "Alamofire"),
                .product(name: "Moya", package: "Moya")
            ],
            path: "Sources/CMMobileSDKDependencyShim"
        )
    ]
)
