//
//  CMStreamerItem.h
//  CMMobileSDK
//
//  Created by D. Ianchyk on 27/07/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @enum
    CMStreamerItemStatus
 @abstract
    These constants are returned by the CMStreamerItem status property to indicate whether it can successfully be played.
 @constant
    CMStreamerItemStatusUnknown
    Indicates that the status of the streamer item is not yet known because it has not tried to load new media resources for playback.
 @constant
    CMStreamerItemStatusReady
    Indicates that the streamer item is ready to be played. At this moment metadata (capabilitiesMask, duration) can be processed.
 @constant
    CMStreamerItemStatusFailed
    Indicates that the streamer item can no longer be played because of an error. The error is described by the value of the failureReason property.
 */
typedef enum : NSUInteger {
    CMStreamerItemStatusUnknown,
    CMStreamerItemStatusReady,
    CMStreamerItemStatusFailed,
} CMStreamerItemStatus;

/*!
 @enum
    CMStreamerItemAudioStreamingMethod
 @abstract
    These constants are returned by the CMStreamerItem audioStreamingMethod property to indicate method being used for audio streaming. Correlates with CMStreamerItemCapabilitiesMaskCanStreamAudio capability.
 @constant
    CMStreamerItemAudioStreamingMethodUnsupported
    Audio streaming is not supported.
 @constant
    CMStreamerItemAudioStreamingMethodPushToTalk
    Input audio stream will be muted while output audio stream is active.
 @constant
    CMStreamerItemAudioStreamingMethodFullDuplex
    Input and output audio streams will be active at the same time.
 */
typedef enum : NSUInteger {
    CMStreamerItemAudioStreamingMethodUnsupported,
    CMStreamerItemAudioStreamingMethodPushToTalk,
    CMStreamerItemAudioStreamingMethodFullDuplex,
} CMStreamerItemAudioStreamingMethod;

/*!
 @enum
    CMStreamerItemCapabilitiesMask
 @abstract
    A mask describing playback capabilities of item.
 @constant
    CMStreamerItemCapabilitiesMaskNone
    Indicates that item has no playback capabilities.
 @constant
    CMStreamerItemCapabilitiesMaskCanSeek
    Indicates whether the item suports seeking. Call CMCameraStreamerInterface instance's -seekTo: method to seek stream to requested time.
 @constant
    CMStreamerItemCapabilitiesMaskCanSpeedPlay
    Indicates whether the supports speed play. Rate can be changed by setting positive value to CMCameraStreamerInterface instance's rate property.
 @constant
    CMStreamerItemCapabilitiesMaskCanStep
    Indicates whether the item supports stepping. Call CMCameraStreamerInterface instance's -stepBy: method to step by requested amount of frames.
 @constant
    CMStreamerItemCapabilitiesMaskCanStreamAudio
    Indicates whether the item supports audio streaming.
    Audio streaming session can be managed by calling CMCameraStreamerInterface instance's -startAudioStreaming, -stopAudioStreaming methods.
    Audio streaming method depends on camera and phone capabilities. Check AudioStreamingMethod enumeration for more details.
 */
typedef enum : NSUInteger {
    CMStreamerItemCapabilitiesMaskNone              = 0,
    CMStreamerItemCapabilitiesMaskCanSeek           = 1 << 0,
    CMStreamerItemCapabilitiesMaskCanSpeedPlay      = 1 << 1,
    CMStreamerItemCapabilitiesMaskCanStep           = 1 << 2,
    CMStreamerItemCapabilitiesMaskCanStreamAudio    = 1 << 3,
} CMStreamerItemCapabilitiesMask;

@class CMMobileSDKError;

/*!
 @class
    CMStreamerItem
 @abstract
    Represents streaming essence and holds metadata.
 */
@interface CMStreamerItem : NSObject

/*!
 @method
    itemWithCameraId:
 @abstract
    Initializes an instance of CMStreamerItem with given cameraId.
 @param
    cameraId
    An id of camera for which live stream should be played.
 @result
    An instance of CMStreamerItem.
 @discussion
    Pass instance returned by this method to CMCameraStreamerInterface instance for live streaming.
    Equivalent to -initWithCameraId:recordingId, passing recordingId equals to zero value.
 */
+ (instancetype)itemWithCameraId:(NSUInteger)cameraId;

/*!
 @method
    itemWithCameraId:recordingId:
 @abstract
    Initializes an instance of CMStreamerItem with given cameraId and recordingId.
 @param
    cameraId
    An id of camera for which footage stream should be played.
 @param
    recordingId
    An id of recording to be played.
 @result
    An instance of CMStreamerItem.
 @discussion
    Pass instance returned by this method to CMCameraStreamerInterface instance for footage streaming.
 */
+ (instancetype)itemWithCameraId:(NSUInteger)cameraId recordingId:(NSUInteger)recordingId;

/*!
 @property
    cameraId
 @abstract
    An id of camera for which live or footage stream should be played.
 */
@property (readonly) NSUInteger cameraId;

/*!
 @property
    recordingId
 @abstract
    An id of recording to be played.
 @discussion
    Will be equal to zero for live streaming.
 */
@property (readonly) NSUInteger recordingId;

/*!
 @property
    status
 @abstract
    The ability of the receiver to be used for playback.
 @discussion
    For possible values and discussion, see CMCameraStreamerStatus.
 */
@property (readonly) CMStreamerItemStatus status;

/*!
 @property
    failureReason
 @abstract
    If status is CMStreamerItemStatusFailed, this property describes the error that caused the failure.
 */
@property (readonly) CMMobileSDKError *failureReason;

/*!
 @property
    capabilitiesMask
 @abstract
    Indicates playback capabilities of item.
 @discussion
    For possible values and discussion, see CMStreamerItemCapabilitiesMask.
 */
@property (readonly) CMStreamerItemCapabilitiesMask capabilitiesMask;

/*!
 @property
    audioStreamingMethod
 @abstract
    Indicates method being used for audio streaming.
 @discussion
    For possible values and discussion, see CMStreamerItemAudioStreamingMethod.
 */
@property (readonly) CMStreamerItemAudioStreamingMethod audioStreamingMethod;

/*!
 @property
    duration
 @abstract
    Indicates the dutation of the item.
 @discussion
    Will be equal to zero for live streaming.
 */
@property (readonly) NSTimeInterval duration;

@end
