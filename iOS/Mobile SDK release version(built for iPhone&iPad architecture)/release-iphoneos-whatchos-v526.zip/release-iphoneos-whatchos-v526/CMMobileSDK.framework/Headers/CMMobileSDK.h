//
//  CMMobileSDK.h
//  CMMobileSDK
//
//  Created by Denys Ianchyk on 12/04/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CMMobileSDK.
FOUNDATION_EXPORT double CMMobileSDKVersionNumber;

//! Project version string for CMMobileSDK.
FOUNDATION_EXPORT const unsigned char CMMobileSDKVersionString[];

#import <CMMobileSDK/CMCameraSniffer.h>
#import <CMMobileSDK/CMCameraStreamer.h>
