//
//  CMCameraStreamerInterface.h
//  CMMobileSDK
//
//  Created by D. Ianchyk on 27/07/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

#ifndef CMCameraStreamerInterface_h
#define CMCameraStreamerInterface_h

#import <UIKit/UIKit.h>
#import "CMStreamerItem.h"

/*!
 @enum
    CMCameraStreamerStatus
 @abstract
    These constants are returned by the CMCameraStreamer status property to indicate whether it can successfully play items.
 @constant
    CMCameraStreamerStatusUnknown
    Indicates that the status of the streamer is not yet known because it has not tried to load new media resources for playback.
 @constant
    CMCameraStreamerStatusReadyToPlay
    Indicates that the streamer is ready to play CMStreamerItem instance.
 @constant
    CMCameraStreamerStatusFailed
    Indicates that the streamer can no longer play CMStreamerItem instance because of an error. The error is described by the value of the failureReason property.
 */
typedef enum : NSUInteger {
    CMCameraStreamerStatusUnknown,
    CMCameraStreamerStatusReadyToPlay,
    CMCameraStreamerStatusFailed,
} CMCameraStreamerStatus;

/*!
 @enum
    CMCameraStreamerPlaybackState
 @abstract
    These constants are returned by the CMCameraStreamer playbackState property to indicate it's playback state.
 @constant
    CMCameraStreamerPlaybackStatePaused
    This state is entered 1) upon receipt of a -pause message or -setRate: message with a value of 0.0, 2) when a change in overall state requires playback to be halted, such as when an interruption occurs on iOS or 3) when the streamer has no item to play, i.e. when the receiver's currentItem is nil.
    In this state, playback is paused indefinitely and will not resume until 1) a subsequent -play message is received or 2) a -setRate: message with a non-zero value for rate is received and sufficient media data has been buffered for playback to proceed.
 @constant
    CMCameraStreamerPlaybackStateBuffering
    This state is entered when 1) the playback buffer becomes empty and playback stalls in CMCameraStreamerPlaybackStatePlaying, 2) when rate is set from zero to non-zero in CMCameraStreamerPlaybackStatePaused and insufficient media data has been buffered for playback to occur.
    In this state, the value of the rate property is not currently effective but instead indicates the rate at which playback will start or resume.
 @constant
    CMCameraStreamerPlaybackStatePlaying
    In this state, playback is currently progressing and rate changes will take effect immediately. Should playback stall because of insufficient media data, playbackState will change to CMCameraStreamerPlaybackStateBuffering.
 @constant
    CMCameraStreamerPlaybackStateEnded
    This state is entered when playback reaches end of media data. Subsequent -play: or setRate: with non-zero value messages will be ignored, -seekTo:, -stepBy:, -pause: or setRate: with zero value messages will change playbackState to CMCameraStreamerPlaybackStatePaused.
 */
typedef enum : NSUInteger {
    CMCameraStreamerPlaybackStatePaused,
    CMCameraStreamerPlaybackStateBuffering,
    CMCameraStreamerPlaybackStatePlaying,
    CMCameraStreamerPlaybackStateEnded,
} CMCameraStreamerPlaybackState;

/*!
 @enum
    CMCameraStreamerAudioStreamingState
 @abstract
    These constants are returned by the CMCameraStreamer audioStreamingState property to indicate it's audio streaming state.
 @constant
    CMCameraStreamerAudioStreamingStateNotStreaming
    This state is entered 1) upon receipt of a -stopAudioStreaming message or 2) when a change in overall state or some other reason requires streaming to be halted.
 @constant
    CMCameraStreamerAudioStreamingStatePreparing
    This state is entered upon receipt of a -startAudioStreaming message if previous value is CMCameraStreamerAudioStreamingStateNotStreaming.
 @constant
    CMCameraStreamerAudioStreamingStateStreaming
    In this state, audio streming is currently progressing.
 */
typedef enum : NSUInteger {
    CMCameraStreamerAudioStreamingStateNotStreaming,
    CMCameraStreamerAudioStreamingStatePreparing,
    CMCameraStreamerAudioStreamingStateStreaming,
} CMCameraStreamerAudioStreamingState;

/*!
 @enum
    CMCameraStreamerRenderMode
 @abstract
    These constants are the allowable values of CMCameraStreamer's renderMode property. They determine how the video content is scaled or stretched within the streamer layer’s bounds.
 @constant
    CMCameraStreamerRenderModeFillBounds
    Specifies that the video should be stretched to fill the layer’s bounds.
 @constant
    CMCameraStreamerRenderModeAspectFit
    Specifies that the streamer should preserve the video’s aspect ratio and fit the video within the layer’s bounds.
 @constant
    CMCameraStreamerRenderModeAspectFill
    Specifies that the streamer should preserve the video’s aspect ratio and fill the layer’s bounds.
 */
typedef enum : NSUInteger {
    CMCameraStreamerRenderModeFillBounds,
    CMCameraStreamerRenderModeAspectFit,
    CMCameraStreamerRenderModeAspectFill,
} CMCameraStreamerRenderMode;

@protocol CMCameraStreamerInterface;

/*!
 @protocol
    CMCameraStreamerDelegete
 @abstract
    Protocol to which CMCameraStreamerInterface instance's delegate should conform.
 */
@protocol CMCameraStreamerDelegete <NSObject>

@optional
/*!
 @method
    cameraStreamer:onStatusChanged:
 @abstract
    Will be called when CMCameraStreamerInterface instance's status property has been changed.
 @param
    streamer
    An instance conforming to CMCameraStreamerInterface protocol which triggered callback.
 @param
    status
    New value of status property.
 @discussion
    For possible values and discussion, see CMCameraStreamerStatus.
 */
- (void)cameraStreamer:(id<CMCameraStreamerInterface>)streamer onStatusChanged:(CMCameraStreamerStatus)status;

/*!
 @method
    cameraStreamer:onPlaybackStateChanged:
 @abstract
    Will be called when CMCameraStreamerInterface instance's playbackState property has been changed.
 @param
    streamer
    An instance conforming to CMCameraStreamerInterface protocol which triggered callback.
 @param
    playbackState
    New value of playbackState property.
 @discussion
    For possible values and discussion, see CMCameraStreamerPlaybackState.
 */
- (void)cameraStreamer:(id<CMCameraStreamerInterface>)streamer onPlaybackStateChanged:(CMCameraStreamerPlaybackState)playbackState;

/*!
 @method
    cameraStreamer:onAudioStreamingStateChanged:
 @abstract
    Will be called when CMCameraStreamerInterface instance's audioStreamingState property has been changed.
 @param
    streamer
    An instance conforming to CMCameraStreamerInterface protocol which triggered callback.
 @param
    audioStreamingState
    New value of audioStreamingState property.
 @discussion
    For possible values and discussion, see CMCameraStreamerAudioStreamingState.
 */
- (void)cameraStreamer:(id<CMCameraStreamerInterface>)streamer onAudioStreamingStateChanged:(CMCameraStreamerAudioStreamingState)audioStreamingState;

/*!
 @method
    cameraStreamer:onSnapshotTaken:atTime:
 @abstract
    Will be called when CMCameraStreamerInterface instance's snapshot has been generated.
 @param
    streamer
    An instance conforming to CMCameraStreamerInterface protocol which triggered callback.
 @param
    snapshot
    An UIImage created by calling -takeSnapshot message.
 @param
    time
    The time at which the UIImage was created.
 @discussion
    Will be nil if error during generation occured.
    The generated image is not retained.
    Clients should retain the image if they wish it to persist.
 */
- (void)cameraStreamer:(id<CMCameraStreamerInterface>)streamer onSnapshotTaken:(UIImage *)snapshot atTime:(NSTimeInterval)time;

/*!
 @method
    cameraStreamer:onCurrentItemStatusChanged:
 @abstract
    Will be called when CMCameraStreamerInterface instance currentItem's status property has been changed.
 @param
    streamer
    An instance conforming to CMCameraStreamerInterface protocol which triggered callback.
 @param
    status
    New value of currentItem's status property.
 @discussion
    For possible values and discussion, see CMStreamerItemStatus.
 */
- (void)cameraStreamer:(id<CMCameraStreamerInterface>)streamer onCurrentItemStatusChanged:(CMStreamerItemStatus)status;

/*!
 @method
    cameraStreamer:onCurrentItemDurationChanged:
 @abstract
    Will be called when CMCameraStreamerInterface instance currentItem's duration property has been changed.
 @param
    streamer
    An instance conforming to CMCameraStreamerInterface protocol which triggered callback.
 @param
    duration
    New value of currentItem's duration property.
 @discussion
    Will not be called for live streaming.
    Will be called once for closed footage.
    Can be called repeadetly during on-going footage playback.
 */
- (void)cameraStreamer:(id<CMCameraStreamerInterface>)streamer onCurrentItemDurationChanged:(NSTimeInterval)duration;

@end

@class CMMobileSDKError;

/*!
 @protocol
    CMCameraStreamerInterface
 @abstract
    CMCameraStreamerInterface offers a playback interface for single-item playback.
 @discussion
    Visual content of items played by an instance of CMCameraStreamerInterface instance can be displayed in a CoreAnimation layer passed to constructor.
    To ensure safe access to CMCameraStreamerIntefrace instance's nonatomic properties while dynamic changes in playback state may be reported, clients must serialize their access with the receiver's notification queue.
    In the common case, such serialization is naturally achieved by invoking CMCameraStreamerInterface instance's various methods on the main thread or queue.
 */
@protocol CMCameraStreamerInterface <NSObject>

/*!
 @method
    initWithLayer:
 @abstract
    Initializes an instance of object which conforms to CMCameraStreamerInterface protocol.
 @param
    layer
    A CoreAnimation layer to which visual content will be be displayed.
 @result
    An instance of object which conforms to CMCameraStreamerInterface protocol.
 */
- (instancetype)initWithLayer:(CALayer *)layer;

/*!
 @property
    delegate
 @abstract
    Indicates object which will receive and process callbacks.
 */
@property (nonatomic, weak) id<CMCameraStreamerDelegete> delegate;

/*!
 @property
    currentItem
 @abstract
    Indicates the current item of the streamer.
 */
@property (nonatomic, strong) CMStreamerItem *currentItem;

/*!
 @property
    renderMode
 @abstract
    Defines how the video is displayed within an CoreAnimation layer bounds rect.
 @discussion
    For possible values and discussion, see CMCameraStreamerRenderMode.
 */
@property (nonatomic, assign) CMCameraStreamerRenderMode renderMode;

/*!
 @property
    muteAudio
 @abstract
    Indicates whether or not audio output of the player is muted. Only affects audio muting for the player instance and not for the device. By default set to YES.
 */
@property (nonatomic, assign) BOOL muteAudio;

/*!
 @property
    rate
 @abstract
    Indicates the desired rate of playback; 0.0 means "paused", 1.0 indicates a desire to play at the natural rate of the current item.
 */
@property (nonatomic, assign) float rate;

/*!
 @property
    status
 @abstract
    Indicates readiness of streamer to be used for playback.
 @discussion
    For possible values and discussion, see CMCameraStreamerStatus.
 */
@property (readonly) CMCameraStreamerStatus status;

/*!
 @property
    failureReason
 @abstract
    If status is CMCameraStreamerStatusFailed, this property describes the error that caused the failure.
 */
@property (readonly) CMMobileSDKError *failureReason;

/*!
 @property
    playbackState
 @abstract
    Indicates whether playback is currently paused indefinitely, suspended while waiting for appropriate conditions, in progress or reached end of media data.
 @discussion
    For possible values and discussion, see CMCameraStreamerPlaybackState.
 */
@property (readonly) CMCameraStreamerPlaybackState playbackState;

/*!
 @property
    audioStreamingState
 @abstract
    Indicates whether audio streaming session is currently not streaming, being preraped for streaming or actually streaming.
 @discussion
    For possible values and discussion, see CMCameraStreamerAudioStreamingState.
 */
@property (readonly) CMCameraStreamerAudioStreamingState audioStreamingState;

/*!
 @property
    audioNotStreamingReason
 @abstract
    If audioStreamingState becomes CMCameraStreamerAudioStreamingStateNotStreaming unexpectedly (not as result of a -stopAudioStreaming method call), this property describes the reason.
 */
@property (readonly) CMMobileSDKError *audioNotStreamingReason;

/*!
 @property
    currentTime
 @abstract
    Returns the current time of the playback.
 @discussion
    Not key-value observable.
 */
@property (readonly) NSTimeInterval currentTime;

/*!
 @method
    seekToTime:
 @abstract
    Moves the playback cursor.
 @param
    time
    Specified seek time for the current player item.
 @discussion
    Use this method to seek to a specified time for the current player item. The time seeked to may differ from the specified time for efficiency.
 */
- (void)seekTo:(NSTimeInterval)time;

/*!
 @method
    stepBy:
 @abstract
    Moves player's current item's current time forward or backward by the specified number of frames.
 @param
    frameCount
    The number of frames by which to move. A positive number results in stepping forward, a negative number in stepping backward.
 @discussion
    Will pause streamer.
 */
- (void)stepBy:(NSInteger)frameCount;

/*!
 @method
    takeSnapshot
 @abstract
    Generates a UIImage for a stream at current time.
 @discussion
    The delegate will receive -cameraStreamer:onSnapshotTaken:atTime: message for generated image.
 */
- (void)takeSnapshot;

/*!
 @method
    startAudioStreaming
 @abstract
    Starts audio streaming session.
 @discussion
    Will have no effect if audioStreamingState is CMCameraStreamerAudioStreamingStateStreaming or CMCameraStreamerAudioStreamingStatePreparing.
 */
- (void)startAudioStreaming;

/*!
 @method
    stopAudioStreaming
 @abstract
    Stops audio streaming session.
 @discussion
    Will set value of audioNotStreamingReason to nil.
 */
- (void)stopAudioStreaming;


@end

#endif /* CMCameraStreamerInterface_h */
