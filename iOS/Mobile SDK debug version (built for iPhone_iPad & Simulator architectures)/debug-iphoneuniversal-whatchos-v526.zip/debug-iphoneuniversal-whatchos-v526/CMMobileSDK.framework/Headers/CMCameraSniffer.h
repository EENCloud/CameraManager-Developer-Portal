//
//  CMCameraSniffer.h
//  CMMobileSDK
//
//  Created by D. Ianchyk on 08/05/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CMCameraSniffer;
@class CMMobileSDKError;
@class CMDevice;

/**
 Protocol to which CMCameraSniffer's delegate should conform.
 */
@protocol CMCameraSnifferDelegete <NSObject>
    
@optional
/*!
 @method
    cameraSniffer:onFound:
 @abstract
    Will be called when new camera has been detected in the network.
 @param
    sniffer
    CMCameraSniffer instance which triggered callback.
 @param
    device
    object which represents found cloud camera.
 */
- (void)cameraSniffer:(CMCameraSniffer *_Nullable)sniffer onFound:(CMDevice *_Nullable)device;

/*!
 @method
    cameraSniffer:onLost:
 @abstract
    Will be called when discovered camera doesn't respond for the broadcast message.
 @param
    sniffer
    CMCameraSniffer instance which triggered callback.
 @param
    device
    object object which represents lost cloud camera.
 */
- (void)cameraSniffer:(CMCameraSniffer *_Nullable)sniffer onLost:(CMDevice *_Nullable)device;

/*!
 @method
    cameraSniffer:onFoundManually:
 @abstract
    Will be called if camera has beed found using -searchDeviceManuallyAt: method.
 @param
    sniffer
    CMCameraSniffer instance which triggered callback.
 @param
    device
    object which represents found cloud camera.
 */
- (void)cameraSniffer:(CMCameraSniffer *_Nullable)sniffer onFoundManually:(CMDevice *_Nullable)device;

/*!
 @method
    cameraSniffer:onError:
 @abstract
    Will be called if there's an error in the process of sniffing a camera.
 @param
    sniffer
    CMCameraSniffer instance which triggered callback.
 @param
    error
    object with error code, general and detail messages.
 */
- (void)cameraSniffer:(CMCameraSniffer *_Nullable)sniffer onError:(CMMobileSDKError *_Nonnull)error;
    
@end

/**
 Class which helps find cloud cameras in local network.
 */
@interface CMCameraSniffer : NSObject

/**
 Object which will receive and process callbacks.
 */
@property (weak, nonatomic) id<CMCameraSnifferDelegete>_Nullable delegate;

/**
 Set with all found cloud cameras.
 */
@property (readonly) NSSet<CMDevice *> * _Nullable foundDevices;

/**
 Returns true if broadcasting is active.
 */
@property (readonly) BOOL isSniffing;

/**
 Constructs CMCameraSniffer instance.
 */
- (nonnull instancetype)initWithDelegate:(id<CMCameraSnifferDelegete>_Nullable)delegate;

/**
 Starts broadcasting for cloud cameras discovery.
 */
- (void)startSniffing;

/**
 Stops broadcasting.
 */
- (void)stopSniffing;

/**
 Searches device at given IP.
 */
- (void)searchDeviceManuallyAt:(NSString *_Nullable)ipAddress;
    
@end
