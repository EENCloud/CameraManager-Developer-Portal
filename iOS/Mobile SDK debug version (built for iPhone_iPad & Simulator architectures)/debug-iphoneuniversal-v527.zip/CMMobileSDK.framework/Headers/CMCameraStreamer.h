//
//  CMCameraStreamer.h
//  CMMobileSDK
//
//  Created by D. Ianchyk on 08/05/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

#import "CMCameraStreamerInterface.h"

@interface CMCameraStreamer : NSObject <CMCameraStreamerInterface>

- (instancetype)initWithLayer:(CALayer *)layer;

@property (nonatomic, weak) id<CMCameraStreamerDelegete> delegate;
@property (nonatomic, strong) CMStreamerItem *currentItem;

@property (nonatomic, assign) CMCameraStreamerRenderMode renderMode;
@property (nonatomic, assign) BOOL muteAudio;
@property (nonatomic, assign) float rate;

@property (readonly) CMCameraStreamerStatus status;
@property (readonly) CMMobileSDKError *failureReason;
@property (readonly) CMCameraStreamerPlaybackState playbackState;
@property (readonly) CMCameraStreamerAudioStreamingState audioStreamingState;
@property (readonly) CMMobileSDKError *audioNotStreamingReason;
@property (readonly) NSTimeInterval currentTime;

- (void)seekTo:(NSTimeInterval)time;
- (void)stepBy:(NSInteger)frameCount;
- (void)takeSnapshot;
- (void)startAudioStreaming;
- (void)stopAudioStreaming;

@end
