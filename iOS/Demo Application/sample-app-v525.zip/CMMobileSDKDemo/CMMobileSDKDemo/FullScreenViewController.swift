//
//  FullScreenViewController.swift
//  CMMobileSDKDemo
//
//  Created by David Puscas on 16/05/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class FullScreenViewController: UIViewController, CMCameraStreamerDelegete {
    
    // MARK: - Public properties
    var streamer: CMCameraStreamer!
    var renderLayer: CALayer!
    var recordingInterval: RecordingInterval?
    var playingRate: Float = 1.0
    
    // MARK: - Private properties
    private var updateUITimer: Timer?
    private var seekSupported = false
    
    // MARK: - IBOutlets
    @IBOutlet weak var frameImageView: UIImageView!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var fullScreenButton: UIButton!
    @IBOutlet weak var muteAudioLabel: UILabel!
    @IBOutlet weak var muteAudioSwitch: UISwitch!
    @IBOutlet weak var timeSlider: UISlider!
    @IBOutlet weak var timePositionLabel: UILabel!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

    // MARK: - IBActions
    @IBAction func fullScreenButtonTapped(_ sender: UIButton) {
        if isIpad {
            streamer.muteAudio = true
        }
        
        dismiss(animated: true)
    }
    
    @IBAction func playButtonTapped(_ sender: UIButton) {
        streamer.rate = streamer.playbackState == CMCameraStreamerPlaybackStatePaused ? playingRate : 0.0
    }
    
    @IBAction func timeSliderValueChanged() {
        streamer.seek(to: TimeInterval(timeSlider.value) * streamer.currentItem.duration)
    }

    @IBAction func muteAudioSwitched(_ sender: UISwitch) {
        streamer.muteAudio = sender.isOn

        updateMuteAudioUI()
    }
    
    // MARK: - UIViewController methods
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        seekSupported = UInt8(streamer.currentItem.capabilitiesMask.rawValue) & UInt8(CMStreamerItemCapabilitiesMaskCanSeek.rawValue) > 0
        timeSlider.isHidden = !seekSupported
        timePositionLabel.isHidden = !seekSupported
        
        streamer.delegate = self
        playingRate = streamer.rate
        
        setupRenderLayer()
        createUpdateUITimer()
        updatePlayButtonTitle()
        updateControlsState()
        updateTimeSlider()
        updateMuteAudioUI()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        removeUpdateUITimer()
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .landscape
    }
    
    override var shouldAutorotate: Bool {
        return !isBeingDismissed
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        if let superlayer = renderLayer.superlayer {
            renderLayer.frame = superlayer.bounds
        }
    }

    // MARK: - CMCameraStreamerDelegete implementation
    func cameraStreamer(_ streamer: CMCameraStreamerInterface!, onStatusChanged status: CMCameraStreamerStatus) {
        switch status {
        case CMCameraStreamerStatusFailed:
            let error = streamer.failureReason!
            showAlertPopup(with: "An error has occured: \(error.detailMessage ?? error.generalMessage)")
        case CMCameraStreamerStatusReadyToPlay:
            streamer.rate = playingRate
            break
        default:
            break
        }
        
        updateControlsState()
    }
    
    func cameraStreamer(_ streamer: CMCameraStreamerInterface!, onPlaybackStateChanged playbackState: CMCameraStreamerPlaybackState) {
        updatePlayButtonTitle()
        updateControlsState()
    }
    
    func cameraStreamer(_ streamer: CMCameraStreamerInterface!, onCurrentItemDurationChanged duration: TimeInterval) {
        updateControlsState()
    }

    // MARK: - UI update timer lifecycle
    func createUpdateUITimer() {
        guard seekSupported, updateUITimer == nil else {
            return;
        }
        
        updateUITimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(updateUITimerTick), userInfo: nil, repeats: true)
        updateUITimer?.fire()
    }
    
    func removeUpdateUITimer() {
        updateUITimer?.invalidate()
        updateUITimer = nil
    }
    
	@objc func updateUITimerTick() {
        updateTimeSlider()
    }
    
    // MARK: - UI update methods
    func updatePlayButtonTitle() {
        playButton.setTitle(streamer.playbackState == CMCameraStreamerPlaybackStatePaused ? "Play" : "Pause", for: .normal)
    }
    
    func updateControlsState() {
        let streamerReadyToPlay = streamer.status == CMCameraStreamerStatusReadyToPlay
        let streamerIsBuffering = streamer.playbackState == CMCameraStreamerPlaybackStateBuffering
        setControlsEnabled(streamerReadyToPlay && !streamerIsBuffering)
        fullScreenButton.isEnabled = true
    }
    
    func updateMuteAudioUI() {
        muteAudioSwitch.isOn = streamer.muteAudio
        muteAudioLabel.text = streamer.muteAudio ? "muted" : "unmuted"
    }
    
    func updateTimeSlider() {
        guard let recordingInterval = recordingInterval else {
            return
        }
        
        if timeSlider.isHighlighted {
            timePositionLabel.text = (recordingInterval.startTime.timeIntervalSince1970 + streamer.currentItem.duration * TimeInterval(timeSlider.value)).toString()
            return
        }
        
        if streamer.playbackState != CMCameraStreamerPlaybackStateBuffering {
            timeSlider.value = Float(streamer.currentTime/streamer.currentItem.duration)
            timePositionLabel.text = (recordingInterval.startTime.timeIntervalSince1970 + streamer.currentTime).toString()
        }
    }
    
    func setupRenderLayer() {
        renderLayer.removeFromSuperlayer()
        frameImageView.layer.addSublayer(renderLayer)
        renderLayer.frame = renderLayer.superlayer!.bounds
    }
}
