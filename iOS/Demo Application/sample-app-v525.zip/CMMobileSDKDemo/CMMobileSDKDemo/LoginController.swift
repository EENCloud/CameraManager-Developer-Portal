//
//  LoginController.swift
//  CMMobileSDKDemo
//
//  Created by David Puscas on 10/05/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class AccessTokenHolder : CMAccessTokenProviderDelegate {
    var accessToken: String = "undefined"
}

extension UIViewController {
    func setControlsEnabled(_ enabled : Bool) {
        view.subviews.filter { $0 is UIControl }.forEach { ($0 as! UIControl).isEnabled = enabled }
        view.subviews.filter { $0 is UIActivityIndicatorView }.forEach {
            let indicator = $0 as! UIActivityIndicatorView
            enabled ? indicator.stopAnimating() : indicator.startAnimating()
        }
    }
    
    func showAlertPopup(with message : String) {
		let alert = UIAlertController(title: "Error", message: message, preferredStyle: UIAlertController.Style.alert)
		alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

class LoginController: UIViewController, UITextFieldDelegate {
    
    static let tokenHolder = AccessTokenHolder()
    var selectedEnvironment : Environment = .production
    
    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loginTextField.attributedPlaceholder = NSAttributedString(string: "enter username",
                                                                  attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        passwordTextField.attributedPlaceholder = NSAttributedString(string: "enter password",
                                                                  attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        
        CMAccessTokenProvider.delegate = LoginController.tokenHolder
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.backgroundTapped(_:))))
    }
    
	@objc func backgroundTapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }

    @IBAction func loginButtonTapped() {
        guard let username = loginTextField.text, let password = passwordTextField.text, username.count > 0, password.count > 0 else {
            showAlertPopup(with: "Username/password are incorrect. Please enter correct data")
            return
        }
        
        setControlsEnabled(false)
        
        RESTHelper.login(at: .production, username: username, password: password) { [weak self] token, error in
            if let error = error {
                self?.showAlertPopup(with: "Can't login: \(error)")
            } else if let token = token {
                LoginController.tokenHolder.accessToken = token
                self?.performSegue(withIdentifier: "presentTabBar", sender: nil)
            }
            
            self?.setControlsEnabled(true)
        }
    }
}
