//
//  SpecialWizardBridge.swift
//  CMMobileSDKDemo
//
//  Created by D. Ianchyk on 23/10/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

import CMMobileSDK

protocol SpecialWizardInterface {
    func prepareForConnection(with options: [String : Any])
    func connectToCamera()
    func refreshWifiList()
    func getListOfAvailableCarriers() -> [CMCarrier]
    func connectCamera(to network: CMNetworkInterface, withName cameraName: String)
    func cancelCurrentOperation()
}

protocol SpecialWizardDelegate {
    func onPreparedForConnection()
    func onConnectedToCamera(_ option: CMMobileSetupOption)
    func onWifiListRefreshed(_ wifiList: [CMWifiNetwork])
    func onFinished(_ cameraId: Int)
    func onError(_ error: CMMobileSDKError)
}

enum SpecialWizardType {
    case nubo, doorbell
}

class SpecialWizardBridge : NSObject, SpecialWizardInterface {
    private var wizard : SpecialWizardInterface?

    var delegate : SpecialWizardDelegate? = nil
    
    var type : SpecialWizardType = .doorbell {
        didSet {
            reset()
        }
    }
    
    func reset() {
        wizard?.cancelCurrentOperation()
        
        switch type {
        case .nubo:
            wizard = CMNuboCamWizard(delegate: self)
        case .doorbell:
            wizard = CMDoorbellWizard(delegate: self)
        }
    }
    
    func prepareForConnection(with options: [String : Any]) {
        wizard?.prepareForConnection(with: options)
    }
    
    func connectToCamera() {
        wizard?.connectToCamera()
    }
    
    func refreshWifiList() {
        wizard?.refreshWifiList()
    }
    
    func getListOfAvailableCarriers() -> [CMCarrier] {
        return wizard?.getListOfAvailableCarriers() ?? []
    }
    
    func connectCamera(to network: CMNetworkInterface, withName cameraName: String) {
        wizard?.connectCamera(to: network, withName: cameraName)
    }
    
    func cancelCurrentOperation() {
        wizard?.cancelCurrentOperation()
    }
}

// adopting bridge to doorbell wizard callbacks
extension SpecialWizardBridge : CMNuboCamWizardDelegete {
    func nuboCamWizardOnPreparedForConnection(_ wizard: CMNuboCamWizard) {
        delegate?.onPreparedForConnection()
    }
    
    func nuboCamWizard(_ wizard: CMNuboCamWizard, onConnectedToCameraWithMobileSetupOption option: CMMobileSetupOption) {
        delegate?.onConnectedToCamera(option)
    }
    
    func nuboCamWizard(_ wizard: CMNuboCamWizard, onWifiListRefreshed wifiList: [CMWifiNetwork]) {
        delegate?.onWifiListRefreshed(wifiList)
    }
    
    func nuboCamWizard(_ wizard: CMNuboCamWizard, onFinished cameraId: Int) {
        delegate?.onFinished(cameraId)
    }
    
    func nuboCamWizard(_ wizard: CMNuboCamWizard, onError error: CMMobileSDKError) {
        delegate?.onError(error)
    }
}

// adopting bridge to doorbell wizard callbacks
extension SpecialWizardBridge : CMDoorbellWizardDelegete {
    func doorbellWizardOnPreparedForConnection(_ wizard: CMDoorbellWizard) {
        delegate?.onPreparedForConnection()
    }
    
    func doorbellWizardOnConnectedToCamera(_ wizard: CMDoorbellWizard) {
        delegate?.onConnectedToCamera(.notAvailable)
    }
    
    func doorbellWizard(_ wizard: CMDoorbellWizard, onWifiListRefreshed networks: [CMWifiNetwork]) {
        delegate?.onWifiListRefreshed(networks)
    }
    
    func doorbellWizard(_ wizard: CMDoorbellWizard, onFinished cameraId: Int) {
        delegate?.onFinished(cameraId)
    }
    
    func doorbellWizard(_ wizard: CMDoorbellWizard, onError error: CMMobileSDKError) {
        delegate?.onError(error)
    }
}

// adopting nubocam wizard interface to special wizard interface
extension CMNuboCamWizard : SpecialWizardInterface { }

// adopting doorbell wizard interface to special wizard interface
extension CMDoorbellWizard : SpecialWizardInterface {
    func getListOfAvailableCarriers() -> [CMCarrier] {
        return []
    }
    
    func connectCamera(to network: CMNetworkInterface, withName cameraName: String) {
        if let wifiNetwork = network as? CMWifiNetwork {
            connectCamera(to: wifiNetwork, withName: cameraName)
        }
    }
}

// adding default implementation for protocol methods
extension SpecialWizardDelegate {
    func onPreparedForConnection() {}
    func onConnectedToCamera(_ option: CMMobileSetupOption) {}
    func onWifiListRefreshed(_ wifiList: [CMWifiNetwork]) {}
    func onFinished(_ cameraId: Int) {}
    func onError(_ error: CMMobileSDKError) {}
}
