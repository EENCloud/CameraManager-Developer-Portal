//
//  RESTHelpers.swift
//  CMMobileSDKDemo
//
//  Created by Denys Ianchyk on 26/05/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import Moya
import SwiftyJSON
import CMMobileSDK

class RESTHelper {
    static func login(at environment: Environment, username: String, password: String,  completionClosure: @escaping (_ token: String?, _ error: String?) -> Void) {
        MoyaProvider<RESTTarget>().request(.oAuth(environment, username, password)) { result in
            switch result {
            case .success(let response):
                guard let _ = try? response.filterSuccessfulStatusCodes() else {
                    completionClosure(nil, "Login request failed with code: \(response.statusCode)")
                    return
                }
                
                guard let json = try? JSON(data: response.data), let tokenValue = json["access_token"].string else {
                    completionClosure(nil, "Can't parse response from server")
                    return
                }
                
                completionClosure(tokenValue, nil)
            case .failure(let error) :
                completionClosure(nil, error.errorDescription)
            }
        }
    }
    
    static func logout(at environment: Environment, completionClosure: @escaping (_ error: String?) -> Void) {
        MoyaProvider<RESTTarget>().request(.logout(environment)) { result in
            switch result {
            case .success(let response):
                guard let _ = try? response.filterSuccessfulStatusCodes() else {
                    completionClosure("Logout request failed with code: \(response.statusCode)")
                    return
                }
                
                completionClosure(nil)
            case .failure(let error) :
                completionClosure(error.errorDescription)
            }
        }
    }
    
    static func fetchRecordings(at environment: Environment, for cameraId: Int, limit: Int, completionClosure: @escaping (_ recordings: CameraRecordings?, _ error: String?) -> Void) {
        MoyaProvider<RESTTarget>().request(.getCameraRecordings(environment, cameraId, limit)) { result in
            switch result {
            case let .success(response):
                guard let _ = try? response.filterSuccessfulStatusCodes() else {
                    completionClosure(nil, "Fetch recordings request failed with code: \(response.statusCode)")
                    return
                }
                
                guard let json = try? JSON(data: response.data).arrayValue, let cameraRecordings = CameraRecordings(from: json, for: environment, with: cameraId) else {
                    completionClosure(nil, "Can't parse response from server")
                    return
                }
                
                completionClosure(cameraRecordings, nil)
            case let .failure(error):
                completionClosure(nil, error.errorDescription)
            }
        }
    }
}
