//
//  RecordingsController.swift
//  CMMobileSDKDemo
//
//  Created by Denys Ianchyk on 01/06/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import UIKit

extension Date {
    func contertToString(withFormat format: String ) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        return formatter.string(from: self)
    }
}

class RecordingsController : UITableViewController {
    
    public var intervals : [RecordingInterval]!
 
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return intervals.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let interval = intervals[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "INTERVAL_CELL_IDENTIFIER", for: indexPath)
        cell.textLabel?.text = interval.startTime.contertToString(withFormat: "yyyy-MM-dd HH:mm:ss")
        cell.detailTextLabel?.text = interval.endTime?.contertToString(withFormat: "yyyy-MM-dd HH:mm:ss") ?? "Now"
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "presentFootagePage", sender: intervals[indexPath.row])
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let controller = segue.destination as? FootageStreamController, let interval = sender as? RecordingInterval else {
            return
        }
        
        controller.recordingInterval = interval
    }    
}
