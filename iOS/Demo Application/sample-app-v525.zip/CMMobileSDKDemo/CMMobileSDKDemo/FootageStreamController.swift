//
//  FootageStreamController.swift
//  CMMobileSDKDemo
//
//  Created by David Puscas on 12/05/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

extension TimeInterval {
    func toString() -> String {
        if self == 0 {
            return ""
        }
        return Date(timeIntervalSince1970:self).contertToString(withFormat: "HH:mm:ss.S")
    }
}

class FootageStreamController: UIViewController, CMCameraStreamerDelegete, SelectableViewController {
    
    // MARK: - SelectableViewController
    var selected: Bool = false {
        didSet {
            if !selected {
                pauseStream()
            }
        }
    }
    
    // MARK: - Public properties
    var recordingInterval: RecordingInterval!
    
    // MARK: - Private properties
    private var streamer: CMCameraStreamer!
    private var renderLayer: CALayer!
    private var updateUITimer: Timer?
    private let rates: [Float] = [1.0, 2.0, 5.0, 10.0]
    private var rateIndex = 0
    private var currentRate: Float {
        return rates[rateIndex]
    }
    private var frameStepCount = 1

    // MARK: - IBOutlets
    @IBOutlet weak var frameImageView: UIImageView!
    @IBOutlet weak var playButton: UIButton!    
    @IBOutlet weak var timeSlider: UISlider!
    @IBOutlet weak var timePositionLabel: UILabel!
    @IBOutlet weak var debugLabel: UILabel!
    @IBOutlet weak var nextFrameButton: UIView!
    @IBOutlet weak var prevFrameButton: UIView!
    @IBOutlet weak var speedRateButton: UIButton!
    
    // MARK: - IBActions
    @IBAction func playButtonTapped(_ sender: UIButton) {
        switch streamer.playbackState {
        case CMCameraStreamerPlaybackStatePaused:
            playStream()
        case CMCameraStreamerPlaybackStatePlaying:
            pauseStream()
        default:
            break
        }
    }

    @IBAction func nextFrameButtonTapped(_ sender: UIButton) {
        stepStream(by: frameStepCount)
    }
    
    @IBAction func prevFrameButtonTapped(_ sender: UIButton) {
        stepStream(by: -frameStepCount)
    }
    
    @IBAction func timeSliderValueChanged() {
        streamer.seek(to: TimeInterval(timeSlider.value) * streamer.currentItem.duration)
    }
    
    @IBAction func speedRateButtonTapped(_ sender: UIButton) {
        rateIndex = (rateIndex + 1) % rates.count
        
        updateSpeedRateButton()
        
        if streamer.playbackState == CMCameraStreamerPlaybackStateBuffering || streamer.playbackState == CMCameraStreamerPlaybackStatePlaying {
            playStream()
        }
    }
    
    // MARK: - UIViewController methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let item = CMStreamerItem.init(cameraId: recordingInterval.cameraId, recordingId: recordingInterval.recordingId)
        
        renderLayer = CALayer(layer: frameImageView.layer)
        
        streamer = CMCameraStreamer(layer: renderLayer)
        streamer.currentItem = item
        streamer.muteAudio = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        streamer.delegate = self
        
        setupRenderLayer()
        updateRenderLayerFrame()
        createUpdateUITimer()
        updateSpeedRateButton()
        updatePlayButtonTitle()
        updateControlsState()
        updateTimeSlider()
        updateDebugLabel()        
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        updateRenderLayerFrame()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        removeUpdateUITimer()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let fullScreenViewController = segue.destination as? FullScreenViewController else {
            return
        }
        
        fullScreenViewController.streamer = streamer
        fullScreenViewController.renderLayer = renderLayer
        fullScreenViewController.recordingInterval = recordingInterval
    }
    
    // MARK: - CMCameraStreamerDelegete implementation
    func cameraStreamer(_ streamer: CMCameraStreamerInterface!, onStatusChanged status: CMCameraStreamerStatus) {
        switch status {
        case CMCameraStreamerStatusFailed:
            let error = streamer.failureReason!
            showAlertPopup(with: "An error has occured: \(error.detailMessage ?? error.generalMessage)")
        case CMCameraStreamerStatusReadyToPlay:
            playStream()
            break
        default:
            break
        }
        
        updateControlsState()
        updateDebugLabel()
    }
    
    func cameraStreamer(_ streamer: CMCameraStreamerInterface!, onPlaybackStateChanged playbackState: CMCameraStreamerPlaybackState) {
        updatePlayButtonTitle()
        updateControlsState()
        updateDebugLabel()
    }
    
    func cameraStreamer(_ streamer: CMCameraStreamerInterface!, onCurrentItemDurationChanged duration: TimeInterval) {
        updateControlsState()
    }
    
    // MARK: - UI update timer lifecycle
    func createUpdateUITimer() {
        if updateUITimer == nil {
            updateUITimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(updateUITimerTick), userInfo: nil, repeats: true)
            updateUITimer?.fire()
        }
    }
    
    func removeUpdateUITimer() {
        updateUITimer?.invalidate()
        updateUITimer = nil
    }
    
	@objc func updateUITimerTick() {
        updateTimeSlider()
    }
    
    // MARK: - UI update methods
    func updatePlayButtonTitle() {
        switch streamer.playbackState {
        case CMCameraStreamerPlaybackStatePaused:
            playButton.setTitle("Play", for: .normal)
        case CMCameraStreamerPlaybackStatePlaying:
            playButton.setTitle("Pause", for: .normal)
        default:
            break
        }

        playButton.isHidden = streamer.playbackState == CMCameraStreamerPlaybackStateEnded
    }
    
    func updateSpeedRateButton() {
        speedRateButton.setTitle("x\(currentRate)", for: .normal)
    }
    
    func updateControlsState() {
        let seekSupported = UInt8(streamer.currentItem.capabilitiesMask.rawValue) & UInt8(CMStreamerItemCapabilitiesMaskCanSeek.rawValue) > 0
        timeSlider.isHidden = !seekSupported
        timePositionLabel.isHidden = !seekSupported

        let stepSupported = UInt8(streamer.currentItem.capabilitiesMask.rawValue) & UInt8(CMStreamerItemCapabilitiesMaskCanStep.rawValue) > 0
        nextFrameButton.isHidden = !stepSupported
        prevFrameButton.isHidden = !stepSupported
        
        let speedPlaySupported = UInt8(streamer.currentItem.capabilitiesMask.rawValue) & UInt8(CMStreamerItemCapabilitiesMaskCanSpeedPlay.rawValue) > 0
        speedRateButton.isHidden = !speedPlaySupported
        
        let streamerReadyToPlay = streamer.status == CMCameraStreamerStatusReadyToPlay
        let streamerIsBuffering = streamer.playbackState == CMCameraStreamerPlaybackStateBuffering
        setControlsEnabled(streamerReadyToPlay && !streamerIsBuffering)
    }
    
    func updateTimeSlider() {
        if timeSlider.isHighlighted {
            timePositionLabel.text = (recordingInterval.startTime.timeIntervalSince1970 + streamer.currentItem.duration * TimeInterval(timeSlider.value)).toString()
            return
        }
            
        if streamer.playbackState != CMCameraStreamerPlaybackStateBuffering {
            timeSlider.value = Float(streamer.currentTime/streamer.currentItem.duration)
            timePositionLabel.text = (recordingInterval.startTime.timeIntervalSince1970 + streamer.currentTime).toString()
        }
    }
    
    func updateDebugLabel() {
        switch streamer.status {
        case CMCameraStreamerStatusUnknown:
            debugLabel.text = "Loading..."
        case CMCameraStreamerStatusFailed:
            debugLabel.text = "Failed"
        default:
            break
        }
        
        guard streamer.status == CMCameraStreamerStatusReadyToPlay else {
            return
        }
        
        switch streamer.playbackState {
        case CMCameraStreamerPlaybackStatePaused:
            debugLabel.text = "Paused"
        case CMCameraStreamerPlaybackStateBuffering:
            debugLabel.text = "Buffering"
        case CMCameraStreamerPlaybackStatePlaying:
            debugLabel.text = "Playing"
        case CMCameraStreamerPlaybackStateEnded:
            debugLabel.text = "Ended"
        default:
            debugLabel.text = "Unknown"
        }
    }
    
    func setupRenderLayer() {
        renderLayer.removeFromSuperlayer()
        frameImageView.layer.addSublayer(renderLayer)
    }
    
    func updateRenderLayerFrame() {
        renderLayer.frame = renderLayer.superlayer!.bounds
    }
    
    // MARK: - stream manipulations
    func playStream() {
        streamer.rate = currentRate
    }
    
    func pauseStream() {
        streamer.rate = 0.0
    }
    
    func stepStream(by frameCount: Int) {
        streamer.step(by: frameCount)
    }
}
