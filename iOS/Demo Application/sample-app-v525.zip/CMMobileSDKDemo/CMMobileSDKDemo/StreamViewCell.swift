//
//  StreamViewCell.swift
//  CMMobileSDKDemo
//
//  Created by Denys Ianchyk on 01/06/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import UIKit

class StreamViewCell: UICollectionViewCell {
 
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var imageView: UIImageView!
    
    func set(selected: Bool) {
        backgroundColor = selected ? UIColor.red.withAlphaComponent(0.5) : .clear
    }
}

