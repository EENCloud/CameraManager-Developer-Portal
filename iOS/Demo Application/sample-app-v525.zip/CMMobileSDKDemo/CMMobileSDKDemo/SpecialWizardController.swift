//
//  NuboCamWizardController.swift
//  CMMobileSDKDemo
//
//  Created by D. Ianchyk on 26/01/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class SpecialWizardController: UIViewController, UITextFieldDelegate, SpecialWizardDelegate {
    @IBOutlet weak var zoneTextField: UITextField!
    @IBOutlet weak var prepareForConnectionButton: UIButton!
    @IBOutlet weak var connectToCameraButton: UIButton!
    @IBOutlet weak var selectWifiButton: UIButton!
    @IBOutlet weak var selectCarrierButton: UIButton!
    @IBOutlet weak var enterApnManuallyButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var progressLabel: UILabel!
    @IBOutlet weak var zoneLabel: UILabel!
    @IBOutlet weak var troubleshootSwitch: UISwitch!
    
    private var mode = WizardMode.adding
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        reset()
        updateOptionLabel()
        
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.backgroundTapped(_:))))
    }
    
	@objc func backgroundTapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        SpecialWizardBridge.shared.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        view.endEditing(true)
        return true
    }
    
    @IBAction func troubleshootSwitched() {
        mode = troubleshootSwitch.isOn ? .troubleshooting : .adding
        updateOptionLabel()
    }
    
    @IBAction func buttonTapped(_ sender: UIButton) {
        switch sender {
        case prepareForConnectionButton:
            guard let optionText = zoneTextField.text, let optionId = Int(optionText) else {
                progressLabel.text = "\(mode.optionText) should be integer. Please try again."
                return
            }
            
            activityIndicator.startAnimating()
            troubleshootSwitch.isEnabled = false
            zoneTextField.isEnabled = false
            progressLabel.text = "Preparing for connection..."
            
            let options = [mode.optionKey : optionId]
            SpecialWizardBridge.shared.prepareForConnection(with: options)
        case connectToCameraButton:
            activityIndicator.startAnimating()
            progressLabel.text = "Connecting to camera..."
            SpecialWizardBridge.shared.connectToCamera()
        default:
            break
        }
    }
    
    @IBAction func chooseWizardButtonTapped(_ sender: UIBarButtonItem) {
        let nuboWizardAction = UIAlertAction(title: "Nubo Wizard", style: .default) { [weak self] _ in
            SpecialWizardBridge.shared.type = .nubo
            self?.reset()
        }
        
        let doorbellWizardAction = UIAlertAction(title: "Doorbell Wizard", style: .default) { [weak self] _ in
            SpecialWizardBridge.shared.type = .doorbell
            self?.reset()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        let alert = UIAlertController(title: "Choose wizard", message: nil, preferredStyle: .actionSheet)
        alert.addAction(nuboWizardAction)
        alert.addAction(doorbellWizardAction)
        alert.addAction(cancelAction)
        alert.popoverPresentationController?.barButtonItem = sender
        self.present(alert, animated: true)
    }

    @IBAction func resetButtonPressed(_ sender: UIBarButtonItem) {
        reset()
    }
    
    private func reset() {
        SpecialWizardBridge.shared.reset()
        
        troubleshootSwitch.isEnabled = true
        zoneTextField.isEnabled = true
        prepareForConnectionButton.isEnabled = true
        connectToCameraButton.isEnabled = false
        selectWifiButton.isEnabled = false
        selectCarrierButton.isEnabled = false
        enterApnManuallyButton.isEnabled = false
        activityIndicator.stopAnimating()
        progressLabel.text = "Tap 'Prepare for connection' button."
        navigationItem.title = SpecialWizardBridge.shared.type.navigationTitle
    }
    
    private func updateOptionLabel() {
        zoneLabel.text = mode.optionText
    }    
    
    func onPreparedForConnection() {
        activityIndicator.stopAnimating()
        prepareForConnectionButton.isEnabled = false
        connectToCameraButton.isEnabled = true
        progressLabel.text = "Ready for connection! Connect to \(SpecialWizardBridge.shared.type.networkPatternText) via Settings app and tap 'Connect to device' button."
    }

    func onConnectedToCamera(_ option: CMMobileSetupOption) {
        activityIndicator.stopAnimating()
        connectToCameraButton.isEnabled = false
        selectWifiButton.isEnabled = true
        progressLabel.text = "Connected to camera. " + option.description

        enterApnManuallyButton.isEnabled = option == .ownSim
        selectCarrierButton.isEnabled = SpecialWizardBridge.shared.getListOfAvailableCarriers().count > 0
    }

    func onError(_ error: CMMobileSDKError) {
        activityIndicator.stopAnimating()
        progressLabel.text = "Received error with code: \(error.code)\ngeneral message: \(error.generalMessage)\n detailed message: \(error.detailMessage ?? "no details")"
    }
}

enum WizardMode {
    case adding, troubleshooting
    
    var optionKey : String {
        switch self {
        case .adding:
            return "zoneId"
        case .troubleshooting:
            return "cameraId"
        }
    }
    
    var optionText : String {
        switch self {
        case .adding:
            return "Zone ID"
        case .troubleshooting:
            return "Camera ID"
        }
    }
}

extension SpecialWizardBridge {
    static let shared = SpecialWizardBridge()
}

extension SpecialWizardType {
    var navigationTitle : String {
        switch self {
        case .nubo:
            return "Nubo Wizard"
        case .doorbell:
            return "Doorbell Wizard"
        }
    }
    
    var networkPatternText : String {
        switch self {
        case .nubo:
            return "NUBO_X"
        case .doorbell:
            return "Doorbell-X"
        }
    }
}

extension CMMobileSetupOption {
    var description : String {
        switch self {
        case .notAvailable:
            return "Connection via mobile is not available."
        case .oldFirmware:
            return "Firmware is too old to connect via mobile."
        case .pinRequired:
            return "Sim card is locked by pin."
        case .ownSim:
            return "Camera can be connected via mobile with own sim card."
        case .nuboSim:
            return "Camera can be connected via mobile with Nubo sim card."
        }
    }
}
