//
//  ManualAPNSetupController.swift
//  CMMobileSDKDemo
//
//  Created by D. Ianchyk on 28/02/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class ManualAPNSetupController : UIViewController, UITextFieldDelegate {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.backgroundTapped(_:))))
    }
    
	@objc func backgroundTapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case nameTextField:
            return usernameTextField.becomeFirstResponder()
        case usernameTextField:
            return passwordTextField.becomeFirstResponder()
        case passwordTextField:
            view.endEditing(true)
        default:
            break
        }
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? ConnectionController {
            let apn = CMAccessPointName(with: nameTextField?.text ?? "name",
                                        username: usernameTextField?.text ?? "username",
                                        password: passwordTextField?.text ?? "password")
            destination.networkInterface = apn
        }
    }
}
