//
//  ChooseWifiController.swift
//  CMMobileSDKDemo
//
//  Created by D. Ianchyk on 29/01/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class ChooseWifiController : UITableViewController, SpecialWizardDelegate {
    private var wifiNetworks : [CMWifiNetwork]? = nil
    private var selectedWifiNetwork : CMWifiNetwork? = nil
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        SpecialWizardBridge.shared.delegate = self
        
        refreshWifiList()
    }
    
    @IBAction func refreshButtonTapped(_ sender: UIBarButtonItem) {
        wifiNetworks = nil
        tableView.reloadData()
        
        refreshWifiList()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return wifiNetworks?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let wifiNetwork = wifiNetworks?[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "kTableViewCellWifiIdentifier", for: indexPath)
        if let wifiNetwork = wifiNetwork {
            cell.textLabel?.text = wifiNetwork.ssid
            cell.detailTextLabel?.text = wifiNetwork.encryption + " (\(wifiNetwork.strengthPercentage)%)"
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedWifiNetwork = wifiNetworks?[indexPath.row]
        
        let segueIdentifier = (selectedWifiNetwork?.encryption == "none") ? "moveToConnectionScreen" : "moveToSecuredWifiScreen"
        performSegue(withIdentifier: segueIdentifier, sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.destination {
        case let controller as SecuredWifiController:
            controller.securedWifiNetwork = selectedWifiNetwork
        case let controller as ConnectionController:
            controller.networkInterface = selectedWifiNetwork
        default:
            break
        }
    }
    
    private func refreshWifiList() {
        SpecialWizardBridge.shared.refreshWifiList()
    }
    
    func onWifiListRefreshed(_ wifiList: [CMWifiNetwork]) {
        wifiNetworks = wifiList.sorted { $0.ssid.lowercased() < $1.ssid.lowercased() }
        tableView.reloadData()
    }

    func onError(_ error: CMMobileSDKError) {
        showAlertPopup(with: "Received error with code: \(error.code)\ngeneral message: \(error.generalMessage)\n detailed message: \(error.detailMessage ?? "no details")")
    }
}
