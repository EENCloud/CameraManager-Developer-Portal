//
//  SecuredWifiController.swift
//  CMMobileSDKDemo
//
//  Created by D. Ianchyk on 31/01/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class SecuredWifiController : UIViewController {
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var connectToLabel: UILabel!
    
    var securedWifiNetwork : CMWifiNetwork? = nil
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        connectToLabel.text = "Enter password for \(securedWifiNetwork?.ssid ?? "unknown wifi"):"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        securedWifiNetwork?.password = passwordTextField.text
        
        if let controller = segue.destination as? ConnectionController {
            controller.networkInterface = securedWifiNetwork
        }
    }
}
