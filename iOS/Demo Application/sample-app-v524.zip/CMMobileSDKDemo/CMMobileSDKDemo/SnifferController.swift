//
//  SnifferController.swift
//  CMMobileSDKDemo
//
//  Created by Denys Ianchyk on 24/04/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

extension String {
    func isValidIpAddress() -> Bool {
        var sin = sockaddr_in()
        return self.withCString({ cstring in inet_pton(AF_INET, cstring, &sin.sin_addr) }) == 1
    }
}

class SnifferController: UIViewController, UITableViewDataSource, UITableViewDelegate, CMCameraSnifferDelegete {
    private static let highligthedColor = UIColor(red: 168.0/255.0, green: 255.0/255.0, blue: 168.0/255.0, alpha: 1.0)
    private static let normalColor = UIColor(red: 168.0/255.0, green: 208.0/255.0, blue: 168.0/255.0, alpha: 1.0)
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var ipTextField: UITextField!
    @IBOutlet weak var searchManuallyButton: UIButton!
    
    var devices : [CMDevice] = []
    var newDevices : Set<CMDevice> = []
    var didDevicesListChanged : Bool = false
    var timer : Timer?
    var sniffer : CMCameraSniffer!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        sniffer = CMCameraSniffer(delegate: self)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .play , target: self, action: #selector(snifferButtonTapped(_:)))
        navigationItem.rightBarButtonItem?.isEnabled = true
        navigationItem.title = "Tap play to start sniffing"
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return devices.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard indexPath.row < devices.count else {
            return UITableViewCell()
        }
        
        let device = devices[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DEVICE_CELL_IDENTIFIER", for: indexPath)
        cell.textLabel?.text = device.modelInfo.model
        cell.textLabel?.backgroundColor = .clear
        cell.detailTextLabel?.text = device.address.mac
        cell.detailTextLabel?.backgroundColor = .clear
        cell.contentView.backgroundColor = SnifferController.normalColor
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let device = devices[indexPath.row]
        guard newDevices.contains(device) else {
            return
        }
        
        newDevices.remove(device)
        
        UIView.animate(withDuration: 0.2, animations: {
            cell.contentView.backgroundColor = SnifferController.highligthedColor
        }) { _ in
            UIView.animate(withDuration: 0.3) {
                cell.contentView.backgroundColor = SnifferController.normalColor
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "presentWizardPage", sender: devices[indexPath.row])
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        view.endEditing(true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let addCameraController = segue.destination as? AddCameraController, let device = sender as? CMDevice else {
            return
        }
        
        view.endEditing(true)
        addCameraController.device = device
    }
    
    @IBAction func logoutButtonTapped(_ sender: UIBarButtonItem) {
        sender.isEnabled = false
        
        RESTHelper.logout(at: LoginController.environment) { [weak self] error in
            sender.isEnabled = true
        
            if let error = error {
                self?.showAlertPopup(with: "Can't logout: \(error)")
            } else {
                self?.dismiss(animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func searchManuallyButtonTapped(_ sender: UIButton) {
        guard let ipAddress = ipTextField.text, ipAddress.isValidIpAddress() else {
            showAlertPopup(with: "Entered value is not IP Address")
            return
        }
        
        searchManuallyButton.isEnabled = false
        sniffer.searchDeviceManually(at: ipAddress)
    }
    
	@objc func snifferButtonTapped(_ sender: UIBarButtonItem) {
        sniffer.isSniffing ? stopSniffing() : startSniffing()
    }

    func startSniffing() {
        sniffer.startSniffing()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .pause, target: self, action: #selector(snifferButtonTapped(_:)))
        navigationItem.rightBarButtonItem?.isEnabled = true
        navigationItem.title = "Tap pause to stop sniffing"
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.tick), userInfo: nil, repeats: true)
        timer?.fire()
    }
    
	@objc func tick() {
        if (didDevicesListChanged) {
            didDevicesListChanged = false
			devices = (sniffer.foundDevices?.sorted { $0.address.mac < $1.address.mac })!
            tableView.reloadSections(IndexSet.init(integer : 0), with: .automatic)
        }
    }
    
    func stopSniffing() {
        timer?.invalidate()
        timer = nil

        sniffer.stopSniffing()

        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .play , target: self, action: #selector(snifferButtonTapped(_:)))
        navigationItem.rightBarButtonItem?.isEnabled = true
        navigationItem.title = "Tap play to start sniffing"
        
        didDevicesListChanged = true
        tick()
    }
    
	func cameraSniffer(_ sniffer: CMCameraSniffer?, onFound device: CMDevice?) {
        newDevices.insert(device!)
        didDevicesListChanged = true
    }

	func cameraSniffer(_ sniffer: CMCameraSniffer?, onLost device: CMDevice?) {
        _ = newDevices.remove(device!)
        didDevicesListChanged = true
    }
    
	func cameraSniffer(_ sniffer: CMCameraSniffer?, onFoundManually device: CMDevice?) {
        DispatchQueue.main.async {
            self.searchManuallyButton.isEnabled = true
            self.performSegue(withIdentifier: "presentWizardPage", sender: device)
        }
    }

	func cameraSniffer(_ sniffer: CMCameraSniffer?, onError error: CMMobileSDKError) {
        DispatchQueue.main.async {
            self.stopSniffing()
            self.searchManuallyButton.isEnabled = true
            self.showAlertPopup(with: "Can't sniff: \(error.detailMessage ?? error.generalMessage)")
        }
    }
}
