//
//  TabBarController.swift
//  CMMobileSDKDemo
//
//  Created by Denys Ianchyk on 07/06/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import UIKit

protocol SelectableViewController {
     var selected : Bool { get set }
}

var isIpad : Bool {
    return UIDevice.current.userInterfaceIdiom == .pad
}

// Mechanism to pause/resume streamers on tab switching (tab controller's childs are not released and ViewWill(Dis)Appear are called during presenting FullScreenController as well)
class TabBarController: UITabBarController, UITabBarControllerDelegate {    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.delegate = self
    }
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        set(viewController, selected: true)
    }
    
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        if let selectedViewController = tabBarController.selectedViewController {
            set(selectedViewController, selected: false)
        }
        return true
    }

    func set(_ viewController : UIViewController, selected : Bool) {
        var controller : UIViewController? = viewController
        if let navigationController = controller as? UINavigationController {
            controller = navigationController.topViewController
        }
        
        if var selectableController = controller as? SelectableViewController {
            selectableController.selected = selected
        }
    }
}
