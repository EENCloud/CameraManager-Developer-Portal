//
//  FetchController.swift
//  CMMobileSDKDemo
//
//  Created by Denys Ianchyk on 01/06/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import UIKit

class FetchController : UIViewController {
    
    @IBOutlet weak var cameraIdTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.backgroundTapped(_:))))

		cameraIdTextField.text = String(LoginController.environment.testCameraId)
    }
    
	@objc func backgroundTapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    @IBAction func fetchFootageButtonTapped() {

        guard let cameraString = cameraIdTextField.text, let cameraId = Int(cameraString) else {
            showAlertPopup(with: "Camera ID is incorrent!\nPlease provide proper input data")
            return
        }
        
        setControlsEnabled(false)
        
        RESTHelper.fetchRecordings(at: LoginController.environment, for: cameraId, limit: 200) { [weak self] recordings, error in
            if let error = error {
                self?.showAlertPopup(with: "An error has occured for camera \(cameraId): \(error)")
            } else if let recordings = recordings {
                self?.performSegue(withIdentifier: "presentIntervalsPage", sender: recordings)
            }
            
            self?.setControlsEnabled(true)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let recordings = sender as? CameraRecordings, let controller = segue.destination as? RecordingsController else {
            return
        }
        
        controller.intervals = recordings.intervals
    }
}
