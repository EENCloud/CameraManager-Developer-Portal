//
//  ViewController.swift
//  CMMobileSDKDemo
//
//  Created by Denys Ianchyk on 13/04/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class AddCameraController: UIViewController, UITextFieldDelegate, CMCameraWizardDelegete  {
    
    @IBOutlet weak var modelLabel: UILabel!
    @IBOutlet weak var ipLabel: UILabel!
    @IBOutlet weak var macLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var zoneTextField: UITextField!
    @IBOutlet weak var logsTextView: UITextView!
    
    var device : CMDevice!
    var cameraWizard : CMCameraWizard!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        cameraWizard = CMCameraWizard(delegate: self)
        
        modelLabel.text = device.modelInfo.model
        ipLabel.text = device.address.ip4
        macLabel.text = device.address.mac
        nameTextField.text = "New \(device.modelInfo.model) camera"

        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.backgroundTapped(_:))))
    }
    
	@objc func backgroundTapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case nameTextField:
            return zoneTextField.becomeFirstResponder()
        case zoneTextField:
            view.endEditing(true)
            fallthrough
        default:
            return true
        }
    }
    
    @IBAction func addCameraButtonTapped() {
        logsTextView.text = ""
        
        guard let name = nameTextField.text, let zone = zoneTextField.text, let zoneId = Int(zone) else {
            logsTextView.text = "Input data is incorrent!\nPlease provide proper input data"
            return
        }
        
        setControlsEnabled(false)
        
        cameraWizard.addDevice(device, named: name, atZone: zoneId)
    }
    
    func cameraWizard(_ wizard: CMCameraWizard, onAdded cameraId: Int, forDevice device: CMDevice) {
        logsTextView.text = "Camera was successfully added with id: \(cameraId)"
        setControlsEnabled(true)
    }
    
    func cameraWizard(_ wizard: CMCameraWizard, onError error: CMMobileSDKError, forDevice device: CMDevice) {
        logsTextView.text = "Adding camera fails with error:\n\(error)\nCode: \(error.code)\nGeneral message: \"\(error.generalMessage)\"\nDetails: \"\(error.detailMessage ?? "no info provided")\""
        setControlsEnabled(true)
    }
}
