//
//  ChooseAPNController.swift
//  CMMobileSDKDemo
//
//  Created by D. Ianchyk on 29/01/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class ChooseAPNController : UITableViewController {
    var apns : [CMAccessPointName]? = nil
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apns?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let apn = apns?[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "kTableViewCellAPNIdentifier", for: indexPath)
        if let apn = apn {
            cell.textLabel?.text = apn.name
            cell.detailTextLabel?.text = "username '\(apn.username)' password '\(apn.password)'"
        }        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? ConnectionController,
            let indexPath = tableView.indexPathForSelectedRow,
            let apn = apns?[indexPath.row] {
            destination.networkInterface = apn
        }
    }
}
