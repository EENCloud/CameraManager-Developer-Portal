//
//  ConnectionController.swift
//  CMMobileSDKDemo
//
//  Created by D. Ianchyk on 31/01/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class ConnectionController : UIViewController, SpecialWizardDelegate {
    @IBOutlet weak var connectionDetailsLabel: UILabel!
    @IBOutlet weak var connectButton: UIButton!
    @IBOutlet weak var progressLabel: UILabel!    
    @IBOutlet weak var nameTextField: UITextField!    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    var networkInterface : CMNetworkInterface? = nil
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        SpecialWizardBridge.shared.delegate = self
        
        var details : String = "No network interface selected"
        switch networkInterface {
        case let wifi as CMWifiNetwork:
            details = "Connect to Wifi \"\(wifi.ssid)\""
            if let password = wifi.password {
                details += " with password \"\(password)\""
            }
        case let apn as CMAccessPointName:
            details = "Connect to APN '\(apn.name)' (username: '\(apn.username)'; password: '\(apn.password)')"
        default:
            break
        }
        
        connectionDetailsLabel.text = details
        connectButton.isEnabled = !details.isEmpty
        progressLabel.text = ""
        nameTextField.text = SpecialWizardBridge.shared.type.defaultCameraName
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        view.endEditing(true)
        return true
    }
    
    @IBAction func connectButtonTapped() {
        guard let networkInterface = networkInterface else {
            progressLabel.text = "Can't connect to selected network interface"
            return
        }
        
        guard let nameText = nameTextField.text, String(nameText).count > 1 else {
            progressLabel.text = "Please enter valid camera name"
            return
        }
        
        activityIndicator.startAnimating()
        nameTextField.isEnabled = false
        progressLabel.text = "Connecting camera to selected network and adding it to platform..."
        SpecialWizardBridge.shared.connectCamera(to: networkInterface, withName: String(nameText))
    }
    
    @IBAction func returnBackButtonTapped(_ sender: UIBarButtonItem) {
        navigationController?.popToRootViewController(animated: true)
    }
    
    func onError(_ error: CMMobileSDKError) {
        activityIndicator.stopAnimating()
        progressLabel.text = "Received error with code: \(error.code)\ngeneral message: \(error.generalMessage)\n detailed message: \(error.detailMessage ?? "no details")"
    }

    func onFinished(_ cameraId: Int) {
        activityIndicator.stopAnimating()
        
        progressLabel.text = "Wizard successfully finished process for camera with id: \(cameraId)"
    }
}

extension SpecialWizardType {
    var defaultCameraName : String {
        switch self {
        case .nubo:
            return "My new Nubo"
        default:
            return "My new Doorbell"
        }
    }
}
