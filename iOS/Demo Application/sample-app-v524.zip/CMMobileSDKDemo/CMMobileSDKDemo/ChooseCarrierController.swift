//
//  ChooseCarrierController.swift
//  CMMobileSDKDemo
//
//  Created by D. Ianchyk on 29/01/2018.
//  Copyright © 2018 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class ChooseCarrierController : UITableViewController {
    var carriers : [CMCarrier]? = nil
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        carriers = SpecialWizardBridge.shared.getListOfAvailableCarriers()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return carriers?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "kTableViewCellCarrierIdentifier", for: indexPath)
        if let carrier = carriers?[indexPath.row] {
            cell.textLabel?.text = "Name: \(carrier.name)"
            cell.detailTextLabel?.text = "mcc: \(carrier.mcc); mnc: \(carrier.mnc); ISO: \(carrier.countryIso)"
        } else {
            cell.textLabel?.text = "Unknown carrier"
            cell.detailTextLabel?.text = "No details provided"
        }
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? ChooseAPNController,
            let indexPath = tableView.indexPathForSelectedRow,
            let carrier = carriers?[indexPath.row] {
            destination.apns = carrier.accessPointNamesList
        }
    }
}

