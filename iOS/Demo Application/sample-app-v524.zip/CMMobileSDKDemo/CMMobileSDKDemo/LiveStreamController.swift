//
//  LiveStreamController.swift
//  CMMobileSDKDemo
//
//  Created by David Puscas on 11/05/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import UIKit
import CMMobileSDK

class LiveStreamController: UIViewController, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UIGestureRecognizerDelegate, CMCameraStreamerDelegete, SelectableViewController {
    
    var selected: Bool = false {
        didSet {
            if selected {
                streamerTuples.forEach { $0.streamer.rate = 1.0 }
            } else {
                streamerTuples.forEach { $0.streamer.rate = 0.0 }
            }
        }
    }
    
    private var maxStreamersCount : Int {
        return isIpad ? 4 : 1
    }    
    
    private var streamerTuples : [(streamer: CMCameraStreamer, layer: CALayer)] = [] {
        didSet {
            addStreamButton.isEnabled = streamerTuples.count < maxStreamersCount
            multiViewCollection.reloadData()
        }
    }
    
    private var selectedStreamer : CMCameraStreamer? {
        didSet {
            updatePlayButtonTitle()
            updateSendAudioButtonTitle()
            updateControlsState()
        }
    }
    
    private var selectedLayer : CALayer? {
        return streamerTuples.first(where: { $0.streamer == selectedStreamer })?.layer
    }
    
    @IBOutlet weak var multiviewControls: UIView!
    @IBOutlet weak var cameraIdTextField: UITextField!
    @IBOutlet weak var removeStreamButton: UIButton!
    @IBOutlet weak var addStreamButton: UIButton!
    @IBOutlet weak var multiViewCollection: UICollectionView!
    @IBOutlet weak var fullScreenButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var sendAudioButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(self.backgroundTapped(_:)))
        recognizer.delegate = self
        view.addGestureRecognizer(recognizer)
		
		cameraIdTextField.text = String(LoginController.environment.testCameraId)
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        return !(isIpad && multiViewCollection.bounds.contains(touch.location(in: multiViewCollection)))
    }
    
	@objc func backgroundTapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        selectedStreamer?.delegate = self
        selectedLayer?.removeFromSuperlayer()

        multiViewCollection.reloadData()
        
        updatePlayButtonTitle()
        updateSendAudioButtonTitle()
        updateControlsState()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return streamerTuples.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        return collectionView.dequeueReusableCell(withReuseIdentifier: "FRAME_CELL_IDENTIFIER", for: indexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let streamerTuple = streamerTuples[indexPath.row]
        let layer = streamerTuple.layer
        
        layer.removeFromSuperlayer()
        layer.frame = cell.bounds
        cell.layer.addSublayer(layer)
        
        (cell as? StreamViewCell)?.set(selected: streamerTuple.streamer == selectedStreamer)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // can't select views at iPhone (there are only one streamer) 
        guard isIpad else {
            return
        }
        
        let streamerToSelect = streamerTuples[indexPath.row].streamer
        selectedStreamer = (selectedStreamer == streamerToSelect) ? nil : streamerToSelect
        
        multiViewCollection.visibleCells.forEach { cell in
            if let indexPath = multiViewCollection.indexPath(for: cell) {
                let streamerTuple = streamerTuples[indexPath.row]
                (cell as? StreamViewCell)?.set(selected: streamerTuple.streamer == selectedStreamer)
            }
        }
    }
    
    func cameraStreamer(_ streamer: CMCameraStreamerInterface!, onStatusChanged status: CMCameraStreamerStatus) {
        switch status {
        case CMCameraStreamerStatusFailed:
            let error = streamer.failureReason!
            showAlertPopup(with: "An error has occured: \(error.detailMessage ?? error.generalMessage)")
        case CMCameraStreamerStatusReadyToPlay:
            updateSendAudioButtonTitle()
            streamer.rate = 1.0
        default:
            break
        }
        
        updateControlsState()
    }
    
    func cameraStreamer(_ streamer: CMCameraStreamerInterface!, onAudioStreamingStateChanged audioStreamingState: CMCameraStreamerAudioStreamingState) {
        updateSendAudioButtonTitle()
    }
    
    func cameraStreamer(_ streamer: CMCameraStreamerInterface!, onPlaybackStateChanged playbackState: CMCameraStreamerPlaybackState) {
        updatePlayButtonTitle()
    }
    
    func updatePlayButtonTitle() {
        playButton.setTitle(selectedStreamer?.playbackState == CMCameraStreamerPlaybackStatePaused ? "Play" : "Pause", for: .normal)
    }

    func updateSendAudioButtonTitle() {
        let title : String
        switch selectedStreamer?.currentItem.audioStreamingMethod {
        case CMStreamerItemAudioStreamingMethodPushToTalk:
            title = (selectedStreamer?.audioStreamingState == CMCameraStreamerAudioStreamingStateStreaming) ? "Tap to listen" : "Tap to speak"
        case CMStreamerItemAudioStreamingMethodFullDuplex:
            title = (selectedStreamer?.audioStreamingState == CMCameraStreamerAudioStreamingStateStreaming) ? "Stop full-duplex" : "Start full-duplex"
        default:
            title = ""
        }
        
        sendAudioButton.setTitle(title, for: .normal)
    }
    
    func updateControlsState() {
        if let streamer = selectedStreamer {
            removeStreamButton.isEnabled = true
            fullScreenButton.isEnabled = true
            playButton.isHidden = streamer.status != CMCameraStreamerStatusReadyToPlay
            
            /* alternative semantically equal expression:
             let audioStreamingSupported = streamer.currentItem.audioStreamingMethod != CMStreamerItemAudioStreamingMethodUnsupported
             */
            let audioStreamingSupported = UInt8(streamer.currentItem.capabilitiesMask.rawValue) & UInt8(CMStreamerItemCapabilitiesMaskCanStreamAudio.rawValue) > 0
            sendAudioButton.isHidden = (streamer.status != CMCameraStreamerStatusReadyToPlay) || isIpad || !audioStreamingSupported
        } else {
            removeStreamButton.isEnabled = false
            fullScreenButton.isEnabled = false
            playButton.isHidden = true
            sendAudioButton.isHidden = true
        }
    }
    
    @IBAction func playButtonPressed() {
        guard let cameraStreamer = selectedStreamer else {
            return
        }
        
        cameraStreamer.rate = cameraStreamer.playbackState == CMCameraStreamerPlaybackStatePaused ? 1.0 : 0.0
    }
    
    @IBAction func sendAudioButtonPressed() {
        guard let cameraStreamer = selectedStreamer else {
            return
        }
        
        if cameraStreamer.audioStreamingState == CMCameraStreamerAudioStreamingStateStreaming {
            cameraStreamer.stopAudioStreaming()
        } else {
            cameraStreamer.startAudioStreaming()
        }
    }
    
    @IBAction func removeStreamButtonPressed() {
        guard let streamerToRemove = selectedStreamer else {
            return
        }
        
        selectedLayer?.removeFromSuperlayer()
        selectedStreamer = nil
        streamerTuples = streamerTuples.filter { $0.streamer != streamerToRemove }
    }
    
    @IBAction func addStreamButtonPressed() {
        guard streamerTuples.count < maxStreamersCount,
            let cameraString = cameraIdTextField.text,
            let cameraId = UInt(cameraString) else {
            return
        }
        
        let layer = CALayer()
        let streamer = CMCameraStreamer(layer: layer)!
        streamer.delegate = self
        streamer.muteAudio = isIpad
        
        streamer.currentItem = CMStreamerItem.init(cameraId: cameraId)
            
        // there are only one streamer on iPhone so select it
        if !isIpad {
            selectedStreamer = streamer
        }
        
        streamerTuples.append((streamer, layer))
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let fullScreenViewController = segue.destination as? FullScreenViewController else {
            return
        }
        
        fullScreenViewController.streamer = selectedStreamer
        fullScreenViewController.renderLayer = selectedLayer
        fullScreenViewController.recordingInterval = nil
    }
}
