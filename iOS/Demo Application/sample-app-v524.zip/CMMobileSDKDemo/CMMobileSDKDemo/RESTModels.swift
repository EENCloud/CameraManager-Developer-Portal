//
//  RESTModels.swift
//  CMMobileSDKDemo
//
//  Created by Denys Ianchyk on 26/05/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import SwiftyJSON

struct RecordingInterval {
    public let startTime : Date
    public let endTime : Date?
    public let cameraId : UInt
    public let recordingId: UInt
    
    init?(from json : JSON, for environment: Environment, with cameraId : Int) {
        guard let startTimeString = json["startTime"].string,
            let startTime = RecordingInterval.dateFormatter.date(from: startTimeString),
            let cameraId = json["cameraId"].uInt,
            let recordingId = json["recordingId"].uInt else {
            return nil
        }
        
        self.startTime = startTime
        self.endTime = RecordingInterval.dateFormatter.date(from: json["endTime"].string ?? "")
        self.cameraId = cameraId
        self.recordingId = recordingId
    }
    
    static var dateFormatter : DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZ"
        formatter.locale = Locale(identifier: "en_US_POSIX")
        return formatter
    }()
}

struct CameraRecordings {
    var intervals : [RecordingInterval] = []
    
    init?(from data: [JSON], for environment: Environment, with cameraId : Int) {
        intervals = data.compactMap { RecordingInterval(from: $0, for: environment, with: cameraId) }
        
        if intervals.isEmpty {
            return nil
        }
    }
}
