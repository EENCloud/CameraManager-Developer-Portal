//
//  RESTTargets.swift
//  CMMobileSDKDemo
//
//  Created by Denys Ianchyk on 26/05/2017.
//  Copyright © 2017 Cameramanager. All rights reserved.
//

import Moya
import CMMobileSDK

enum Environment {
    case production
    
    var url : String {
        switch self {
        case .production:
            return "https://rest.cameramanager.com"
        }
    }
    
    var restPort : Int {
        switch self {
        case .production:
            return 443
        }
    }
    
    var oAuthPort : Int {
        switch self {
        case .production:
            return 443
        }
    }
    
    var name : String {
        switch self {
        case .production:
            return "Production"
        }
    }
    
    var testUsername : String {
        switch self {
        case .production:
            return "something@een.com"
        }
    }
    
    var testPassword : String {
        switch self {
        case .production:
            return "password"
        }
    }
    
    var testCameraId : Int {
        switch self {
        case .production:
            return 12345
        }
    }
}

enum RESTTarget {
    case getCameraStream(Environment, Int)
    case getCameraRecordings(Environment, Int, Int)
    case oAuth(Environment, String, String)
    case logout(Environment)
}

extension RESTTarget: TargetType {
    var baseURL: URL {
        switch self {
        case let .getCameraRecordings(environment, _, _), let .getCameraStream(environment, _):
            return URL(string: "\(environment.url):\(environment.restPort)/rest/v2.3")!
        case let .oAuth(environment, _, _):
            return URL(string: "\(environment.url):\(environment.oAuthPort)")!
        case let .logout(environment):
            return URL(string: "\(environment.url):\(environment.restPort)")!
        }
    }
    
    var path: String {
        switch self {
        case let .getCameraStream(_, cameraId):
            return "/cameras/\(cameraId)/streams"
        case let .getCameraRecordings(_, cameraId, _):
            return "/cameras/\(cameraId)/recordings"
        case .logout:
            return "rest/v2.3/users/self/tokens/current"
        case .oAuth:
            return "/oauth/token"
        }
    }
    
    var method: Moya.Method {
        switch self {
        case .getCameraStream, .getCameraRecordings:
            return .get
        case .oAuth:
            return .post
        case .logout:
            return .delete
        }
    }
    
    var parameters: [String: Any]? {
        switch self {
        case .getCameraStream, .logout:
            return nil
        case let .getCameraRecordings(_, _, limit):
            return ["limit" : limit, "sortByRecordingIdOrder" : "desc"]
        case let .oAuth(_, username, password):
            return ["scope": "write", "grant_type": "password", "username" : username, "password" : password]
        }
    }
    
    var parameterEncoding: ParameterEncoding {
        return URLEncoding.queryString
    }
    
    var sampleData: Data {
        return Data()
    }
    
    var task: Task {
        guard let parameters = parameters else {
            return .requestPlain
        }
        
        return .requestParameters(parameters: parameters, encoding: parameterEncoding)
    }
    
    var headers: [String: String]? {
        switch self {
        case .oAuth:
            return ["Authorization": "Basic SU9TOklPUw==", "Content-Type" : "application/json"]
        default:
            return ["Authorization": "Bearer \(CMAccessTokenProvider.delegate?.accessToken ?? "undefined")", "Content-Type" : "application/json"]
        }
    }
}
