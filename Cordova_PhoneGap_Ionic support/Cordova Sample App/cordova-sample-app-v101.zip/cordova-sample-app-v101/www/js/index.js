/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

const kButtonClassLoaded = "baseButton loaded";
const kButtonClassChecking = "baseButton checking";
const kButtonClassPassed = "baseButton passed";
const kButtonClassFailed = "baseButton failed";

const kButtonIdSniffer = "snifferButton";
const kButtonIdCloudCamWizard = "cloudCamWizardButton";
const kButtonIdNuboCamWizard = "nuboCamWizardButton";
const kButtonIdStreamer = "streamerButton";
const kButtonIdReset = "resetButton";
const kDivIdStreamingFrame = "streamingFrame";

var app = {
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },
    
    onDeviceReady: function() {
        this.setupCheckButtons();
        this.setupResetButton();
    },
    
    setupCheckButtons: function() {
        this.setupSnifferButton();
        this.setupCloudWizardButton();
        this.setupNuboWizardButton();
        this.setupStreamerButton();
    },
    
    setupSnifferButton: function() {
        this.setButtonStateLoaded(kButtonIdSniffer);
        document.getElementById(kButtonIdSniffer).onclick = function() {
            this.onclick = null;
            app.setButtonStateChecking(kButtonIdSniffer);
            CMMobileSDK.checkSniffer();
        };
    },
    
    setupCloudWizardButton: function() {
        this.setButtonStateLoaded(kButtonIdCloudCamWizard);
        document.getElementById(kButtonIdCloudCamWizard).onclick = function() {
            this.onclick = null;
            app.setButtonStateChecking(kButtonIdCloudCamWizard);
            CMMobileSDK.checkCloudCamWizard();
        };
    },
    
    setupNuboWizardButton: function() {
        this.setButtonStateLoaded(kButtonIdNuboCamWizard);
        document.getElementById(kButtonIdNuboCamWizard).onclick = function() {
            this.onclick = null;
            app.setButtonStateChecking(kButtonIdNuboCamWizard);
            CMMobileSDK.checkNuboCamWizard();
        };
    },
    
    setupStreamerButton: function() {
        this.setButtonStateLoaded(kButtonIdStreamer);
        document.getElementById(kButtonIdStreamer).onclick = function() {
            this.onclick = null;
            app.setButtonStateChecking(kButtonIdStreamer);

            var streamingFrame = document.getElementById(kDivIdStreamingFrame);
            var width = streamingFrame.offsetWidth;
            var height = streamingFrame.offsetHeight;
            var x = streamingFrame.offsetLeft;
            var y = streamingFrame.offsetTop;
            var frame = [x, y, width, height];
            CMMobileSDK.checkStreamer(3131, frame);
        };
    },
    
    setupResetButton: function() {
        document.getElementById(kButtonIdReset).onclick = function() {
            app.setupCheckButtons();
            CMMobileSDK.reset();
        };
    },
    
    checkButtonCallback: function(buttonId, isPassed) {
        if (isPassed) {
            this.setButtonStatePassed(buttonId);
        } else {
            this.setButtonStateFailed(buttonId);
        }
    },
    
        setButtonStateLoaded(buttonId) {
            this.updateButtonState(buttonId, kButtonClassLoaded, "Check ", "");
        },
    
        setButtonStateChecking(buttonId) {
            this.updateButtonState(buttonId, kButtonClassChecking, "Checking ", "...");
        },
    
        setButtonStatePassed(buttonId) {
            this.updateButtonState(buttonId, kButtonClassPassed, "", " is OK");
        },
    
        setButtonStateFailed(buttonId) {
            this.updateButtonState(buttonId, kButtonClassFailed, "", " failed");
        },
    
    updateButtonState: function(buttonId, newState, prefix, suffix) {
        var button = document.getElementById(buttonId);
        button.className = newState;
        button.innerHTML = prefix + button.name + suffix;
    }
};

app.initialize();