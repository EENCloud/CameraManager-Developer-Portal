var exec = require('cordova/exec');

var CMMobileSDK = {
    checkSniffer: function () {
        exec(null, null, 'CMMobileSdkPlugin', 'checkSniffer', null);
    },

    checkCloudCamWizard: function () {
        exec(null, null, 'CMMobileSdkPlugin', 'checkCloudCamWizard', null);
    },

    checkNuboCamWizard: function () {
        exec(null, null, 'CMMobileSdkPlugin', 'checkNuboCamWizard', null);
    },

    checkStreamer: function (cameraId, frame) {
        exec(null, null, 'CMMobileSdkPlugin', 'checkStreamer', [cameraId, frame]);
    },

    reset: function () {
        exec(null, null, 'CMMobileSdkPlugin', 'reset', null);
    }
};

module.exports = CMMobileSDK;