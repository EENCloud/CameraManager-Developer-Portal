#import "iOSMobileSDKv3.h"
#import <CMMobileSDK/CMMobileSDK.h>

#define kButtonIdSniffer @"snifferButton"
#define kButtonIdCloudCamWizard @"cloudCamWizardButton"
#define kButtonIdNuboCamWizard @"nuboCamWizardButton"
#define kButtonIdStreamer @"streamerButton"

#define kSnifferCheckPassedTimeout 3.0

@interface iOSMobileSDKv3() <CMAccessTokenProviderDelegate, CMCameraSnifferDelegete, CMCameraWizardDelegete, CMNuboCamWizardDelegete, CMCameraStreamerDelegete>

@property (nonatomic, strong) CMCameraSniffer *sniffer;
@property (nonatomic, strong) CMCameraWizard *cloudCamWizard;
@property (nonatomic, strong) CMNuboCamWizard *nuboCamWizard;
@property (nonatomic, strong) CMCameraStreamer *streamer;
@property (nonatomic, strong) UIView *streamerView;

@end

@implementation iOSMobileSDKv3

#pragma mark - CMAccessTokenProviderDelegate

- (NSString *)accessToken {
    return @"access-token-retrieved-by-you-and-passed-here";
}

#pragma mark - Sniffer integration
    
- (void)checkSniffer:(CDVInvokedUrlCommand*)command {
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];

    CMAccessTokenProvider.delegate = self;
    
    CMCameraSniffer *sniffer = [[CMCameraSniffer alloc] initWithDelegate:self];
    self.sniffer = sniffer;
    [self.sniffer startSniffing];

    __weak iOSMobileSDKv3 *weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(kSnifferCheckPassedTimeout * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [weakSelf cameraSniffer:sniffer passed:NO];
    });
}

- (void)cameraSniffer:(CMCameraSniffer *)sniffer onLost:(CMDevice *)device {
    [self cameraSniffer:sniffer passed:YES];
}

- (void)cameraSniffer:(CMCameraSniffer *)sniffer onFound:(CMDevice *)device {
    [self cameraSniffer:sniffer passed:YES];
}

- (void)cameraSniffer:(CMCameraSniffer *)sniffer onError:(CMMobileSDKError *)error {
    [self cameraSniffer:sniffer passed:NO];
}

- (void)cameraSniffer:(CMCameraSniffer *)sniffer passed:(BOOL)passed {
    if (self.sniffer == sniffer) {
        [self triggerButtonCallback:kButtonIdSniffer isPassed:passed];
        self.sniffer = nil;
    }
}

#pragma mark - Cloud Cam Wizard integration
    
- (void)checkCloudCamWizard:(CDVInvokedUrlCommand*)command {
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];

    CMAccessTokenProvider.delegate = self;
    
    self.cloudCamWizard = [[CMCameraWizard alloc] initWithDelegate:self];
    
    CMAddress *address = [[CMAddress alloc] initWithIp4:@"0.0.0.0" mac:@"00:00:00:00:00:00"];
    CMDevice *device = [[CMDevice alloc] initWithAddress:address typeId:0];
    [self.cloudCamWizard addDevice:device named:@"my new camera" atZone:0];
}

- (void)cameraWizard:(CMCameraWizard *)wizard onAdded:(NSInteger)cameraId forDevice:(CMDevice *)device {
    // test not passed because camera with empty values was added
    [self cloudCamWizard:wizard passed:NO];
}

- (void)cameraWizard:(CMCameraWizard *)wizard onError:(CMMobileSDKError *)error forDevice:(CMDevice *)device {
    // test passing when device with ip 0.0.0.0 is not reachable
    [self cloudCamWizard:wizard passed:error.code == 14];
}

- (void)cloudCamWizard:(CMCameraWizard *)wizard passed:(BOOL)passed {
    if (self.cloudCamWizard == wizard) {
        [self triggerButtonCallback:kButtonIdCloudCamWizard isPassed:passed];
        self.cloudCamWizard = nil;
    }
}

#pragma mark - Nubo Cam Wizard integration
    
- (void)checkNuboCamWizard:(CDVInvokedUrlCommand*)command {
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    
    CMAccessTokenProvider.delegate = self;
    
    self.nuboCamWizard = [[CMNuboCamWizard alloc] initWithDelegate:self];
    
    NSDictionary *options = @{@"zoneId" : @(1)};
    [self.nuboCamWizard prepareForConnectionWith:options];
}

- (void)nuboCamWizardOnPreparedForConnection:(CMNuboCamWizard *)wizard {
    [self nuboCamWizard:wizard passed:YES];
}

- (void)nuboCamWizard:(CMNuboCamWizard *)wizard onFinished:(NSInteger)cameraId {
    [self nuboCamWizard:wizard passed:NO];
}

- (void)nuboCamWizard:(CMNuboCamWizard * _Nonnull)wizard onConnectedToCameraWithMobileSetupOption:(enum CMMobileSetupOption)option {
    [self nuboCamWizard:wizard passed:NO];
}

- (void)nuboCamWizard:(CMNuboCamWizard *)wizard onError:(CMMobileSDKError *)error {
    [self nuboCamWizard:wizard passed:NO];
}

- (void)nuboCamWizard:(CMNuboCamWizard *)wizard passed:(BOOL)passed {
    if (self.nuboCamWizard == wizard) {
        [self triggerButtonCallback:kButtonIdNuboCamWizard isPassed:passed];
        self.nuboCamWizard = nil;
    }
}

#pragma mark - Streamer integration
    
- (void)checkStreamer:(CDVInvokedUrlCommand*)command {
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];

    if (command.arguments.count != 2) {
        [self cameraStreamer:self.streamer passed:NO];
        return;
    }
    
    CMAccessTokenProvider.delegate = self;
    
    NSNumber* cameraId = command.arguments.firstObject;
    CMStreamerItem *item = [CMStreamerItem itemWithCameraId:cameraId.unsignedIntegerValue];

    NSArray* frame = command.arguments.lastObject;
    CGRect streamerFrame = CGRectMake([frame[0] floatValue], [frame[1] floatValue], [frame[2] floatValue], [frame[3] floatValue]);

    if (self.streamerView == nil) {
        self.streamerView = [UIView new];
        [self.webView.scrollView addSubview:self.streamerView];
    }
    
    self.streamerView.frame = streamerFrame;
    
    self.streamer = [[CMCameraStreamer alloc] initWithLayer:self.streamerView.layer];
    self.streamer.delegate = self;
    self.streamer.currentItem = item;
}

- (void)cameraStreamer:(id<CMCameraStreamerInterface>)streamer onStatusChanged:(CMCameraStreamerStatus)status {
    if (self.streamer == streamer) {
        [self cameraStreamer:streamer passed:status == CMCameraStreamerStatusReadyToPlay];
        
        if (status == CMCameraStreamerStatusReadyToPlay) {
            streamer.rate = 1.0;
        }
    }
}

- (void)cameraStreamer:(CMCameraStreamer *)streamer passed:(BOOL)passed {
    if (self.streamer == streamer) {
        [self triggerButtonCallback:kButtonIdStreamer isPassed:passed];
        if (!passed) {
            self.streamer = nil;
        }
    }
}

#pragma mark - Misc

- (void)reset:(CDVInvokedUrlCommand*)command {
    self.sniffer = nil;
    self.cloudCamWizard = nil;
    self.nuboCamWizard = nil;
    self.streamer = nil;
    
    [self.streamerView removeFromSuperview];
    self.streamerView = nil;
    
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

- (void)triggerButtonCallback:(NSString *)buttonId isPassed:(BOOL)isPassed {
    NSString *passed = isPassed ? @"true" : @"false";
    NSString *js = [NSString stringWithFormat:@"app.checkButtonCallback(\"%@\", %@);", buttonId, passed];
    [self.commandDelegate evalJs:js];
}
    
@end
