#import <Cordova/CDVPlugin.h>

@interface iOSMobileSDKv3 : CDVPlugin

- (void)checkSniffer:(CDVInvokedUrlCommand*)command;
- (void)checkCloudCamWizard:(CDVInvokedUrlCommand*)command;
- (void)checkNuboCamWizard:(CDVInvokedUrlCommand*)command;
- (void)checkStreamer:(CDVInvokedUrlCommand*)command;
- (void)reset:(CDVInvokedUrlCommand*)command;

@end
