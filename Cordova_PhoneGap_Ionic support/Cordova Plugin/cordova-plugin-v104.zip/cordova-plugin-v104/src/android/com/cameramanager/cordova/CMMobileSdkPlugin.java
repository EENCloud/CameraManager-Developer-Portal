package com.cameramanager.cordova;

import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.os.Handler;
import android.os.Looper;
import android.view.Surface;
import android.view.TextureView;
import android.view.ViewGroup;

import com.cameramanager.mobile_sdk.camera_core.data.Address;
import com.cameramanager.mobile_sdk.camera_core.data.Device;
import com.cameramanager.mobile_sdk.camera_core.data.DeviceModelInfo;
import com.cameramanager.mobile_sdk.camera_core.error.MobileSdkError;
import com.cameramanager.mobile_sdk.nubo.network.api.camera.model.WifiNetwork;
import com.cameramanager.mobile_sdk.nubo.wizard.NuboCamWizard;
import com.cameramanager.mobile_sdk.nubo.wizard.listener.NuboCamWizardListener;
import com.cameramanager.mobile_sdk.sniffer.CameraSniffer;
import com.cameramanager.mobile_sdk.sniffer.CameraSnifferListener;
import com.cameramanager.mobile_sdk.streamer.CameraStreamer;
import com.cameramanager.mobile_sdk.streamer.CameraStreamerListener;
import com.cameramanager.mobile_sdk.streamer.StreamerItem;
import com.cameramanager.mobile_sdk.token_provider.AccessTokenProvider;
import com.cameramanager.mobile_sdk.wizard.CameraWizard;
import com.cameramanager.mobile_sdk.wizard.CameraWizardListener;
import com.cameramanager.mobile_sdk.wizard.model.CameraHotspot;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.Collections;
import java.util.List;

public class CMMobileSdkPlugin extends CordovaPlugin implements AccessTokenProvider,
                                                                CameraSnifferListener,
                                                                CameraWizardListener,
                                                                CameraStreamerListener
{

    ///////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Constants
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////

    private static final String ACCESS_TOKEN = "";

    private static final String kButtonIdSniffer = "snifferButton";
    private static final String kButtonIdCloudCamWizard = "cloudCamWizardButton";
    private static final String kButtonIdNuboCamWizard = "nuboCamWizardButton";
    private static final String kButtonIdStreamer = "streamerButton";

    private static final String ACTION_CHECK_SNIFFER = "checkSniffer";
    private static final String ACTION_CHECK_CLOUD_WIZARD = "checkCloudCamWizard";
    private static final String ACTION_CHECK_NUBO_WIZARD = "checkNuboCamWizard";
    private static final String ACTION_CHECK_STREAMER = "checkStreamer";
    private static final String ACTION_RESET = "reset";

    private static final long SNIFFER_CHECK_PASSED_TIMEOUT_MS = 3_000L;

    ///////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Fields
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////

    private CameraSniffer _cameraSniffer;
    private CameraWizard _cameraWizard;
    private NuboCamWizard _nuboCamWizard;
    private CameraStreamer _cameraStreamer;

    private TextureView _streamerView;

    private final Handler _snifferHandler = new Handler( Looper.getMainLooper() );

    ///////////////////////////////////////////////////////////////////////////////////////////////
    //
    // Public methods
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    public boolean execute( String action, JSONArray args, CallbackContext callbackContext ) throws JSONException
    {
        switch ( action )
        {
            case ACTION_CHECK_SNIFFER:
                checkSniffer( callbackContext );
                return true;

            case ACTION_CHECK_CLOUD_WIZARD:
                checkCloudCamWizard( callbackContext );
                return true;

            case ACTION_CHECK_NUBO_WIZARD:
                checkNuboCamWizard( callbackContext );
                return true;

            case ACTION_CHECK_STREAMER:
                final long cameraId = args.getLong( 0 );
                final JSONArray frame = args.getJSONArray( 1 );
                if ( frame.length() != 4 )
                {
                    throw new JSONException( "4 frame coordinates were not provided" );
                }
                final int left = frame.getInt( 0 );
                final int top = frame.getInt( 1 );
                final int right = left + frame.getInt( 2 );
                final int bottom = top + frame.getInt( 3 );
                checkStreamer( callbackContext, cameraId, new RectF( left, top, right, bottom ) );
                return true;

            case ACTION_RESET:
                reset();
                return true;
        }

        return false;
    }

    // region AccessTokenProvider

    @Override
    public String getAccessToken()
    {
        return ACCESS_TOKEN;
    }

    // endregion AccessTokenProvider

    // region CameraSniffer

    private void checkSniffer( CallbackContext callbackContext )
    {
        callbackContext.sendPluginResult( new PluginResult( PluginResult.Status.OK ) );

        _cameraSniffer = new CameraSniffer( cordova.getContext(), this );
        _cameraSniffer.setProvider( this );
        _cameraSniffer.startSniffing();

        _snifferHandler.postDelayed( () -> onSnifferPassed( false ), SNIFFER_CHECK_PASSED_TIMEOUT_MS );
    }

    private void onSnifferPassed( boolean passed )
    {
        if ( _cameraSniffer != null )
        {
            _cameraSniffer.stopSniffing();
        }
        _snifferHandler.removeCallbacksAndMessages( null );
        triggerButtonCallback( kButtonIdSniffer, passed );
    }

    @Override
    public void onFound( Device device )
    {
        onSnifferPassed( true );
    }

    @Override
    public void onLost( Device device )
    {
        onSnifferPassed( true );
    }
	
	@Override
	public void onFoundManually( Device device )
	{
		onSnifferPassed( true );
	}

    @Override
    public void onError( MobileSdkError mobileSdkError )
    {
        onSnifferPassed( false );
    }

    // endregion CameraSniffer

    // region CameraWizard

    private void checkCloudCamWizard( CallbackContext callbackContext )
    {
        callbackContext.sendPluginResult( new PluginResult( PluginResult.Status.OK ) );

        _cameraWizard = new CameraWizard( this );
        _cameraWizard.setProvider( this );

        final Address address = new Address( "0.0.0.0", "0", "00:00:00:00:00:00" );
        final DeviceModelInfo deviceModelInfo = new DeviceModelInfo( "Brand", "Model" );
        final Device device = new Device( address, deviceModelInfo, 0 );

        _cameraWizard.addDevice( device, "Test Camera", 0 );
    }

    private void onCloudWizardPassed( boolean passed )
    {
        triggerButtonCallback( kButtonIdCloudCamWizard, passed );
    }

    @Override
    public void onAdded( long cameraId )
    {
        onCloudWizardPassed( false );
    }

    @Override
    public void onError( Device device, MobileSdkError mobileSdkError )
    {
        // PASS is the device with IP 0.0.0.0 is not reachable
        onCloudWizardPassed( mobileSdkError.getCode() == 14 );
    }

    // endregion CameraWizard

    // region NuboCamWizard

    private void checkNuboCamWizard( CallbackContext callbackContext )
    {
        callbackContext.sendPluginResult( new PluginResult( PluginResult.Status.OK ) );

        _nuboCamWizard = NuboCamWizard.create( cordova.getContext(), _nuboCamWizardListener, this );

        _nuboCamWizard.prepareForConnection( Collections.singletonMap( "zoneId", "1" ) );
    }

    private void onNuboCamWizardPassed( boolean passed )
    {
        triggerButtonCallback( kButtonIdNuboCamWizard, passed );
    }

    private final NuboCamWizardListener _nuboCamWizardListener = new NuboCamWizardListener()
    {
        @Override
        public void onPreparedForConnection( List< CameraHotspot > list )
        {
            onNuboCamWizardPassed( true );
        }

        @Override
        public void onConnectedToCamera( int i )
        {
            onNuboCamWizardPassed( false );
        }

        @Override
        public void onWifiListRefresh( List< WifiNetwork > list )
        {
            onNuboCamWizardPassed( false );
        }

        @Override
        public void onFinished( long l )
        {
            onNuboCamWizardPassed( false );
        }

        @Override
        public void onDisconnectedFromCameraUnexpectedly()
        {
            onNuboCamWizardPassed( false );
        }

        @Override
        public void onError( MobileSdkError mobileSdkError )
        {
            onNuboCamWizardPassed( false );
        }
    };

    // endregion NuboCamWizard

    // region CameraStreamer

    private void checkStreamer( CallbackContext callbackContext, long cameraId, RectF frameRect )
    {
        callbackContext.sendPluginResult( new PluginResult( PluginResult.Status.OK ) );

        _streamerView = new TextureView( cordova.getActivity() );
        ViewGroup.MarginLayoutParams layoutParams = new ViewGroup.MarginLayoutParams( Math.round( frameRect.right - frameRect.left ),
                                                                                      Math.round( frameRect.bottom - frameRect.top ) );
        layoutParams.leftMargin = (int) frameRect.left;
        layoutParams.topMargin = (int) frameRect.top;
        cordova.getActivity().runOnUiThread( () -> ( (ViewGroup) webView.getView().getParent() ).addView( _streamerView, layoutParams ) );

        _streamerView.setSurfaceTextureListener( new TextureView.SurfaceTextureListener()
        {
            @Override
            public void onSurfaceTextureAvailable( SurfaceTexture surfaceTexture, int width, int height )
            {
                _cameraStreamer = new CameraStreamer( cordova.getContext(), new Surface( surfaceTexture ) );
                _cameraStreamer.setProvider( CMMobileSdkPlugin.this );
                _cameraStreamer.setCameraStreamerListener( CMMobileSdkPlugin.this );
                _cameraStreamer.setStreamerItem( StreamerItem.createItem( cameraId ) );
            }

            @Override
            public void onSurfaceTextureSizeChanged( SurfaceTexture surface, int width, int height )
            {

            }

            @Override
            public boolean onSurfaceTextureDestroyed( SurfaceTexture surface )
            {
                return false;
            }

            @Override
            public void onSurfaceTextureUpdated( SurfaceTexture surface )
            {

            }
        } );

    }

    private void onStreamerPassed( boolean passed )
    {
        triggerButtonCallback( kButtonIdStreamer, passed );
    }

    @Override
    public void onStatusChanged( CameraStreamer.CameraStreamerStatus cameraStreamerStatus )
    {
        final boolean readyToPlay = cameraStreamerStatus == CameraStreamer.CameraStreamerStatus.ReadyToPlay;
        onStreamerPassed( readyToPlay );

        if ( cameraStreamerStatus == CameraStreamer.CameraStreamerStatus.ReadyToPlay )
        {
            _cameraStreamer.setRate( 1.0f );
        }
    }

    @Override
    public void onPlaybackStateChanged( CameraStreamer.CameraStreamerPlaybackState cameraStreamerPlaybackState )
    {

    }

    @Override
    public void onCurrentItemStatusChanged( StreamerItem.StreamerItemStatus streamerItemStatus )
    {

    }

    @Override
    public void onCurrentItemDurationChanged( long l )
    {

    }

    @Override
    public void onAudioStreamingStateChanged( CameraStreamer.CameraStreamerAudioStreamingState cameraStreamerAudioStreamingState )
    {

    }

    @Override
    public void onSnapshotTaken( byte[] bytes, long l )
    {

    }

    // endregion CameraStreamerListener

    private void triggerButtonCallback( String buttonId, boolean passed )
    {
        final String passedResult = passed ? "true" : "false";
        final String jsCommand = String.format( "app.checkButtonCallback(\"%s\", %s);", buttonId, passedResult );
        cordova.getActivity().runOnUiThread( () -> webView.loadUrl( "javascript:" + jsCommand ) );
    }

    private void reset()
    {
        if ( _cameraSniffer != null )
        {
            _cameraSniffer.stopSniffing();
            _cameraSniffer = null;
        }

        if ( _cameraWizard != null )
        {
            _cameraWizard = null;
        }

        if ( _nuboCamWizard != null )
        {
            _nuboCamWizard = null;
        }

        if ( _cameraStreamer != null )
        {
            _cameraStreamer.release();
            _cameraStreamer = null;

            if ( _streamerView != null )
            {
                cordova.getActivity().runOnUiThread( () -> ( (ViewGroup) webView.getView().getParent() ).removeView( _streamerView ) );
            }
        }
    }

}