//
//  DataHandler.h
//  CMTimelineSDK
//
//  Created by Rajlakshmi on 12/24/20.
//

#import <Foundation/Foundation.h>
#import <FontConstant.h>

NS_ASSUME_NONNULL_BEGIN



@interface DataHandler : NSObject

/* Methods to set font family */
+(void)setData:(FontType)value;
+(FontType)getDataForCustomFont;

/* Methods to set Album name */
+(void)setAlbumName:(NSString*)value;
+(NSString*)getAlbumName;

/* Methods to set App Group */
+(void)setAppGroupName:(NSString*)value;
+(NSString*)getAppGroupName;

@end

NS_ASSUME_NONNULL_END
