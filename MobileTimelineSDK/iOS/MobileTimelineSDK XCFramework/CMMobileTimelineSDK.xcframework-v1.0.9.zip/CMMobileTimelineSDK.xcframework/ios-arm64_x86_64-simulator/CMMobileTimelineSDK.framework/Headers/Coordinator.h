//
//  Coordinator.h
//  CMTimelineSDK
//
//  Created by Rajlakshmi on 11/23/20.
//

#import <UIKit/UIKit.h>
#import "FontConstant.h"


NS_ASSUME_NONNULL_BEGIN

@interface CMMobileTimelineSDK : NSObject


@property (strong, nonatomic) NSString *accessToken;
@property (assign, nonatomic) NSNumber *cameraId;
@property (assign, nonatomic) NSTimeInterval time;
@property (assign, nonatomic) BOOL isVerticalRecordingsVisible;
@property (assign, nonatomic) BOOL isTimelineControlsVisible;
@property (strong, nonatomic) NSString *primaryColor;
@property (strong, nonatomic) NSString *secondaryColor;
@property (assign, nonatomic) FontType customFont;
@property (strong, nonatomic) UIViewController *viewController;
@property (assign, nonatomic) int zoomLevel;
@property (assign, nonatomic) BOOL isCameraNameVisible;
@property (strong, nonatomic) NSArray *hideEventTypes;

@property (strong, nonatomic) NSString *albumName;
@property (strong, nonatomic) NSString *appGroupName;

- (instancetype)initWithAccessToken:(NSString *)accessToken
                           cameraId:(NSNumber *)cameraId
                               time:(NSTimeInterval )time
                     viewController:(UIViewController *)viewController;
- (instancetype)initWithAccessToken:(NSString *)accessToken
                           cameraId:(NSNumber *)cameraId
                     viewController:(UIViewController *)viewController;

-(void)present;

//+(NSURL*)getBaseURL;
//+(void)setBaseURL:(NSString *)baseURL;

@end

NS_ASSUME_NONNULL_END
