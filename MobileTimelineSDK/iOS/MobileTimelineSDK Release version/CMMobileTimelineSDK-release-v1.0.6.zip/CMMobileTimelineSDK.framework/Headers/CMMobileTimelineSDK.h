//
//  CMTimelineSDK.h
//  CMTimelineSDK
//
//  Created by Rajlakshmi on 11/20/20.
//

#import <Foundation/Foundation.h>

//! Project version number for CMTimelineSDK.
FOUNDATION_EXPORT double CMTimelineSDKVersionNumber;

//! Project version string for CMTimelineSDK.
FOUNDATION_EXPORT const unsigned char CMTimelineSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CMTimelineSDK/PublicHeader.h>


#import <CMMobileTimelineSDK/Coordinator.h>
