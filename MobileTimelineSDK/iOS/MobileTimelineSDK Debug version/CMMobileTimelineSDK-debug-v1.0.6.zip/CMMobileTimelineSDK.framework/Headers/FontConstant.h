//
//  FontConstant.h
//  CMTimelineSDK
//
//  Created by Rajlakshmi on 12/28/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FontConstant : NSObject


/*   Font type **/
typedef NS_ENUM(NSInteger, FontType) {
  poppinsFont,
  defaultFont,
};


@end

NS_ASSUME_NONNULL_END
