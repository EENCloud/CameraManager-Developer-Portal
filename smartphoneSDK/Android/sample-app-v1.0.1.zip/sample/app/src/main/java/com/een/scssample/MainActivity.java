package com.een.scssample;

import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.cameramanager.smartphonecamerastreamer.SmartphoneCameraStreamer;
import com.cameramanager.smartphonecamerastreamer.SmartphoneCameraStreamerParams;
import com.cameramanager.smartphonecamerastreamer.SmartphoneCameraStreamerState;
import com.cameramanager.smartphonecamerastreamer.SmartphoneCameraStreamerStreamQuality;
import com.cameramanager.smartphonecamerastreamer.listener.SmartphoneCameraListener;

import java.util.Objects;

public class MainActivity extends AppCompatActivity implements SmartphoneCameraListener {

    String TAG = "EEN_SmartCamDemo";
    SmartphoneCameraStreamer cam;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).hide();

        /*
            Step 1. Get credentials for camera installation

                    SmartphoneCameraStreamer streamer = new SmartphoneCameraStreamer(getApplication());
                    String hardwareID = streamer.getHardwareId()
                    String cameraUsername = streamer.getUsername();
                    String cameraPassword = streamer.getPassword()

            Step 2. If you don't have a zone you need to create it before adding a camera
                    Add camera to your zone in backend based on zone id, hardware ID and password ("deviceTypeId" set to 10031)
                    Remember to keep information about user and hardware ID on your backend
                    Remember that HardwareID can be added only to one zone
                    If the user changes the hardware ID (for example: uninstall and install the app) you need to remove the camera in the backend too.

            Step 3. You are ready to go
                    Remember about giving PERMISSIONS!!
                    android.permission.INTERNET
                    android.permission.CAMERA

         */

        // Create SmartphoneCameraStreamer & SmartphoneCameraStreamerParams

        SmartphoneCameraStreamerParams params = new SmartphoneCameraStreamerParams("http://rest.cameramanager.com");
        cam = new SmartphoneCameraStreamer(this, getApplication(), (SurfaceView) findViewById(R.id.surface_camera), params);

        // set listener
        cam.setStreamingListener(this);
        cam.connect();

        // add button to stop streaming
        Button close_stream = findViewById(R.id.close_stream_button);

        close_stream.setOnClickListener(v -> {
            cam.disconnect();
            cam.release();
            finish();
        });
    }

    @Override
    public void onChangeState(SmartphoneCameraStreamerState smartphoneCameraStreamerState) {
        Log.d(TAG, "onChangeState: " + smartphoneCameraStreamerState.toString());
    }

    // With this listener You can catch up on stream quality
    @Override
    public void onChangeStreamQuality(SmartphoneCameraStreamerStreamQuality smartphoneCameraStreamerStreamQuality) {
        Log.d(TAG, "onChangeStreamQuality: " + smartphoneCameraStreamerStreamQuality);
    }


    // With this listener you will know when an error occurs
    /*
        With this listener You can catch up on stream status such as:

        Connecting,
        Reconnecting,
        Streaming,
        Stopping,
        Error

    */
    @Override
    public void onError(int code, String error) {
        Log.d(TAG, "onError: " + error + " code: "+ code);
    }
}